<?php
/*
+===========================================+
|      ArabPortal V2.1.x Copyright � 2006   |
|   -------------------------------------   |
|                                           |
|            By Rafia AL-Otibi              |
|                    And                    |
|              Arab Portal Team             |
|   -------------------------------------   |
|      Web: http://www.ArabPortal.Net       |
|   -------------------------------------   |
|  Last Updated: 22/10/2006 Time: 10:00 PM  |
+===========================================+
*/
/***************************************************************************
				���� ��� 10 ����� �� ������
			   ����� ����� ����� || ���� ��� �������
			www.arabiaone.org (arabgenius@hotmail.com)
	  (Mr.DeaDSouL@hotmail.com) ����� ������ ����� ������� ||
***************************************************************************/

if (TURN_BLOCK_ON !== true)
{
    die ("<center><h3>����</h3></center>");
}

$index_middle .= "<div align=\"center\">
<center><table border='0' width='100%' align='center' cellpadding='".$linkColcount."'><tr>";
$result = mysql_query("SELECT id,title FROM rafia_news where allow='yes' ORDER BY id DESC limit 10");
$index_middle .= "<marquee BEHAVIOR='scroll' direction='right' scrollAmount='3' onmouseover='this.scrollAmount=1' onmouseout='this.scrollAmount=3' width='100%' border='0'>";
while($row = mysql_fetch_array($result))
{
    extract($row);
$index_middle .= "<a href=news.php?action=view&id=$id><b><font color=\"#FFFFFF\">$title</font></a><font color=\"#0E518C\">&nbsp;&nbsp;&nbsp;&nbsp;�&nbsp;&nbsp;&nbsp;</font></b>";
}
$index_middle .= "</marquee>";


$index_middle .= "</tr></table></div>";
echo  $index_middle;
?>