
#------------------- TABLE rafia_admin_menu -------------------
DROP TABLE IF EXISTS rafia_admin_menu; 

CREATE TABLE `rafia_admin_menu` (
  `menuid` int(10) NOT NULL auto_increment,
  `submenu` int(1) NOT NULL default '0',
  `orderby` int(10) NOT NULL default '0',
  `menutitle` varchar(100) default NULL,
  `menuurl` varchar(100) default NULL,
  PRIMARY KEY  (`menuid`)
) ;

INSERT INTO rafia_admin_menu VALUES (1,'',1,'_SETTINGS','');
INSERT INTO rafia_admin_menu VALUES (2,1,'','_MAIN_SETTINGS','index.php?action=settings');
INSERT INTO rafia_admin_menu VALUES (3,1,8,'_BACKUP','index.php?cat=backup');
INSERT INTO rafia_admin_menu VALUES (4,'',2,'_MENU','');
INSERT INTO rafia_admin_menu VALUES (5,4,1,'_MENU_LIST','index.php?cat=menu');
INSERT INTO rafia_admin_menu VALUES (6,4,2,'_ADD_NEW_MENU','index.php?cat=menu&act=add');
INSERT INTO rafia_admin_menu VALUES (7,'',3,'_POLLS_LIST','');
INSERT INTO rafia_admin_menu VALUES (8,7,3,'_POLLS','index.php?cat=poll');
INSERT INTO rafia_admin_menu VALUES (9,7,4,'_ADD_POLL','index.php?cat=poll&act=add');
INSERT INTO rafia_admin_menu VALUES (10,'',4,'_GROUP_MANG','');
INSERT INTO rafia_admin_menu VALUES (11,10,6,'_EDIT_GROUP','index.php?cat=groups&act=groups');
INSERT INTO rafia_admin_menu VALUES (12,10,7,'_ADD_GROUP','index.php?cat=groups&act=add');
INSERT INTO rafia_admin_menu VALUES (13,'',5,'_MEMEBRS_MANGAER','');
INSERT INTO rafia_admin_menu VALUES (14,13,'','_SEARCH','index.php?cat=users&act=search');
INSERT INTO rafia_admin_menu VALUES (15,13,1,'_MEMEBRS_REGISTE','index.php?cat=users');
INSERT INTO rafia_admin_menu VALUES (16,13,2,'_ADD_MEMEBER','index.php?cat=users&act=addusers');
INSERT INTO rafia_admin_menu VALUES (17,13,3,'_MAILING_MEMBERS','index.php?cat=users&act=emailusers');
INSERT INTO rafia_admin_menu VALUES (18,13,4,'_MEMBERS_WAITING','index.php?cat=users&act=userswait');
INSERT INTO rafia_admin_menu VALUES (19,13,5,'_MEMBERS_TITLES','index.php?cat=users&act=usertitles');
INSERT INTO rafia_admin_menu VALUES (20,13,6,'_CON_AVATARS','index.php?cat=users&act=avatars');
INSERT INTO rafia_admin_menu VALUES (21,'',6,'_MAILLIST_MANAGER','');
INSERT INTO rafia_admin_menu VALUES (22,21,'','_MAILLIST_MANAGER','index.php?cat=maillest&act=admin');
INSERT INTO rafia_admin_menu VALUES (23,21,1,'_MAILLIST_LIST','index.php?cat=maillest&act=list');
INSERT INTO rafia_admin_menu VALUES (24,21,2,'_SENDING_MAILLIST','index.php?cat=maillest&act=emails');
INSERT INTO rafia_admin_menu VALUES (25,'',7,'_ADS_MANAGER','');
INSERT INTO rafia_admin_menu VALUES (26,25,'','_ADD_ADS','index.php?cat=ads&act=add');
INSERT INTO rafia_admin_menu VALUES (27,25,1,'_EDIT_DELETE','index.php?cat=ads&act=list');
INSERT INTO rafia_admin_menu VALUES (28,25,2,'_ADS_REPORT','index.php?cat=ads&act=veiw');
INSERT INTO rafia_admin_menu VALUES (29,'',8,'_SMILES_MANAGER','');
INSERT INTO rafia_admin_menu VALUES (30,29,1,'_ADD_SMILES','index.php?cat=smiles&act=add');
INSERT INTO rafia_admin_menu VALUES (31,29,2,'_EDIT_DELETE','index.php?cat=smiles&act=list');
INSERT INTO rafia_admin_menu VALUES (32,'',9,'_THEME','');
INSERT INTO rafia_admin_menu VALUES (33,32,'','_EDIT_THEME','index.php?cat=template&act=design');
INSERT INTO rafia_admin_menu VALUES (34,32,1,'_ADD_THEME','index.php?cat=template&act=adddesign');
INSERT INTO rafia_admin_menu VALUES (35,32,2,'_SHOW_TEMPLATES','index.php?cat=template&act=temp');
INSERT INTO rafia_admin_menu VALUES (36,32,3,'_ADD_TEMPLATE','index.php?cat=template&act=add');
INSERT INTO rafia_admin_menu VALUES (37,32,4,'_COPY_UPLOAD_TEMPLATE','index.php?cat=template&act=copy');
INSERT INTO rafia_admin_menu VALUES (38,'',10,'_NEW_PAGES','');
INSERT INTO rafia_admin_menu VALUES (39,38,'','_EDIT_AND_DELETE','index.php?cat=template&act=pages');
INSERT INTO rafia_admin_menu VALUES (40,38,1,'_ADD_NEW_PAGE','index.php?cat=template&act=addpage');
INSERT INTO rafia_admin_menu VALUES (41,'',11,'_NEWS_CONTROL','');
INSERT INTO rafia_admin_menu VALUES (42,41,'','_NEWS_SETTINGS','index.php?cat=news');
INSERT INTO rafia_admin_menu VALUES (43,41,1,'_CATS_LIST','index.php?cat=news&act=cat');
INSERT INTO rafia_admin_menu VALUES (44,41,2,'_ADD_CAT','index.php?cat=news&act=addcat');
INSERT INTO rafia_admin_menu VALUES (45,41,3,'_MOD_LIST','index.php?cat=news&act=mod');
INSERT INTO rafia_admin_menu VALUES (46,41,4,'_ADD_MOD','index.php?cat=news&act=addmod');
INSERT INTO rafia_admin_menu VALUES (47,41,5,'_AVAILABLE_MENUS','index.php?cat=news&act=newsmenu');
INSERT INTO rafia_admin_menu VALUES (48,'',11,'_FORUM_PRO','');
INSERT INTO rafia_admin_menu VALUES (49,48,'','_FORUM_SETTINGS','index.php?cat=forum');
INSERT INTO rafia_admin_menu VALUES (50,48,1,'_CATS_LIST','index.php?cat=forum&act=cat');
INSERT INTO rafia_admin_menu VALUES (51,48,2,'_ADD_MAIN_CAT','index.php?cat=forum&act=addmine');
INSERT INTO rafia_admin_menu VALUES (52,48,3,'_ADD_SUB_CAT','index.php?cat=forum&act=addcat');
INSERT INTO rafia_admin_menu VALUES (53,48,4,'_MOD_LIST','index.php?cat=forum&act=mod');
INSERT INTO rafia_admin_menu VALUES (57,48,5,'_ADD_MOD','index.php?cat=forum&act=addmod');
INSERT INTO rafia_admin_menu VALUES (58,'',11,'_DOWNLOAD_PRO','');
INSERT INTO rafia_admin_menu VALUES (59,58,'','_DOWNLOAD_SETTINGS','index.php?cat=download');
INSERT INTO rafia_admin_menu VALUES (60,58,1,'_CATS_LIST','index.php?cat=download&act=cat');
INSERT INTO rafia_admin_menu VALUES (61,58,1,'_ADD_CAT','index.php?cat=download&act=addcat');
INSERT INTO rafia_admin_menu VALUES (62,58,2,'_MOD_LIST','index.php?cat=download&act=mod');
INSERT INTO rafia_admin_menu VALUES (63,58,3,'_ADD_MOD','index.php?cat=download&act=addmod');
INSERT INTO rafia_admin_menu VALUES (64,58,4,'_AVAILABLE_MENUS','index.php?cat=download&act=downmenu');
INSERT INTO rafia_admin_menu VALUES (65,'',11,'_WEB_LINKS','');
INSERT INTO rafia_admin_menu VALUES (66,65,'','_WEB_LINKS_SETTINGS','index.php?cat=link');
INSERT INTO rafia_admin_menu VALUES (67,65,1,'_CATS_LIST','index.php?cat=link&act=cat');
INSERT INTO rafia_admin_menu VALUES (68,65,1,'_ADD_CAT','index.php?cat=link&act=addcat');
INSERT INTO rafia_admin_menu VALUES (69,65,2,'_MOD_LIST','index.php?cat=link&act=mod');
INSERT INTO rafia_admin_menu VALUES (70,65,3,'_ADD_MOD','index.php?cat=link&act=addmod');
INSERT INTO rafia_admin_menu VALUES (71,65,4,'_AVAILABLE_MENUS','index.php?cat=link&act=linkmenu');
INSERT INTO rafia_admin_menu VALUES (72,4,3,'_MAIN_MENUS','index.php?cat=menu&act=indexmenu');
INSERT INTO rafia_admin_menu VALUES (73,'',1,'_MOD','mod.php');
INSERT INTO rafia_admin_menu VALUES (74,1,8,'_COUNTER','index.php?action=Counter');
INSERT INTO rafia_admin_menu VALUES (75,73,1,'_MOD_NEW','mod.php?act=new');
INSERT INTO rafia_admin_menu VALUES (76,73,2,'_MOD_SET','mod.php?act=set');
INSERT INTO rafia_admin_menu VALUES (77,73,3,'_MOD_MANAG','mod.php?act=manag');
INSERT INTO rafia_admin_menu VALUES (78,73,3,'_MOD_TEMP','mod.php?act=temp');
INSERT INTO rafia_admin_menu VALUES (79,1,8,'_CHECKNEW','index.php?cat=checknew');
INSERT INTO rafia_admin_menu VALUES (80,13,6,'_UPDATE_U_P','index.php?cat=users&act=update_u_p');
INSERT INTO rafia_admin_menu VALUES (81, 1, 8, '_MAIL_US', 'index.php?cat=mailus');

#------------------- TABLE rafia_admin_sess -------------------
DROP TABLE IF EXISTS rafia_admin_sess; 

CREATE TABLE `rafia_admin_sess` (
  `sessID` varchar(32) NOT NULL default '',
  `sessIP` varchar(32) NOT NULL default '',
  `sess_NAME` varchar(32) NOT NULL default '',
  `sess_TIME` int(11) NOT NULL default '0',
  `sess_VALUE` text NOT NULL,
  `sess_LOGTIME` int(10) NOT NULL default '0',
  PRIMARY KEY  (`sessID`)
) ;


#------------------- TABLE rafia_ads -------------------
DROP TABLE IF EXISTS rafia_ads; 

DROP TABLE IF EXISTS rafia_ads;
CREATE TABLE rafia_ads (
  adsid tinyint(10) unsigned NOT NULL auto_increment,
  adsimg varchar(200) default NULL,
  width int(3) NOT NULL default '0',
  height int(3) NOT NULL default '0',
  adsdatetime int(11) NOT NULL default '0',
  adsurl varchar(200) default NULL,
  adsisshow varchar(5) NOT NULL default 'no',
  adsname varchar(200) default NULL,
  numshow int(10) unsigned default '0',
  clicks int(10) NOT NULL default '0',
  viewin char(1) NOT NULL default 'h',
  active tinyint(1) NOT NULL default '1',
  PRIMARY KEY  (adsid)
);


INSERT INTO rafia_ads VALUES (1,'images/ads/ads.gif','','',1161540665,'http://www.arabportal.net','yes','������� �������',0,'','h',1);
INSERT INTO rafia_ads VALUES (2,'images/ads/book.gif','','',1169222970,'http://www.arabportal.net','yes','������� ������� 2.1',0,'','m',1);
INSERT INTO rafia_ads VALUES (3, 'images/ads/service4ar.gif', 0, 0, 1192488883, 'http://www.service4ar.com', 'yes', '���� ����� �����', 2, 0, 'm', 1); 


#------------------- TABLE rafia_alert -------------------
DROP TABLE IF EXISTS rafia_alert; 

CREATE TABLE `rafia_alert` (
  `id` int(10) NOT NULL auto_increment,
  `news_id` int(10) NOT NULL default '0',
  `thread_id` int(10) NOT NULL default '0',
  `down_id` int(10) NOT NULL default '0',
  `userid` int(10) NOT NULL default '0',
  `sendmsg` int(1) NOT NULL default '0',
  PRIMARY KEY  (`id`)
) ;



#------------------- TABLE rafia_cat -------------------
DROP TABLE IF EXISTS rafia_cat; 

CREATE TABLE `rafia_cat` (
  `id` int(10) NOT NULL auto_increment,
  `ordercat` int(10) NOT NULL default '0',
  `catType` int(3) NOT NULL default '0',
  `subcat` int(10) NOT NULL default '0',
  `title` varchar(100) NOT NULL default '',
  `dsc` text NOT NULL,
  `dscin` text NOT NULL,
  `countopic` int(10) NOT NULL default '0',
  `countcomm` int(10) NOT NULL default '0',
  `lastpostid` int(11) NOT NULL default '0',
  `moderateid` varchar(100) NOT NULL default '0',
  `ismine` tinyint(2) NOT NULL default '0',
  `groupost` varchar(200) NOT NULL default '0',
  `groupview` varchar(200) NOT NULL default '0',
  `cat_email` varchar(255) default NULL,
  `catClose` char(1) NOT NULL default '0',
  PRIMARY KEY  (`id`)
) ;

INSERT INTO rafia_cat VALUES (1, 0, 1, 0, '����� �����', '���� ������� �������', '', 1, 0, 4, '', 0, '1,2,4', '1,2,3,4', '', '');
INSERT INTO rafia_cat VALUES (2, 0, 2, 0, '��������� ������', '', '', 0, 0, 0, '', 1, '', '', '', '');
INSERT INTO rafia_cat VALUES (3, 0, 2, 2, '������� �����', '���� �������� ������ ����� ������ �� ���� ����', '', 0, 0, 3, '', 0, '1,2,4', '1,2,3,4', '', '');
INSERT INTO rafia_cat VALUES (4, 0, 3, 0, '����� �����', '��� ������� �������', '��� ������� �������', 0, 0, 1, '', 0, '', '', '', '');
INSERT INTO rafia_cat VALUES (5, 0, 4, 0, '��� ������', '��� ������� �������', '��� ������� �������', 2, 0, 0, '', 0, '', '', '', '');

#------------------- TABLE rafia_comment -------------------
DROP TABLE IF EXISTS rafia_comment;
CREATE TABLE rafia_comment (
  id int(10) NOT NULL auto_increment,
  news_id int(10) NOT NULL default '0',
  modType int(3) NOT NULL default '0',
  thread_id int(10) NOT NULL default '0',
  down_id int(10) NOT NULL default '0',
  userid int(10) NOT NULL default '0',
  name varchar(100) NOT NULL default '',
  title varchar(100) NOT NULL default '',
  date_time int(11) NOT NULL default '0',
  `comment` text NOT NULL,
  cat_id int(10) NOT NULL default '0',
  usesig tinyint(1) NOT NULL default '1',
  uploadfile int(10) NOT NULL default '0',
  `timestamp` int(10) NOT NULL default '0',
  allow char(3) NOT NULL default '',
  aa tinyint(1) NOT NULL default '0',
  PRIMARY KEY  (id)
);




#------------------- TABLE rafia_counter -------------------
DROP TABLE IF EXISTS rafia_counter; 

CREATE TABLE `rafia_counter` (
  `conterID` int(1) NOT NULL auto_increment,
  `newsCount` int(12) NOT NULL default '0',
  `downCount` int(12) NOT NULL default '0',
  `forumCount` int(12) NOT NULL default '0',
  `gbCount` int(12) NOT NULL default '0',
  `linksCount` int(12) NOT NULL default '0',
  `usersCount` int(12) NOT NULL default '0',
  `commentCount` int(12) NOT NULL default '0',
  `totalCount` int(15) NOT NULL default '0',
  `mostCount` int(12) NOT NULL default '0',
  `mosttime` int(11) NOT NULL default '0',
  `dayCount` int(12) NOT NULL default '0',
  `timetoday` int(11) NOT NULL default '0',
  PRIMARY KEY  (`conterID`)
) ;

INSERT INTO rafia_counter VALUES (1, 1, 0, 0, 0, 2, 1, 0, 1026, 311, 1170964800, 1, 1177876800); 


#------------------- TABLE rafia_design -------------------
#
# Table structure for table `rafia_design`
#

DROP TABLE IF EXISTS rafia_design; 
CREATE TABLE `rafia_design` (
  `id` tinyint(4) NOT NULL auto_increment,
  `theme` varchar(60) NOT NULL default '',
  `usertheme` int(1) NOT NULL default '0',
  `aa` varchar(10) NOT NULL default '',
  `themewidth` varchar(10) NOT NULL default '',
  `themepath` varchar(100) default NULL,
  `style_css` longtext NOT NULL,
  `pagehd` text NOT NULL,
  `pageft` text NOT NULL,
  PRIMARY KEY  (`id`)
);

#
# Dumping data for table `rafia_design`
#

INSERT INTO rafia_design VALUES (1,'arabportal',1,'','778','apt','.nav{\r\n    font-family: arial;\r\n    font-size: 16px;\r\n    font-weight: bold;\r\n    color: Gray; \r\n    align: right;\r\n    padding-right: 25px;\r\n    padding-bottom: 5px;\r\n    margin-bottom: 5px;\r\n    background-image: url(images/r.gif); background-repeat: no-repeat; background-position: right top;\r\n    border-bottom: 1px solid #C2C2C2;\r\n}\r\n.normal {font-family: arial;\r\n    font-size: 16px;\r\n    font-weight: bold;\r\n}\r\n.orang_b     { font-family:Bold 16px Arial;\r\n               color: #FFFFFF; \r\n                background-color: #EE753A; \r\n                    padding:3;\r\n                    margin-left:3px;\r\n\r\n\r\n                    \r\n                    }\r\n.info_bar    { font-family: Tahoma; font-size: 10pt; color: #808080; background-color:\r\n               #EBEBEB }\r\n.normal_dark_link{ font-family: Arial; font-size: 12pt; color: #FFFFFF; font-weight: bold ;text-decoration:none;\r\n\r\npadding-top: 3; padding-bottom: 3\r\n}\r\n\r\n.normal_dark_link2{ font-family: Arial; font-size: 12pt; color: #FFFFFF; font-\"\"weight: bold ;text-decoration: none;\r\n background-color: #34597D; \r\npadding-top: 3; padding-bottom: 3\r\n}\r\n\r\nBODY {\r\n    FONT-FAMILY: #Arial, Helvetica;\r\n    FONT-SIZE : 13px;\r\n    weight: bold;\r\n    COLOR : #3A3A3A;\r\n TEXT-DECORATION : none\r\n    }\r\n\r\nA:link      {\r\n    COLOR : #000000;\r\n    TEXT-DECORATION : none\r\n    }\r\nA:visited   {\r\nCOLOR : #000000;\r\n    TEXT-DECORATION : none\r\n    }\r\nA:hover     {\r\n    COLOR : #cc3300;\r\nTEXT-DECORATION : none\r\n    }\r\nA:active    {\r\nCOLOR : #000000;\r\n    TEXT-DECORATION : none;\r\n    }\r\n\r\nH1 { font-family: \'impact, arial\';\r\n        font-size: 20pt;\r\n        color:  #3A3A3A;\r\n        BACKGROUND-COLOR : #34597D\r\n}\r\n\r\n.fontht{\r\n    font-size: 12 pt;\r\n    font-family: Arial, Helvetica;\r\n    color: #3A3A3A;\r\n    font-weight: bold;\r\n    }\r\n.fontablt     {\r\n    font-family: tahoma;\r\n    font-size: 10 pt;\r\n     color: #505050\r\n    }\r\nSELECT {\r\n    font-size: 12px Tahoma;\r\n    background-color: #EBEBEB;\r\n    color: #666666;\r\n}\r\nTEXTAREA {\r\nFONT-FAMILY: Tahoma, MS Sans Serif, ;\r\nFONT-SIZE: 12px;\r\nborder: 1px #cccccc solid;\r\n\r\n}\r\n.text_box{\r\n    font:12px tahoma;\r\n border: 1px #cccccc solid;\r\n}\r\n\r\n.button{\r\n  font:12px tahoma;\r\n   background-color: #FFF;\r\n    border: 1px #cccccc solid;\r\n}\r\n\r\n.small{\r\n    font: 13px tahoma;\r\n}\r\n\r\n.table_main {\r\n   border: 1px #000000 solid;\r\n    background-color: #F1F1F1;\r\n    border-collapse: collapse;\r\n    bordercolor=\"#111111\";\r\n    width=\"100%\" ;\r\n}\r\n\r\n.forum_table_main {\r\n   border: 1px #000000 solid;\r\n    background-color: #F1F1F1;\r\n    border-collapse: collapse;\r\n    bordercolor=\"#111111\";\r\n    width=\"90%\" ;\r\n}\r\n\r\n.td_top_cat {\r\n   background-color: #B0CCB0;\r\n   font-size: 10 pt;\r\n   font-family: tahoma;\r\n   color: 000000;\r\nfont-weight: bold;\r\n\r\n   }\r\n.td_bottom_cat {\r\n   background-color: #FFFFFF;\r\n   font-family: Arial, Helvetica;\r\n   font-size: 9 pt;\r\n   color: 000000\r\n}\r\n.td_top_list\r\n{\r\n    background: #34597D;\r\n    border:0px;  \r\n    vertical-align:top;\r\n    font-size: 12 pt;\r\n font-family: Arial, Helvetica;\r\n    color: #3A3A3A;\r\n    font-weight: bold;\r\n     color: #FFF;\r\n\r\n    \r\n}\r\n.td_middle_list\r\n{\r\n    text-align:right ;\r\n    vertical-align:top;\r\n   font-family: tahoma;\r\n   font-size: 10 pt;\r\n   color: 000000\r\n\r\n}\r\n.td_middle_list2\r\n{\r\n     background-color: E0E9E2;\r\n    text-align:right ;\r\n    vertical-align:top;\r\n   font-family: tahoma;\r\n   font-size: 10 pt;\r\n   color: 000000\r\n}\r\n.bgcolor1{\r\n background-color: #FFFFFF ;\r\n}\r\n.bgcolor2{\r\n background-color: #FFFFFF ;\r\n}\r\n.bgcolor3{\r\n background-color: #34597D;\r\n}\r\n.bgcolor4{\r\n background-color: #FFFFFF ;\r\n}\r\n\r\n.forum_control_bar{\r\n    background: #EEEEEE;\r\n    border-bottom: solid 1px #C1C1C1;\r\n    border-top: solid 1px #FFF;\r\n    font: 12px tahoma;\r\n}\r\n.small_dark_link{\r\n    font-family: tahoma; font-size: 12px; color: #FFFFFF; text-decoration: none;\r\nbackground-color: #34597D; \r\npadding-top: 3; padding-bottom: 3;padding-left: 3;\r\n}\r\n.forum_header{\r\n    font:bold 12pt arial;\r\n    text-align: center;\r\n    background-image: url(../../themes/apt/catbg2.gif);\r\n    background-repeat: repeat-x;\r\n    color: #ffffff;\r\n    padding: 3px;\r\n}\r\n\r\n.forum_header2{\r\n    font:bold 12pt arial;\r\n    text-align: center;\r\n    background-image: url(../../themes/apt/apt_23.gif);\r\n    background-repeat: repeat-x;\r\n    color: #ffffff;\r\n    padding: 3px;\r\n}\r\n\r\n.forum_alt1{\r\n    font:bold 12pt arial;\r\n    color: #34597D;\r\n    background: #DFE9F4;\r\n    padding: 0px;\r\n}\r\n\r\n.forum_alt2{\r\n    font-size: 12 pt;\r\n    font-family: Arial, Helvetica;\r\n    color: #34597D;\r\n    font-weight: bold;\r\n    }\r\n\r\n\r\n.forum_alt3{\r\n    font:bold 12pt arial;\r\n    color: #34597D;\r\n    background: #FFFFFF;\r\n    padding: 0px;\r\n    border-bottom: solid 3px #8CA7C3;\r\n    border-left: solid 1px #8CA7C3;\r\n    border-right: solid 1px #8CA7C3;\r\n    border-top: solid 1px #8CA7C3;\r\n}\r\n\r\n.news_cat_title {\r\n	background: url(themes/apt/cat_bg.gif) repeat-x bottom;\r\n	width: 100%;\r\n	height: 26px;\r\n	text-align: center;\r\n}\r\n.news_cat_title img {\r\n	margin-left: -3px;\r\n	margin-right: -4px;\r\n}\r\n.news_cat_title a {\r\n	height: 26px;\r\n	font-family: Arial;\r\n	font-size: 15px;\r\n	font-weight: bold;\r\n	color: #7C1D09;\r\n	text-decoration: none;\r\n	padding-top: 4px;\r\n}\r\n.news_cat_title a:hover {\r\n	color: #D2691E;\r\n}\r\n\r\n.news_title {\r\n	padding-right: 14px;\r\n	font-family: Arial;\r\n	font-size: 15px;\r\n	font-weight: bold;\r\n	text-align: right;\r\n	color: #8B0000;\r\n	background-image: url(themes/apt/news_icon.gif);\r\n	background-position: right;\r\n	background-repeat: no-repeat;\r\n	clear: both;\r\n}\r\n.news_title a {\r\n	font-family: Arial;\r\n	font-size: 15px;\r\n	font-weight: bold;\r\n	color: #A52A2A;\r\n	text-align: right;\r\n	text-decoration: none;\r\n}\r\n.news_title a:hover {\r\n	color: #D2691E;\r\n	text-align: right;\r\n}\r\n\r\n.article_info\r\n{\r\n	background-image: url(themes/apt/info.gif);\r\n	background-repeat: no-repeat;\r\n	background-position: right;\r\n	color: #8B7547;\r\n	font-family: Tahoma;\r\n	font-size: 11px;\r\n	display: block;\r\n	padding: 2px 13px 2px 3px;\r\n	margin-bottom: 2px;\r\n}\r\n.article_info a {\r\n	color: #A0522D;\r\n	text-decoration: none;\r\n}\r\n.article_pic {\r\n	border: 1px solid #CCCCCC;\r\n	padding: 3px 3px 3px 3px;\r\n	margin: 3px 2px 1px 2px;\r\n	background-color: White;\r\n	display: inline;\r\n}\r\n.home_text {\r\n	font: 12px Tahoma;\r\n	color: #505050;\r\n	text-align: justify;\r\n}\r\n.side_menu_head{\r\n    font-family: Tahoma;\r\n    font-size: 12px;\r\n    color: #ffffff;\r\n    padding: 3px;\r\n}\r\n.side_menu_center{\r\n    font-family: Tahoma;\r\n    font-size: 10 pt;\r\n    text-align: right;\r\n     color: #505050\r\n}\r\n.side_menu_center a {\r\n	font-family: Tahoma;\r\n	font-size: 12px;\r\n	color: #505050;\r\n	text-align: right;\r\n	text-decoration: none;\r\n}\r\n.side_menu_center a:hover {\r\n	color: #D2691E;\r\n}','<center><table border=\"0\" width=\"$themewidth\" id=\"table1\" height=\"9\" cellspacing=\"0\" cellpadding=\"0\">\r\n	<tr>\r\n		<td colspan=\"15\" background=\"themes/apt/apt_01.gif\" width=\"100%\" height=\"9\">\r\n		<img border=\"0\" src=\"themes/apt/apt_01.gif\" width=\"1\" height=\"9\"></td>\r\n	</tr>\r\n	<tr>\r\n		<td width=\"78\">\r\n		<a href=\"./\">\r\n		<img border=\"0\" src=\"themes/apt/apt_16.gif\" width=\"78\" height=\"22\"></a></td>\r\n		<td width=\"3\">\r\n		<img border=\"0\" src=\"themes/apt/apt_05.gif\" width=\"3\" height=\"22\"></td>\r\n		<td width=\"40\">\r\n		<a href=\"forum.php\">\r\n		<img border=\"0\" src=\"themes/apt/apt_14.gif\" width=\"40\" height=\"22\"></a></td>\r\n		<td width=\"3\">\r\n		<img border=\"0\" src=\"themes/apt/apt_05.gif\" width=\"3\" height=\"22\"></td>\r\n		<td width=\"39\">\r\n		<a href=\"news.php\">\r\n		<img border=\"0\" src=\"themes/apt/apt_12.gif\" width=\"39\" height=\"22\"></a></td>\r\n		<td width=\"3\">\r\n		<img border=\"0\" src=\"themes/apt/apt_05.gif\" width=\"3\" height=\"22\"></td>\r\n		<td width=\"69\">\r\n		<a href=\"download.php\">\r\n		<img border=\"0\" src=\"themes/apt/apt_10.gif\" width=\"69\" height=\"22\"></a></td>\r\n		<td width=\"3\">\r\n		<img border=\"0\" src=\"themes/apt/apt_05.gif\" width=\"3\" height=\"22\"></td>\r\n		<td width=\"57\">\r\n		<a href=\"link.php\">\r\n		<img border=\"0\" src=\"themes/apt/apt_08.gif\" width=\"57\" height=\"22\"></a></td>\r\n		<td width=\"3\">\r\n		<img border=\"0\" src=\"themes/apt/apt_05.gif\" width=\"3\" height=\"22\"></td>\r\n		<td width=\"58\">\r\n		<a href=\"guestbook.php\">\r\n		<img border=\"0\" src=\"themes/apt/apt_06.gif\" width=\"58\" height=\"22\"></a></td>\r\n		<td width=\"3\">\r\n		<img border=\"0\" src=\"themes/apt/apt_05.gif\" width=\"3\" height=\"22\"></td>\r\n		<td width=\"50\">\r\n		<a href=\"mail.php\">\r\n		<img border=\"0\" src=\"themes/apt/apt_04.gif\" width=\"50\" height=\"22\"></a></td>\r\n		<td width=\"3\">\r\n		<img border=\"0\" src=\"themes/apt/apt_05.gif\" width=\"3\" height=\"22\"></td>\r\n		<td background=\"themes/apt/apt_02.gif\" width=\"100%\" height=\"22\"> \r\n		<a href=\"index.php?action=rss\">\r\n		<img border=\"0\" src=\"themes/apt/apt_03.gif\" width=\"50\" height=\"22\" align=\"left\"></a></td>\r\n	</tr>\r\n</table>\r\n<table border=\"0\" width=\"$themewidth\" id=\"table2\" cellspacing=\"0\" cellpadding=\"0\">\r\n	<tr>\r\n		<td width=\"163\">\r\n		<img border=\"0\" src=\"themes/apt/apt_20.gif\" width=\"163\" height=\"85\"></td>\r\n		<td width=\"160\">\r\n		<img border=\"0\" src=\"themes/apt/apt_19.gif\" width=\"160\" height=\"85\"></td>\r\n		<td background=\"themes/apt/apt_18.gif\" width=\"100%\"> </td>\r\n		<td width=\"113\">\r\n		<img border=\"0\" src=\"themes/apt/apt_17.gif\" width=\"113\" height=\"85\"></td>\r\n	</tr>\r\n</table>\r\n<table border=\"0\" width=\"$themewidth\" id=\"table3\" cellspacing=\"0\" cellpadding=\"0\">\r\n	<tr>\r\n		<td colspan=\"6\" background=\"themes/apt/apt_21.gif\" width=\"100%\" height=\"12\">\r\n		<img border=\"0\" src=\"themes/apt/apt_21.gif\" width=\"1\" height=\"12\"></td>\r\n	</tr>\r\n</table></center>','<!-- Footer Start -->\r\n<center>\r\n <table border=\"0\" cellpadding=\"0\" cellspacing=\"0\" width=\"$themewidth\" id=\"table2\">\r\n  <tr>\r\n    <td>\r\n    <img border=\"0\" src=\"themes/apt/footer_01.jpg\" width=\"278\" height=\"66\"></td>\r\n    <td background=\"themes/apt/footer_03.jpg\" width=\"100%\" align=\"center\" style=\"color: #3F81A1; font-family: Tahoma; font-size: 10pt\">\r\n	<font color=\"#EBEBEB\">Powered by:</font>\r\n    <a target=\"_blank\" class=\"footer_link\" href=\"http://www.arabportal.net\">\r\n	<font color=\"#FF3300\">Arab Portal</font></a> <font color=\"#EBEBEB\">v2.1\r\n, Copyright� 2007</font>\r\n    </td>\r\n    <td>\r\n    <a href=\"http://www.myrosy.com\">\r\n    <img border=\"0\" src=\"themes/apt/footer_02.jpg\" width=\"62\" height=\"66\"></a></td>\r\n </tr>\r\n</table></center>\r\n<!-- Footer End -->');

#------------------- TABLE rafia_download -------------------
DROP TABLE IF EXISTS rafia_download; 

CREATE TABLE `rafia_download` (
  `id` int(10) NOT NULL auto_increment,
  `cat_id` int(10) NOT NULL default '0',
  `title` varchar(100) NOT NULL default '',
  `date_time` int(11) NOT NULL default '0',
  `userid` int(10) NOT NULL default '0',
  `name` varchar(100) NOT NULL default '',
  `size` varchar(11) NOT NULL default '0',
  `post_head` text NOT NULL,
  `post` text NOT NULL,
  `url` varchar(100) default NULL,
  `uploadfile` int(10) NOT NULL default '0',
  `exp_show` varchar(200) default NULL,
  `formmember` char(3) NOT NULL default 'no',
  `downFrom` tinyint(1) NOT NULL default '1',
  `allow` char(3) NOT NULL default 'yes',
  `rating_total` int(10) NOT NULL default '0',
  `ratings` int(10) NOT NULL default '0',
  `c_comment` int(10) NOT NULL default '0',
  `sticky` tinyint(5) NOT NULL default '0',
  `close` tinyint(1) NOT NULL default '0',
  `clicks` int(10) NOT NULL default '0',
  PRIMARY KEY  (`id`)
) ;



#------------------- TABLE rafia_email -------------------
DROP TABLE IF EXISTS rafia_email; 

CREATE TABLE `rafia_email` (
  `id` int(10) NOT NULL auto_increment,
  `title` varchar(100) NOT NULL default '',
  `email` varchar(100) NOT NULL default '',
  PRIMARY KEY  (`id`)
) ;



#------------------- TABLE rafia_forum -------------------
DROP TABLE IF EXISTS rafia_forum; 

CREATE TABLE `rafia_forum` (
  `id` int(10) NOT NULL auto_increment,
  `cat_id` int(10) NOT NULL default '0',
  `title` varchar(100) NOT NULL default '',
  `date_time` int(11) NOT NULL default '0',
  `userid` int(10) NOT NULL default '0',
  `name` varchar(100) NOT NULL default '',
  `post` text NOT NULL,
  `allow` char(3) NOT NULL default '',
  `usesig` tinyint(1) NOT NULL default '1',
  `iconid` int(5) NOT NULL default '0',
  `uploadfile` int(10) NOT NULL default '0',
  `reader` int(10) default '0',
  `c_comment` int(10) default '0',
  `sticky` tinyint(5) NOT NULL default '0',
  `close` tinyint(1) NOT NULL default '0',
  `lastuserid` int(10) NOT NULL default '0',
  `timestamp` int(10) NOT NULL default '0',
  `edit_by` varchar(255) NOT NULL default '0',
  `ip_address` varchar(180) default NULL,
  PRIMARY KEY  (`id`),
  KEY `post` (`post`(1))
) ;



#------------------- TABLE rafia_groups -------------------

DROP TABLE IF EXISTS rafia_groups; 

CREATE TABLE `rafia_groups` (
  `groupid` int(3) unsigned NOT NULL auto_increment,
  `grouptitle` varchar(100) NOT NULL default '0',
  `view_site` tinyint(1) NOT NULL default '0',
  `add_news` int(1) NOT NULL default '0',
  `stat_news` char(3) NOT NULL default 'yes',
  `add_news_c` int(1) NOT NULL default '0',
  `download_news_file` int(1) NOT NULL default '1',
  `add_news_img` int(1) NOT NULL default '0',
  `edit_news` int(1) NOT NULL default '0',
  `edit_news_own` int(1) NOT NULL default '0',
  `delete_news` int(1) NOT NULL default '0',
  `print_news` int(1) NOT NULL default '0',
  `ues_editor` int(1) NOT NULL default '0',
  `view_forum` int(1) NOT NULL default '0',
  `add_forum_post` int(1) NOT NULL default '0',
  `stat_forum` char(3) NOT NULL default 'yes',
  `add_forum_c` int(1) NOT NULL default '0',
  `upload_forum_file` int(1) NOT NULL default '0',
  `download_forum_file` int(1) NOT NULL default '0',
  `edit_forum` int(1) NOT NULL default '0',
  `edit_forum_own` int(1) NOT NULL default '0',
  `delete_forum` int(1) NOT NULL default '0',
  `print_forum` int(1) NOT NULL default '0',
  `view_download` int(1) NOT NULL default '0',
  `stat_download` char(3) NOT NULL default 'yes',
  `add_download` int(1) NOT NULL default '0',
  `add_download_c` int(1) NOT NULL default '0',
  `upload_download_file` int(1) NOT NULL default '0',
  `edit_download` int(1) NOT NULL default '0',
  `edit_download_own` int(1) NOT NULL default '0',
  `allow_download_alert` int(1) NOT NULL default '0',
  `allow_download_rate` int(1) NOT NULL default '0',
  `use_search` int(1) NOT NULL default '0',
  `allow_comment` char(3) NOT NULL default 'wit',
  `edit_comment` int(1) NOT NULL default '0',
  `edit_comment_own` int(1) NOT NULL default '0',
  `upload_comment_file` int(1) NOT NULL default '0',
  `view_link` int(1) NOT NULL default '0',
  `add_link` int(1) NOT NULL default '0',
  `stat_link` char(3) NOT NULL default 'yes',
  `allow_link_alert` int(1) NOT NULL default '0',
  `allow_link_rate` int(1) NOT NULL default '0',
  `view_news_img` int(1) NOT NULL default '1',
  `allow_members_list` int(1) NOT NULL default '0',
  PRIMARY KEY  (`groupid`)
) ;

#
# Dumping data for table `rafia_groups`
#

INSERT INTO rafia_groups VALUES (1,'������ �����',1,1,'yes',1,1,1,1,1,1,1,1,1,1,'yes',1,1,1,1,1,1,1,1,'yes',1,1,1,1,1,1,1,1,'yes',1,1,1,1,1,'yes',1,1,1,1);
INSERT INTO rafia_groups VALUES (2,'�������',1,1,'wit',1,1,1,'',1,'',1,'',1,1,'yes',1,1,1,1,1,1,1,1,'yes',1,1,1,'',1,1,1,1,'yes','',1,1,1,1,'yes',1,1,1,1);
INSERT INTO rafia_groups VALUES (3,'������',1,'','wit',1,'','','','','','','',1,'','wit','','','','','','','',1,'yes','',1,'','','',1,1,1,'yes','','','',1,1,'wit','',1,1,'');
INSERT INTO rafia_groups VALUES (4,'��������',1,1,'yes',1,1,1,1,1,1,1,'',1,1,'yes',1,1,1,1,1,1,1,1,'yes',1,1,1,1,1,1,1,1,'yes',1,1,1,1,1,'yes',1,1,1,1);

#------------------- TABLE rafia_guestbook -------------------
DROP TABLE IF EXISTS rafia_guestbook; 

CREATE TABLE `rafia_guestbook` (
  `id` int(10) NOT NULL auto_increment,
  `date_time` int(11) NOT NULL default '0',
  `name` varchar(100) NOT NULL default '',
  `email` varchar(50) NOT NULL default '',
  `url` varchar(100) NOT NULL default '',
  `guestbook` text NOT NULL,
  `comment` text NOT NULL,
  `allow` char(3) NOT NULL default 'yes',
  `ip` varchar(15) NOT NULL default '',
  PRIMARY KEY  (`id`)
) ;



#------------------- TABLE rafia_links -------------------
DROP TABLE IF EXISTS rafia_links; 

CREATE TABLE `rafia_links` (
  `id` int(10) NOT NULL auto_increment,
  `cat_id` int(10) NOT NULL default '0',
  `title` varchar(100) NOT NULL default '',
  `date_time` int(11) NOT NULL default '0',
  `name` varchar(100) NOT NULL default '',
  `email` varchar(100) NOT NULL default '0',
  `post` text NOT NULL,
  `url` varchar(100) NOT NULL default '0',
  `allow` char(3) NOT NULL default '',
  `rating_total` int(10) NOT NULL default '0',
  `ratings` int(10) NOT NULL default '0',
  `clicks` int(10) NOT NULL default '0',
  PRIMARY KEY  (`id`)
) ;

INSERT INTO rafia_links VALUES (1,5,'���� ��� �������',1163611446,'admin','webmaster@service4ar.com','����� ����� � ������� ����� ������ �� �������� ������ ���� ��������� � ������ � ���������� � ��� ������','http://www.arabiaone.org','yes','','','');
INSERT INTO rafia_links VALUES (2,5,'���� ������� �������',1163611446,'admin','nobody@arabportal.net','������ ��� ������ ������� ������� � �� ����� ����� 100%','http://www.arabportal.net','yes','','','');
INSERT INTO rafia_links VALUES (3, 5, '���� ����� �����', 1183321345, '����� �����', 'webmaster@service4ar.com', '���� ������ ������� �������� ������ �������', 'http://www.service4ar.com', 'yes', 0, 0, 0);

#------------------- TABLE rafia_menu -------------------
DROP TABLE IF EXISTS rafia_menu; 

CREATE TABLE `rafia_menu` (
  `menuid` int(10) NOT NULL auto_increment,
  `title` varchar(100) default NULL,
  `blockmenu` varchar(100) default NULL,
  `menutitle` varchar(100) default NULL,
  `menuhead` text,
  `menucenter` text,
  `menualign` int(1) NOT NULL default '0',
  `menushow` int(1) NOT NULL default '0',
  `menumodule` varchar(10) NOT NULL default '0',
  `menuorder` int(5) NOT NULL default '0',
  `checkuser` int(1) NOT NULL default '0',
  PRIMARY KEY  (`menuid`),
  KEY `menualign` (`menualign`),
  KEY `menushow` (`menushow`),
  KEY `menumodule` (`menumodule`)
) ;

INSERT INTO rafia_menu VALUES (1, '������� ��������', 'blockmenu', 'mainmenu', '������� ��������', '<li><a href="index.php"> ���� ������� </a>\r\n<li>\r\n<a href="news.php"> ��������� </a>\r\n<li><a href="members.php?action=signup"> ��������</a>\r\n<li>\r\n<a href="download.php"> ���� ������� </a>\r\n<li>\r\n<a href=archive.php>����� �������</a>\r\n<li>\r\n<a href=forum.php> ������� </a>\r\n<li>\r\n<a href=link.php> ���� �������</a>\r\n<li>\r\n<a href=guestbook.php> ��� ������</a>\r\n<li>\r\n<a href=guestbook.php?action=add> ����� �����</a>\r\n<li>\r\n<a href=mail.php> ������</a>\r\n<li>\r\n<a href=members.php> �������</a>', 1, 1, '', 0, 0);
INSERT INTO rafia_menu VALUES (2, '������� ��������', 'blockmenu', 'modules', '������� ��������', '$menu_mods', 1, 1, '', 1, 0);
INSERT INTO rafia_menu VALUES (3, '������� ��������', 'blockmenu', 'pages', '������� ��������', '$pages_menu', 2, 1, '', 0, 0);
INSERT INTO rafia_menu VALUES (4, '����� ������', 'blockmenu', 'mainmenu', '����� ������', '<center><br>\r\n<img border=0 src=images/user_login1.gif width=64 height=64><BR>\r\n       </center><table border=0 width=100%><tr><td width=100%>\r\n <form method=post action=members.php?action=login>\r\n    <tr><td> <font face=tahoma size=2>��������</font></td></tr>\r\n    <tr><td><input type=textbox name=username size=13>\r\n    </td></tr><tr><td> <font face=tahoma size=2 >���� ������</font></td></tr>\r\n    <tr><td><input type=password name=userpass size=13>\r\n    </td></tr><tr><td><input  class=button  type=submit value=����><br>\r\n<a href=javascript:rafiawin("popup.php?action=remind",300,400)><font face=tahoma size=2>����� �������ʿ</font></a>\r\n<br>\r\n\r\n<a href=javascript:rafiawin("popup.php?action=activate",250,350)><font face=tahoma size=2>\r\n����� �������� \r\n </font></a>\r\n    </td></tr></form>\r\n</td></tr></table>', 1, 1, '', 4, 2);
INSERT INTO rafia_menu VALUES (5, '����� �������', 'blockmenu', 'member_box', '����� ��:$member_name', '$isadmin\r\n<li><a href=members.php?action=cp>����� ������</b></font></a><br>\r\n\r\n<li><a href=pm.php>������� ������ : ($pmumrows )</b></font></a><br>\r\n\r\n<li><a href=members.php?action=logout>����� ������</b></font></a><br', 1, 1, '', 3, 1);
INSERT INTO rafia_menu VALUES (6, '�����', 'blockmenu', 'mainmenu', '���� �����', '<center><br>\r\n<img border=0 src=images/search2.gif width=64 height=64><BR>\r\n        <form name=search_form  action=search.php method=post>\r\n  <select name=searchin>\r\n<option selected value="">����� �� �</option>\r\n<option value=rafia_news>�������</option>\r\n<option value=rafia_forum>�������</option>\r\n<option value=rafia_download>�������</option>\r\n<option value=rafia_links>�������</option>\r\n</select>\r\n<br>  <input type=text name=searchfor size=14><br>\r\n  <input class=button  type=submit name="submit" value=���></form>\r\n<a href="search.php?action=search">��� �����</a>\r\n  </center>', 1, 1, '', 1, 0);
INSERT INTO rafia_menu VALUES (7, '��� ���������', 'blockmenu', 'last_topics', '��� ���������', '<script language="javascript">\r\n<!--\r\n if (top.location != document.location) top.location = document.location;\r\nvar Open = ""\r\nvar Closed = ""\r\nfunction preload(){\r\nif(document.images){\r\n        Open = new Image(9,9)\r\n        Closed = new Image(9,9)\r\n        Open.src = "images/folo.gif"\r\n        Closed.src = "images/folc.gif"\r\n}}\r\nfunction showhide(what,what2){\r\nif (what.style.display=="none"){\r\nwhat.style.display="";\r\nwhat2.src=Open.src\r\n}\r\nelse{\r\nwhat.style.display="none"\r\nwhat2.src=Closed.src\r\n}\r\n}\r\n-->\r\n</script>\r\n<body onload="preload()">\r\n\r\n<!-- forum �������  -->\r\n<span id="menu1" onClick="showhide(menu1outline,menu1sign)"  style="cursor:hand">\r\n<img id="menu1sign" src="images/folc.gif" valign="bottom">\r\n<font color="#EE4811" size=2><b>\r\n ������� ������� </b></font></span>\r\n<br>\r\n<span id="menu1outline" style="display:\'none\'">\r\n     $forumtopics\r\n</span>\r\n\r\n<!-- download ���� �������   -->\r\n<span id="menu2" onClick="showhide(menu2outline,menu2sign)"  style="cursor:hand">\r\n<img id="menu2sign" src="images/folc.gif" valign="bottom">\r\n<font color="#EE4811" size=2><b>������� ���� �������</b></font></span><br>\r\n<span id="menu2outline" style="display:\'none\'">\r\n$downloadtopics\r\n</span>\r\n\r\n<!-- links ���� �������  -->\r\n<span id="menu3" onClick="showhide(menu3outline,menu3sign)"  style="cursor:hand">\r\n<img id="menu3sign" src="images/folc.gif" valign="bottom">\r\n<font color="#EE4811" size=2><b>  ���� �������</b></font></span><br>\r\n<span id="menu3outline" style="display:\'none\'">\r\n$linkstopics\r\n</span>', 2, 0, '', 3, 0);
INSERT INTO rafia_menu VALUES (8, '������� ��������', 'blockmenu', 'mainmenu', '������� ��������', '<center><table align=center border=0 cellspacing=0 cellpadding=5>\r\n<form name=mail action=mail.php?action=maillist method=post>\r\n<tr><td><select name="posttybe">\r\n<option selected value="add">��������</option>\r\n<option value="delete">�����</option>\r\n</select></td></tr>\r\n<tr><td><input type=text name=email size=12 value="�� ������ ���"></td></tr><tr>\r\n<td align=center><input class="button"  type=submit name=submit value="�����"></td>\r\n</tr></form></table></center>', 2, 1, '', 2, 2);
INSERT INTO rafia_menu VALUES (9, '����� �����', 'blockmenu', 'mainmenu', '����� �����', '<li><a target=_blank href="http://www.arabportal.net">������� �������</a>\r\n<li><a target=_blank href="http://www.arabiaone.org">���� ��� �������</a>\r\n<li><a href="http://www.php4arab.org/">������ �� ��� ���</a>\r\n<li><a href="http://www.zajilnet.com/forum/index.php">����</a>\r\n<li><a href="http://www.scriptat.com/">�������</a>\r\n<li><a href="http://www.c4arab.com/">�������� �������</a>\r\n<li><a target=_blank href="http://myrosy.com">���� Myrosy</a>\r\n<li><a target=_blank href="http://swalif.net/softs">����� ����</a>', 2, 1, '', 4, 0);
INSERT INTO rafia_menu VALUES (10, '����� ����������', 'blockmenu', 'stat_table', '��������', '<font class="fontablt">��� �������:  $numrowsm </font>\r\n<br>    <font class="fontablt">������� �������:  $numrowsn </font>\r\n<br>    <font class="fontablt">������� �������:  $numrowsf</font>\r\n\r\n<br>    <font class=fontablt>������� ������� :  $numrowsd </font>\r\n<br>    <font class=fontablt>������� ���������:  $numrowsg  </font>\r\n<br>    <font class=fontablt>������� �������:  $numrowsl</font>\r\n\r\n<br>    <font class=fontablt>������� ������:  $numrowsc</font>', 1, 1, '', 4, 0);
INSERT INTO rafia_menu VALUES (11, '����� �������', 'blockmenu', 'topics_cat_menu', '����� �������', '<li>\r\n<a href=news.php?action=list&cat_id=$menid>\r\n                  $mentitle</a>', 1, 1, '', 1, 0);
INSERT INTO rafia_menu VALUES (12, '��� �������', 'upblock', 'archive_menu', '��� �������', '<li><a href=news.php?action=view&id=$menlistid>$menlisttitle</a><br>', 1, 1, '', 3, 0);
INSERT INTO rafia_menu VALUES (13, '�������', 'blockmenu', 'poll_menu', '', '', 2, 1, '', 0, 0);
INSERT INTO rafia_menu VALUES (14, '���� ������� �����', 'blockmenu', 'download_menu', '������ �����', '<li><a href=download.php?action=view&id=$id>$title</a><br>', 2, 1, 'download', 3, 0);
INSERT INTO rafia_menu VALUES (15, '��� �������', 'blockmenu', 'new_download_menu', '��� �������', '<li><a href=download.php?action=view&id=$id>$title</a><br>', 2, 1, 'download', 1, 0);
INSERT INTO rafia_menu VALUES (16, '���������� ������ �������', 'blockmenu', 'online_menu', '���������� ������', '<font class=fontablt> ���������� ������ :$online\r\n<br>\r\n�� ������ : $not_user\r\n<br>\r\n�� �������  :  $user_online\r\n<br>\r\n��� �������� : $totalCount\r\n<br>\r\n��� �������� ����� :  $dayCount\r\n<br>\r\n���� ��� ������ ��� :  $mostCount\r\n<br>\r\n�� ����� : $mosttime \r\n\r\n</font>', 1, 1, '', 5, 0);
INSERT INTO rafia_menu VALUES (17, '����� �����', 'blockmenu', 'menu_ads', '�������', '', 2, 1, '', 0, 0);
INSERT INTO rafia_menu VALUES (18, '������ ���������', 'blockmenu', 'mainmenu', '������ ���������', '<!--INC dir="block" file="random_wisdom.php" -->', 2, 1, '', 0, 0);
INSERT INTO rafia_menu VALUES (19, '������� ������', 'blockmenu', 'mainmenu', '������� ������', '<!--INC dir="block" file="hejri_calendar.php" -->', 2, 1, '', 0, 0);

#------------------- TABLE rafia_messages -------------------
DROP TABLE IF EXISTS rafia_messages; 

CREATE TABLE rafia_messages (
  msgid bigint(20) NOT NULL auto_increment,
  mailus tinyint(1) NOT NULL default '0',
  userbox tinyint(4) NOT NULL default '0',
  msgbox tinyint(4) NOT NULL default '0',
  msgdate int(11) NOT NULL default '0',
  msgisread tinyint(1) NOT NULL default '1',
  msgtitle varchar(128) default NULL,
  message text,
  ufromid int(32) NOT NULL default '0',
  fromname varchar(100) NOT NULL default '0',
  utoid int(10) NOT NULL default '0',
  toname varchar(100) NOT NULL default '',
  PRIMARY KEY  (msgid)
);

#------------------- TABLE rafia_moderate -------------------
DROP TABLE IF EXISTS rafia_moderate; 

CREATE TABLE `rafia_moderate` (
  `id` int(10) NOT NULL auto_increment,
  `moderatecatid` int(10) NOT NULL default '0',
  `modadmin` int(10) NOT NULL default '0',
  `moderateid` int(11) NOT NULL default '0',
  `moderatename` varchar(100) NOT NULL default '',
  `can_close` tinyint(1) NOT NULL default '0',
  `can_sticky` tinyint(1) NOT NULL default '0',
  `can_edit` tinyint(1) NOT NULL default '0',
  `can_delete` tinyint(1) NOT NULL default '0',
  `can_move` tinyint(1) NOT NULL default '0',
  PRIMARY KEY  (`id`)
) ;



#------------------- TABLE rafia_mods -------------------
DROP TABLE IF EXISTS rafia_mods; 

CREATE TABLE `rafia_mods` (
  `id` tinyint(4) NOT NULL auto_increment,
  `mod_name` varchar(30) NOT NULL default '',
  `mod_title` varchar(255) NOT NULL default '',
  `mod_user` tinyint(1) NOT NULL default '0',
  `mod_sys` tinyint(1) NOT NULL default '1',
  `left_menu` int(1) NOT NULL default '0',
  `right_menu` int(1) NOT NULL default '1',
  `middle_menu` int(1) NOT NULL default '1',
  `mnueid` text NOT NULL,
  `themeid` int(10) NOT NULL default '0',
  `adsH` tinyint(1) NOT NULL default '1',
  `adsF` tinyint(1) NOT NULL default '0',
  PRIMARY KEY  (`id`,`mod_name`)
) ;


INSERT INTO rafia_mods VALUES (1, 'Top10', '���� 10', 0, 1, 1, 1, 0, '1,2,3,4,6,7,8,9,10,11,14,15,16,17,18,19', 1, 1, 0);
INSERT INTO rafia_mods VALUES (2, 'map', '����� ������', 0, 1, 1, 1, 0, '1,2,3,4,6,7,8,9,10,11,14,15,16,17,18,19', 1, 1, 0);

#------------------- TABLE rafia_mods_settings -------------------
DROP TABLE IF EXISTS rafia_mods_settings; 

CREATE TABLE `rafia_mods_settings` (
  `set_id` int(9) NOT NULL auto_increment,
  `set_mod` varchar(30) NOT NULL default '',
  `set_text` varchar(255) NOT NULL default '',
  `set_var` varchar(255) default NULL,
  `set_val` text,
  `set_order` tinyint(4) default NULL,
  `set_type` tinyint(4) default NULL,
  PRIMARY KEY  (`set_id`)
) ;


INSERT INTO rafia_mods_settings VALUES (1, 'Top10', '��� ��������� ���� �����', 'Top_DeaDSouL', '10', 0, 3);
INSERT INTO rafia_mods_settings VALUES (2, 'map', '����� ����� ������� �� �������', 'use_news', '1', 0, 5);
INSERT INTO rafia_mods_settings VALUES (3, 'map', '����� ����� ������� �� �������', 'use_forum', '1', 0, 5);
INSERT INTO rafia_mods_settings VALUES (4, 'map', '����� ����� ���� ������� �� �������', 'use_download', '1', 0, 5);
INSERT INTO rafia_mods_settings VALUES (5, 'map', '����� ����� ���� ������� �� �������', 'use_link', '1', 0, 5);
INSERT INTO rafia_mods_settings VALUES (6, 'map', '����� ����� ������� �������� �� �������', 'use_mods', '1', 0, 5);
INSERT INTO rafia_mods_settings VALUES (7, 'map', '����� ����� ������� �������� �� �������', 'use_pages', '1', 0, 5);


#------------------- TABLE rafia_mods_templates -------------------
DROP TABLE IF EXISTS rafia_mods_templates; 

CREATE TABLE `rafia_mods_templates` (
  `id` int(10) NOT NULL auto_increment,
  `main` tinyint(1) NOT NULL default '0',
  `themeid` int(10) NOT NULL default '0',
  `sub` int(10) NOT NULL default '0',
  `modid` int(10) NOT NULL default '0',
  `modname` varchar(50) NOT NULL default '',
  `theme` varchar(30) NOT NULL default '',
  `temp_title` varchar(100) NOT NULL default '',
  `template` longtext NOT NULL,
  PRIMARY KEY  (`id`)
) ;



#------------------- TABLE rafia_news -------------------
DROP TABLE IF EXISTS rafia_news; 

CREATE TABLE `rafia_news` (
  `id` int(10) NOT NULL auto_increment,
  `cat_id` int(10) NOT NULL default '0',
  `title` varchar(100) NOT NULL default '',
  `date_time` int(11) NOT NULL default '0',
  `userid` int(10) NOT NULL default '0',
  `name` varchar(100) NOT NULL default '',
  `news_head` text NOT NULL,
  `post` text NOT NULL,
  `allow` char(3) NOT NULL default '',
  `inindex` int(1) NOT NULL default '1',
  `main` tinyint(1) NOT NULL default '0',
  `inmenu` int(1) NOT NULL default '1',
  `catmig` int(1) NOT NULL default '0',
  `ues_editor` int(1) NOT NULL default '0',
  `reader` int(10) default '0',
  `c_comment` int(10) default '0',
  `sticky` tinyint(5) NOT NULL default '0',
  `close` tinyint(1) NOT NULL default '0',
  `lastuserid` int(10) NOT NULL default '0',
  `timestamp` int(10) NOT NULL default '0',
  `uploadfile` int(10) NOT NULL default '0',
  `edit_by` varchar(255) NOT NULL default '0',
  PRIMARY KEY  (`id`)
) ;

INSERT INTO rafia_news VALUES (1,1,'������� ������� 2.1 ������� ������',1192525896,1,'����� �����','��� ���� ������ ������\r\n������ ����� ����� ���� � ������\r\n� ������ � ������ ��� ���� �������� � �������� ����� � ����� ���� � ��� ��� � ���� ������ ... ��� ��� :-\r\n���� ������ � ������ �� ���� ��� ������ ������� ������ �� ������� ������� ������ ���� ���� ����� 2.1 � ��� ����� �� ������� �� ���� ��������� ��������� ��� ����1 � ����2\r\n� ��� ��� ���� ���� ��������� ���� ���� :-','[color=FA0309]�� ������� ������[/color]\r\n* ����� ����� ������� �������� ���� ������� ���������\r\n* ����� ����� ������ � ���� ���� �������\r\n* ����� ����� ����� ��� ���� � ����� ���� ��� �������� ����\r\n* ����� ����� ������� �������� �� ������ ��������\r\n* ����� ����� ������� �������� �� ������� ��������\r\n* ����� ����� ����� ��� ���� (���� / ����) �� ������� ��������\r\n* ����� ��� ���� � ���� ������ ����� �����\r\n* ����� ������ �� �������� �������\r\n* ������ �� ��������� �� ���� ����� �������\r\n\r\n[color=FA0309]�� ������� ������ 1 � ������2[/color]\r\n* ����� ����� ��� ������� �� ������ �������� � ��� �������\r\n* ����� ����� ��� ����� � �������\r\n* ����� ��� ������� ������� ������� � ��� �������\r\n* ����� ��� ������� �������� ��� ����� ����� � ����� ������ � �����\r\n* ��� ����� ������� �������� �� ��� �������� ������ �������\r\n* ����� ������� ����� �������� �� ������� �������� �� ����� ���� ���� ��� ����\r\n* ����� ������ ����� ������� ������� ����� ���� �� �����\r\n* ������� ����� ������� ������� �������\r\n* ����� ����� ������ ����� ������� �� ������ ��������\r\n* ����� ����� ��� ��������� ��� ��� ����� �� �������\r\n* ����� ����� ���������� ����� �� �������\r\n* ����� ������ ����� ���� ���� � ����� ���\r\n* ����� ��� ������� ������ �� ����� ���� ������ ����� ��������\r\n* ����� ����� ������� ������ ��������\r\n* ����� ����� ������� � ����� ���� RSS �������� �������\r\n* ����� ����� ����� ������ �� ���� ����� �������\r\n* ����� ����� ��� ������� ��� ��� ������ ���� ������\r\n* ����� ����� ����� ����� ���� PDF ������� �� ������ Acrobat reader\r\n* ����� ����� ����� �������� �� ����� ������� ��� ����� ����������\r\n* ����� ����� ������ �� ����� ������ �� ���� ������ ���������� �� �� ���� ���� ������\r\n* ����� ����� ����� ( ���� �� ����� ���� ������ )\r\n* ����� ���� ������ ���� �� ���� �� ���� ������ �� ����� ���\r\n����� ��� �� ������� ������ ����� �������\r\n* ����� ��� ������� ���� �������/������� ����� ������\r\n* ����� ������� ��� ������ �� ������ ������ ������\r\n* ����� ������� ��� ����� ������\r\n','yes',1,1,1,'','',2,'','','',1,1192525896,2,'');


#------------------- TABLE rafia_online -------------------
DROP TABLE IF EXISTS rafia_online; 

CREATE TABLE `rafia_online` (
  `id` int(10) NOT NULL auto_increment,
  `timestamp` int(15) NOT NULL default '0',
  `onlineip` varchar(40) NOT NULL default '',
  `onlinefile` varchar(100) NOT NULL default '',
  `onlinepage` varchar(100) NOT NULL default '',
  `onlineSID` varchar(32) NOT NULL default '',
  `user_online` varchar(100) NOT NULL default '0',
  `useronlineid` int(11) NOT NULL default '0',
  PRIMARY KEY  (`onlineSID`),
  KEY `timestamp` (`timestamp`),
  KEY `user_online` (`user_online`),
  KEY `id` (`id`),
  KEY `onlineip` (`onlineip`)
) ;


#------------------- TABLE rafia_pages -------------------
DROP TABLE IF EXISTS rafia_pages; 

CREATE TABLE rafia_pages (
  id int(10) unsigned NOT NULL auto_increment,
  name varchar(30) collate latin1_general_ci NOT NULL default '',
  popup int(1) NOT NULL default '0',
  checkuser int(1) NOT NULL default '0',
  active int(1) default '0',
  pagetext longtext collate latin1_general_ci NOT NULL,
  ishtml int(1) NOT NULL default '0',
  count int(10) NOT NULL default '0',
  showcount tinyint(1) NOT NULL default '0',
  showinmenu tinyint(1) NOT NULL default '1',
  PRIMARY KEY  (id)
);

INSERT INTO rafia_pages VALUES (1, '���� �������', 0, 0, 1, '<br>\r\n<br>\r\n<h3>��� ������ �������� ���</h3>\r\n<br>\r\n<br>\r\n', 0, 0, 1, 1);



#------------------- TABLE rafia_pollanswer -------------------
DROP TABLE IF EXISTS rafia_pollanswer; 

CREATE TABLE `rafia_pollanswer` (
  `pollid` int(11) NOT NULL auto_increment,
  `quesid` int(11) NOT NULL default '0',
  `text` varchar(255) NOT NULL default '',
  `results` int(10) NOT NULL default '0',
  PRIMARY KEY  (`pollid`)
) ;



#------------------- TABLE rafia_pollques -------------------
DROP TABLE IF EXISTS rafia_pollques; 

CREATE TABLE `rafia_pollques` (
  `quesid` int(11) NOT NULL auto_increment,
  `question` varchar(255) NOT NULL default '',
  `stat` int(1) NOT NULL default '0',
  PRIMARY KEY  (`quesid`)
) ;



#------------------- TABLE rafia_search_res -------------------
DROP TABLE IF EXISTS rafia_search_res; 

CREATE TABLE `rafia_search_res` (
  `id` mediumint(9) NOT NULL auto_increment,
  `search_id` text NOT NULL,
  `search_word` varchar(100) default NULL,
  `search_in` varchar(100) default NULL,
  `search_date` int(11) NOT NULL default '0',
  `from_date` int(11) NOT NULL default '0',
  `search_order` varchar(4) NOT NULL default 'desc',
  `search_max` int(10) NOT NULL default '0',
  `user_id` mediumint(10) default '0',
  `search_ip` varchar(64) default NULL,
  PRIMARY KEY  (`id`)
) ;


#------------------- TABLE rafia_sessions -------------------
DROP TABLE IF EXISTS rafia_sessions; 

CREATE TABLE `rafia_sessions` (
  `ses_id` varchar(32) NOT NULL default '',
  `ses_time` int(11) NOT NULL default '0',
  `ses_start` int(11) NOT NULL default '0',
  `ses_value` text NOT NULL,
  PRIMARY KEY  (`ses_id`)
) ;


#------------------- TABLE rafia_settings -------------------
DROP TABLE IF EXISTS rafia_settings; 

CREATE TABLE `rafia_settings` (
  `id` smallint(5) unsigned NOT NULL auto_increment,
  `modulname` varchar(20) NOT NULL default '0',
  `titletype` int(10) NOT NULL default '0',
  `settingtype` int(2) NOT NULL default '0',
  `title` varchar(200) NOT NULL default '0',
  `variable` varchar(100) NOT NULL default '',
  `value` text,
  `options` int(10) NOT NULL default '0',
  PRIMARY KEY  (`id`)
);

INSERT INTO rafia_settings VALUES (1,0,1,1,'_SITE_TITLE','sitetitle','������� �������',30);
INSERT INTO rafia_settings VALUES (2,0,1,1,'_EMAIL','sitemail','xxxx@mail.com',30);
INSERT INTO rafia_settings VALUES (3,0,1,1,'_SITE_URL','siteURL','http://www.xxxx.com',30);
INSERT INTO rafia_settings VALUES (4,0,2,2,'_DATE_TYPE','hijri_date','m',5);
INSERT INTO rafia_settings VALUES (5,0,2,4,'_MEMEBER_REG_STATE','newuserallow','yes',1);
INSERT INTO rafia_settings VALUES (6,'link','','','_WEBLINK_MENU','link_menuid','1,2,3,4,5,6,8,9,11,12,16','');
INSERT INTO rafia_settings VALUES (7,0,2,4,'_USE_IMAGE_IN_SIG','use_sign_images','no',3);
INSERT INTO rafia_settings VALUES (8,0,2,6,'_GUSET_CAN_POST','gballow','wit',2);
INSERT INTO rafia_settings VALUES (9,'link',3,'','_WEBLINK_PERPAGE','linkperpagelist','20',50);
INSERT INTO rafia_settings VALUES (10,'news',1,'','_MAX_LENTH_IN_NEWS_FIRST_PART','txtcount1','500',10);
INSERT INTO rafia_settings VALUES (11,'news',1,'','_MAX_LENTH_IN_2_PART','txtcount2','30000',10);
INSERT INTO rafia_settings VALUES (12,'forum',1,'','_MAX_LENTH_IN_TOPIC_TITLE','txtcount3','30000',10);
INSERT INTO rafia_settings VALUES (13,'down',1,'','_MAX_DOWNLOAD_REVIEW','txtcount4','30000',10);
INSERT INTO rafia_settings VALUES (14,0,1,'','_MAX_DEIS_LINK_GUEST','txtcount5','1000',10);
INSERT INTO rafia_settings VALUES (15,0,1,'','_MAX_IN_POSTS','txtcount6','30000',10);
INSERT INTO rafia_settings VALUES (16,0,1,4,'_MAX_LENTH_IN_SIG','txtcount7','300',10);
INSERT INTO rafia_settings VALUES (17,0,3,6,'_GUEST_PERPAGE','gbperpagelist','25',50);
INSERT INTO rafia_settings VALUES (18,'news',3,'','_NEWS_PERPAGE','newsperpagelist','12',50);
INSERT INTO rafia_settings VALUES (19,0,3,6,'_NEWS_IN_MAIN','showmax','6',20);
INSERT INTO rafia_settings VALUES (20,'news',3,'','_NEWS_POSTS_IN_PERPAGE','newsperpagecomment','10',30);
INSERT INTO rafia_settings VALUES (21,'news',3,'','_NUMBER_OF_NEWS_IN','showmaxr','20',30);
INSERT INTO rafia_settings VALUES (22,0,1,3,'_ACTIVE_TITLE','subject_activate','����� �������� ��� ���� $apt->sitetitle',40);
INSERT INTO rafia_settings VALUES (23,0,1,'','_MAX_LENTH_IN_TOPIC_TITLE','max_title_cut','100',5);
INSERT INTO rafia_settings VALUES (24,0,1,'','_UPLOAD_PATH','upload_path','upload','');
INSERT INTO rafia_settings VALUES (25,0,4,3,'_FEEDBACK_TITLES','mailsubject','�������\r\n���\r\n������� ��� ���',6);
INSERT INTO rafia_settings VALUES (26,0,2,3,'_SENDTOME_BY','sendme_by','cp',8);
INSERT INTO rafia_settings VALUES (27,0,1,3,'_ALERT_NEW_MSG','subject_alert','��� $name ��� ��� �������� $titlepost',40);
INSERT INTO rafia_settings VALUES (28,0,1,4,'_MAX_LENTH_IN_PMSG','txtcount8','2000',10);
INSERT INTO rafia_settings VALUES (29,0,1,4,'_MAX_PMSG','maxpmuser','50',10);
INSERT INTO rafia_settings VALUES (30,'forum',3,'','_FORUM_POSTS_PERPAGE','forumperpagecomment','10',30);
INSERT INTO rafia_settings VALUES (31,'forum',3,'','_CAT_LISTTHRAEDS_PERPAGE','forumperpagelist','30',50);
INSERT INTO rafia_settings VALUES (32,'forum',1,'','_MAX_TIME_EDIT','timeallowedit','3600',10);
INSERT INTO rafia_settings VALUES (33,'forum',1,'','_EXIT_ALLOWED','forumfileupload','jpg,gif,png,php,zip,pdf','');
INSERT INTO rafia_settings VALUES (34,'forum',1,'','_MAX_SIZE_FORUM_ATTACHMENT','forumfilemxsize','300',10);
INSERT INTO rafia_settings VALUES (35,'down',3,'','_FORUM_POSTS_PERPAGE','downperpagecomment','10',50);
INSERT INTO rafia_settings VALUES (36,'down',3,'','_DOWNLOAD_PERPAGE','downperpagelist','16',50);
INSERT INTO rafia_settings VALUES (37,'news',1,'','_EXS_IMG_ALLOWED','newsfileupload','jpg,gif,png','');
INSERT INTO rafia_settings VALUES (38,'down',1,'','_EXIT_ALLOWED','downfileupload','zip,rar,tar,gz','');
INSERT INTO rafia_settings VALUES (39,'news',1,'','_MAX_ADD_IMAGE_NEWS','newsfilemxsize','100','');
INSERT INTO rafia_settings VALUES (40,0,4,'','_SEND_TO_FRINDE_CONTENT','sendpage','_SEND_TO_FRINDE_SUB',6);
INSERT INTO rafia_settings VALUES (41,'down',1,'','_MAX_DOWNLOAD_DEIS','txtcount9','300',10);
INSERT INTO rafia_settings VALUES (42,'down','','','_DOWNLOAD_MENU','down_menuid','1,2,3,4,5,6,8,10,12,14,15',10);
INSERT INTO rafia_settings VALUES (43,'news','','','_NEWS_MENUS','news_menuid','1,2,3,4,5,6,8,9,10,11,12,16,18','');
INSERT INTO rafia_settings VALUES (44,0,1,2,'_HOURS_GM','dtimehour','2',4);
INSERT INTO rafia_settings VALUES (46,'down',1,'','_MAX_DOWNLOAD_SZIE','downfilemxsize','500','');
INSERT INTO rafia_settings VALUES (47,0,1,3,'_LOGIN_TITLE','subject_remind','������ ����� �����',40);
INSERT INTO rafia_settings VALUES (48,0,1,3,'_ALERT_BROKEN_URL','subject_alertlink','����� �� ���� �����',40);
INSERT INTO rafia_settings VALUES (49,0,1,3,'_SEND_TO_FRINDE_TITLE','subject_sendpage','����� �� �����',40);
INSERT INTO rafia_settings VALUES (50,0,2,4,'_USE_LINKS_IN_SIG','use_sign_linkcode','yes',3);
INSERT INTO rafia_settings VALUES (51,0,2,4,'_USE_BBCODE_IN_SIG','use_sign_fontcode','yes',3);
INSERT INTO rafia_settings VALUES (52,'link',1,'','_MAX_WEBLINK_DEIS','txtcount10','500',10);
INSERT INTO rafia_settings VALUES (53,0,1,5,'_MAX_COMMENT_SZIE','commentfilemxsize','1000','');
INSERT INTO rafia_settings VALUES (54,0,1,5,'_EXT_COMMENT','commentfileupload','jpg,gif,zip,php,doc,txt,asx,mp3,js,ram,html,htm',40);
INSERT INTO rafia_settings VALUES (55,0,1,5,'_SHOW_COLORED','sizephpcode','10000','');
INSERT INTO rafia_settings VALUES (56,0,1,5,'_SMALL_IMAGE_IF','resizedimage','450','');
INSERT INTO rafia_settings VALUES (57,0,1,3,'_ALERT_NEW_MSG','alert_pm','����� ����� ����',40);
INSERT INTO rafia_settings VALUES (58,'news',4,'','_HTML_TAGS','html_tags','<P><A><IMG><TABLE><TBODY><TR><TD><FONT>\r\n<UL><LI><OL><STRONG><EM><U><B><BR>',6);
INSERT INTO rafia_settings VALUES (59,'news',2,'','_USE_ADS_IN_NEWS','use_adsin_news','yes',3);
INSERT INTO rafia_settings VALUES (60,'forum',2,'','_USE_ADS_IN_FORUM','use_adsin_forum','yes',3);
INSERT INTO rafia_settings VALUES (61,'down',2,'','_USE_ADS_IN_WEBLINK','use_adsin_download','yes',3);
INSERT INTO rafia_settings VALUES (62,0,'','','','index_menuid','1,2,3,4,5,6,8,9,10,11,12,13,16,17,18,19','');
INSERT INTO rafia_settings VALUES (63,'news',1,'','_DEFULT_ALIGN_FOR_IMG_DEFULT_ALIGN_FOR_IMG','CatMagealign','right',10);
INSERT INTO rafia_settings VALUES (64,'news',5,'','_USE_HTML_EDITOR','ues_editor','','');
INSERT INTO rafia_settings VALUES (65,'news',5,'','_USE_LEFT_MENU','news_left_menu','1','');
INSERT INTO rafia_settings VALUES (66,'down',5,'','_USE_LEFT_MENU','down_left_menu','1','');
INSERT INTO rafia_settings VALUES (67,'link',5,'','_USE_LEFT_MENU','link_left_menu','1','');
INSERT INTO rafia_settings VALUES (68,0,3,6,'_NEWS_IN_MAIN_COL','indexColcount','2',3);
INSERT INTO rafia_settings VALUES (69,'news',3,'','_CAT_COL_VIEW','newsColcount','2',4);
INSERT INTO rafia_settings VALUES (70,'link',3,'','_CAT_COL_VIEW','linkColcount','2',4);
INSERT INTO rafia_settings VALUES (71,'down',3,'','_CAT_COL_VIEW','downColcount','2',4);
INSERT INTO rafia_settings VALUES (72,'hidden','','','','version','Arab Portal v2.1 stable','');
INSERT INTO rafia_settings VALUES (73,0,1,7,'_KEYWORDS','keywords','������� �������',20);
INSERT INTO rafia_settings VALUES (74,0,1,7,'_DESCRIPTION','Description','������� ������� -Powered by: Arab Portal v2.1, Copyright� 2007',40);
INSERT INTO rafia_settings VALUES (75,'news',2,'','_POST_ORDER_BY','news_order_by','date_time',6);
INSERT INTO rafia_settings VALUES (76,'forum',2,'','_POST_ORDER_BY','forum_order_by','timestamp',6);
INSERT INTO rafia_settings VALUES (77,0,2,1,'_TURN_OFF','turn_off','no',3);
INSERT INTO rafia_settings VALUES (78,0,1,1,'_TURN_OFF_MSG','turn_off_msg','������ ���� ����� ������� ... �� �����',50);
INSERT INTO rafia_settings VALUES (79,0,10,'','_THEME','theme','arabportal','');
INSERT INTO rafia_settings VALUES (80,0,2,6,'_MAIN_PAGE_FORM','main_form','formB',9);
INSERT INTO rafia_settings VALUES (81,0,1,6,'_NEWS_IN_CAT','showcat','1,6',25);
INSERT INTO rafia_settings VALUES (82,'hidden','','','','mail_msg','������ ����� ����� ���� ������� \r\n','');
INSERT INTO rafia_settings VALUES (83,'hidden','','','','mail_vars','50:=:0:=:xxx@mail.com:=:','');
INSERT INTO rafia_settings VALUES (84,0,4,6,'_BAD_WORDS','bad_words','���',6);
INSERT INTO rafia_settings VALUES (85,0,4,6,'_PAN_IP','pan_ip','',6);
INSERT INTO rafia_settings VALUES (86,0,3,1,'_COUNT_MIDDLE_MENU','count_middle_menu','2',4);
INSERT INTO rafia_settings VALUES (87,0,2,5,'_USE_GD_THUMB','use_gd_thumb','yes',3);
INSERT INTO rafia_settings VALUES (88,'hidden','','','','captcha_code','1190721969:|:888850','');
INSERT INTO rafia_settings VALUES (89,'news',1,'','_DEFULT_GD_WIDTH_IMG','thumb_width','100',10);
INSERT INTO rafia_settings VALUES (90,0,2,7,'_HTML_LINKS','html_links','yes',3);

#------------------- TABLE rafia_smileys -------------------
DROP TABLE IF EXISTS rafia_smileys; 

CREATE TABLE `rafia_smileys` (
  `id` int(11) NOT NULL auto_increment,
  `code` varchar(50) default NULL,
  `smile` varchar(100) default NULL,
  `smilename` varchar(75) default NULL,
  PRIMARY KEY  (`id`)
) ;

INSERT INTO rafia_smileys VALUES (1,':TON:','tongue.gif','TO');
INSERT INTO rafia_smileys VALUES (2,':COO:','cool.gif','cool');
INSERT INTO rafia_smileys VALUES (3,':DRY:','dry.gif','dry');
INSERT INTO rafia_smileys VALUES (4,':ARB:','Arabian.gif','����');
INSERT INTO rafia_smileys VALUES (5,':MAD:','mad.gif','mad');
INSERT INTO rafia_smileys VALUES (6,':WOW:','ohmy.gif','ohmy');
INSERT INTO rafia_smileys VALUES (7,':HuH:','huh.gif','huh');
INSERT INTO rafia_smileys VALUES (8,':SAD:','sad.gif','sad');
INSERT INTO rafia_smileys VALUES (9,':SMI:','smile.gif','smile');
INSERT INTO rafia_smileys VALUES (11,':WUB:','wub.gif','wub');


#------------------- TABLE rafia_spam -------------------
DROP TABLE IF EXISTS rafia_spam; 

CREATE TABLE `rafia_spam` (
  `spamip` varchar(32) NOT NULL default '0',
  `spamtable` varchar(30) NOT NULL default '',
  `spamtime` int(10) NOT NULL default '0',
  PRIMARY KEY  (`spamip`)
) ;


#------------------- TABLE rafia_templates -------------------
DROP TABLE IF EXISTS rafia_templates; 

CREATE TABLE `rafia_templates` (
  `id` int(10) unsigned NOT NULL auto_increment,
  `theme` varchar(100) NOT NULL default '',
  `name` varchar(30) NOT NULL default '',
  `temptype` int(2) NOT NULL default '0',
  `template` longtext NOT NULL,
  PRIMARY KEY  (`id`)
);

INSERT INTO rafia_templates VALUES (1,'arabportal','link_cat',5,'<table border=\"0\" cellpadding=\"0\" cellspacing=\"0\" width=\"100%\" >\r\n         <tr>\r\n           <td width=\"100%\" style=\"padding: 3\"><font class=fontht><img border=\"0\" src=\"images/b1.gif\" align=\"middle\" width=\"8\" height=\"8\">  <a href=$PHP_SELF?action=list&cat_id=$id> $title</a></font>\r\n<span class=fontablt>           <img border=\"0\" src=\"images/topics.gif\" align=\"middle\" alt=\"��� ��������\">\r\n           <font color=\"#C0C0C0\">[$numrows]\r\n</font></span></td>\r\n         </tr>\r\n         <tr>\r\n           <td width=\"100%\" class=fontablt><font color=\"#808080\">    $dsc</font></td>\r\n         </tr>\r\n       </table>');
INSERT INTO rafia_templates VALUES (2,'arabportal','forum_topic_list',3,'<tr>\r\n				<td class=\"forum_alt2\">\r\n				<img border=0 src=themes/$themepath/$imgonoff></td>\r\n				<td class=\"forum_alt1\">$rep_icon</td>\r\n				<td width=\"100%\" class=\"forum_alt2\">\r\n<a href=$PHP_SELF?action=view&id=$id&cat_id=$cat_id>\r\n\r\n<font color=\"#34597D\">$title</font>\r\n\r\n </a>$pagenum\r\n </td>\r\n				<td  class=\"forum_alt1\" align=\"center\">$numrows</td>\r\n				<td class=\"forum_alt2\" align=\"center\">$name</td>\r\n				<td class=\"forum_alt1\" align=\"center\">$reader</td>\r\n				<td class=\"forum_alt2\"  width=\"200\" nowrap>\r\n				<span class=\"small\">����� ��� ������: <br>\r\n				$lastdate <br>\r\n				������ :  $lastposter </span>\r\n				</td>\r\n			</tr>');
INSERT INTO rafia_templates VALUES (3,'arabportal','news_topic_list',2,'<table border=\"0\" cellpadding=\"0\" cellspacing=\"0\" width=\"95%\">\r\n	<tr>\r\n		<td height=\"28\">\r\n<div class=news_title>\r\n	<img border=\"0\" src=\"themes/apt/news_icon.gif\" width=\"12\" height=\"12\"> <a href=\"$news_link\">$title</a></div>\r\n	\r\n		</td>\r\n	</tr>\r\n  <tr>\r\n    <td width=\"100%\">\r\n    <table border=\"0\" cellpadding=\"2\" style=\"border-collapse: collapse\" width=\"100%\" id=\"AutoNumber1\" class=\"article_info\">\r\n      <tr>\r\n        <td align=\"right\" width=\"100%\">\r\n	<div class=\"article_info\">	<img border=\"0\" src=\"themes/apt/info.gif\" width=\"13\" height=\"18\"> ������: <a href=\"members.php?action=info&userid=$userid\">$name</a> ������: $date </div></td>\r\n        <td nowrap align=\"left\" colspan=\"3\">  </td>\r\n      </tr>\r\n    </table>\r\n    </td>\r\n  </tr>\r\n  <tr>\r\n    <td width=\"100%\" style=\"padding-top: 5; padding-bottom: 5; text-align:justify\">\r\n$newsimage <font class=\"home_text\">$news_head </font>\r\n		</td>\r\n  </tr>\r\n  <tr>\r\n    <td align=\"right\" width=\"100%\" class=\"info_bar2\" style=\"padding-top: 5; padding-bottom: 5\">\r\n    <p align=\"right\"><a href=\"$news_link\">\r\n	<img border=\"0\" src=\"themes/apt/more.gif\" width=\"56\" height=\"13\" align=\"right\"></a>\r\n<div class=\"article_info\">	&nbsp; \r\n	������: $reader &nbsp;&nbsp;&nbsp;���������: $numrows </div></td>\r\n  </tr>\r\n  <tr>\r\n    <td width=\"100%\">$pagenum </td>\r\n  </tr>\r\n</table>\r\n<hr color=\"#C0C0C0\" width=\"95%\" size=\"1\" style=\"border-style: dotted; border-width: 1px\">');
INSERT INTO rafia_templates VALUES (4,'arabportal','forum_table',3,'<table border=\"0\" width=\"95%\" id=\"table4\" cellspacing=\"1\" cellpadding=\"0\">\r\n			<tr>\r\n				<td width=\"100%\" class=\"forum_header\" style=\"text-align: right\">\r\n				 $rep_icon � $title</td>\r\n			</tr>\r\n			<tr>\r\n				<td width=\"100%\" class=\"forum_alt3\">\r\n				<table border=\"0\" width=\"100%\" id=\"table16\" >\r\n					<tr>\r\n						<td width=\"20%\" class=\"forum_alt1\" valign=\"top\">\r\n\r\n<span class=small>\r\n������: <a href=\"members.php?action=info&userid=$userid\">$username</a><br>\r\n$usertitle<br>$userimgtitle<br>\r\n$avatar_pic\r\n������� : $datetime<br>\r\n��������� :  $allposts <br>\r\n  <a href=\"mail.php?action=sendtousers&userid=$userid\">\r\n <img border=\'0\' src=\'themes/$themepath/email.gif\' alt=\'������\'>\r\n  </a>\r\n<a href=$homepage target=_blank><img border=\'0\' src=\'themes/$themepath/home.gif\' alt=\'������ ������\' ></a>\r\n<br>\r\n</span>\r\n</td>\r\n      \r\n\r\n						<td width=\"80%\" valign=\"top\" class=\"normal\" colspan=\"2\"><span class=small><font color=\"#808080\">\r\n						&nbsp;��� ��  $date -   ������ : $reader\r\n    -   ���� : $c_comment </font>\r\n\r\n    </span>\r\n						<hr color=\"#7394B6\" size=\"1\">\r\n\r\n                 $post\r\n                 \r\n                 <br>\r\n$upload_file<br>\r\n      <hr color=\"#7394B6\" size=\"1\">\r\n       <center>$signature</center>\r\n        </td>\r\n					</tr>\r\n					<tr>\r\n						<td width=\"20%\" class=\"small\" valign=\"top\" align=\"center\">\r\n						 $ip_address </td>\r\n						<td width=\"40%\" valign=\"top\" class=small>\r\n                           $adminJump\r\n      </td>\r\n						<td width=\"40%\" valign=\"top\" align=\"left\">\r\n\r\n               <a href=\"pm.php?action=sendmsg&id=$userid\">\r\n               <img border=\"0\" src=\"themes/$themepath/pm.gif\">\r\n               </a>\r\n     \r\n      <a href=\"forum.php?action=edit&id=$id\"><img border=\"0\" src=\"themes/$themepath/edit.gif\"></a>\r\n      <a href=\"forum.php?action=addcomment&id=$id&qp=1\"><img border=\"0\" src=\"themes/$themepath/quote.gif\"></a>\r\n\r\n     </td>\r\n					</tr>\r\n				</table>\r\n               </td>\r\n				</tr>\r\n			</table>');
INSERT INTO rafia_templates VALUES (5,'arabportal','download_cat',4,'<table border=\"0\" cellpadding=\"0\" cellspacing=\"0\" width=\"100%\" >\r\n         <tr>\r\n           <td width=\"100%\" style=\"padding: 3\">\r\n			\r\n			\r\n			\r\n			<img border=\"0\" src=\"images/b1.gif\" align=\"middle\" width=\"8\" height=\"8\"> \r\n			<span dir=\"RTL\" class=fontht>\r\n			 <a href=download.php?action=list&cat_id=$id> $title</a></font></span>\r\n<span class=fontablt>           \r\n<img border=\"0\" src=\"images/topics.gif\" align=\"middle\" alt=\"��� �������\">\r\n           <font color=\"#C0C0C0\">[$numrows]\r\n</font></span></td>\r\n         </tr>\r\n         <tr>\r\n           <td width=\"100%\" class=fontablt>\r\n			<blockquote>\r\n				<font color=\"#808080\">$dsc</font></blockquote>\r\n\r\n</td>\r\n         </tr>\r\n       </table>\r\n<hr color=\"#000000\" size=\"1\" width=\"90%\">');
INSERT INTO rafia_templates VALUES (6,'arabportal','show_members',6,'<center><table border=\"0\" width=\"80%\" id=\"table1\" cellspacing=\"0\" cellpadding=\"0\">\r\n	<tr>\r\n		<td width=\"9\" height=\"31\">\r\n		<img border=\"0\" src=\"themes/apt/menu_03.jpg\" width=\"9\" height=\"31\"></td>\r\n		<td background=\"themes/apt/menu_02.jpg\" width=\"100%\"><center><font class=fontablt2>����� �������</font></center></td>\r\n		<td width=\"9\" height=\"31\">\r\n		<img border=\"0\" src=\"themes/apt/menu_01.jpg\" width=\"9\" height=\"31\"></td>\r\n	</tr>\r\n</table>');
INSERT INTO rafia_templates VALUES (7,'arabportal','members_pm_link',6,'<center><table border=\"0\" width=\"304\"><tr>\r\n       <td width=\"76\" bgcolor=\"$bgcolor5\">\r\n       <p align=\"center\">   <a href=\"pm.php?box=1\">\r\n		<img border=\"0\" src=\"themes/apt/pr_inbox.jpg\" width=\"76\" height=\"56\"></a></td>\r\n       <td width=\"76\" bgcolor=\"$bgcolor5\">\r\n       <p align=\"center\">   <a href=\"pm.php?box=2\">\r\n		<img border=\"0\" src=\"themes/apt/pr_outbox.jpg\" width=\"76\" height=\"56\"></a></td>\r\n       <td width=\"76\" bgcolor=\"$bgcolor5\">\r\n       <p align=\"center\">   <a href=\"pm.php?box=3\">\r\n		<img border=\"0\" src=\"themes/apt/pr_save.jpg\" width=\"76\" height=\"56\"></a></td>\r\n     <td width=\"76\" bgcolor=\"$bgcolor5\">\r\n      <p align=\"center\"><a href=\"members.php?action=edit\">\r\n		<img border=\"0\" src=\"themes/apt/setting.jpg\" width=\"76\" height=\"56\"></a></td>\r\n       </tr></table></center>');
INSERT INTO rafia_templates VALUES (8,'arabportal','link_list',5,'<table border=\"0\" cellpadding=\"0\" cellspacing=\"0\" width=\"95%\">\r\n	<tr>\r\n		<td width=\"17\">\r\n		</td>\r\n<td  class=\"info_bar\" width=\"100%\" background=\"themes/apt/cat_bg.jpg\">\r\n<img border=\"0\" src=\"themes/apt/table_03.jpg\" width=\"3%\" height=\"18\">\r\n&nbsp;<a target=_blank href=\"$PHP_SELF?action=goto&id=$id\"><font color=\"#FFFFFF\">$title</font></a><a target=_blank href=\"$PHP_SELF?action=goto&id=$id\">\r\n	\r\n	</a>\r\n	\r\n	</td>\r\n	</tr>\r\n  <tr>\r\n    <td width=\"100%\" colspan=\"2\">\r\n    <table border=\"0\" cellpadding=\"2\" style=\"border-collapse: collapse\" width=\"100%\" id=\"AutoNumber1\" class=\"info_bar\">\r\n      <tr>\r\n        <td width=\"100%\">\r\n         �������: $rating_avg &nbsp;\r\n                </td>\r\n        <td nowrap align=\"left\" colspan=\"3\"> </td>\r\n      </tr>\r\n    </table>\r\n    </td>\r\n  </tr>\r\n  \r\n</table>\r\n\r\n\r\n\r\n<table border=\'0\' width=\'95%\' bgcolor=\"#ffffff\" cellspacing=0 cellpadding=0>\r\n<tr><td width=\'32%\' valign=top bgcolor=#f1f1f1>\r\n<font class=fontablt>�������� : $clicks  </font>\r\n<BR>\r\n<font class=fontablt> �������:  $ratings</font>\r\n <br>\r\n<font class=fontablt>������ : $name  </font>\r\n</td>\r\n<td  height=\'100%\' valign=top>\r\n<table border=\"0\" cellpadding=\"0\" cellspacing=\"0\" width=\"100%\">\r\n<tr>\r\n  <td valign=top><font class=fontablt>$post</font>\r\n</td>\r\n</tr>\r\n</table>\r\n</td>\r\n</tr>\r\n</table>\r\n<table border=\"0\" cellpadding=\"0\" cellspacing=\"0\" width=\"95%\">\r\n<tr>\r\n<td width=100% valign=top bgcolor=#FFFFFF align=center><p align=center>\r\n| <a href=javascript:rafiawin(\'popup.php?action=alertl&id=$id\',200,400)><img border=\"0\" src=\"themes/$themepath/hidlink.gif\"></a>\r\n| <a href=javascript:rafiawin(\'popup.php?action=ratek&id=$id\',200,400)><img border=\"0\" src=\"themes/$themepath/rank.gif\"></a>|\r\n<a href=\"$PHP_SELF?action=edit&id=$id\"><img border=\"0\" src=\"themes/$themepath/edit.gif\"></a>\r\n</td>\r\n</tr>\r\n</table>\r\n<hr color=\"#C0C0C0\" width=\"95%\" size=\"1\">');
INSERT INTO rafia_templates VALUES (9,'arabportal','download_table',4,'<table border=\"0\" width=\"90%\" id=\"table3\" cellspacing=\"0\" cellpadding=\"0\">\r\n			<tr>\r\n				<td class=\"forum_header\">\r\n				 ������� �� ��������</td>\r\n			</tr>\r\n			<tr>\r\n				<td>\r\n				<table border=\"0\" width=\"100%\" id=\"table4\" cellpadding=\"2\" class=\"fontablt\">\r\n					<tr>\r\n						<td nowrap class=\"info_bar\">��� ��������:</td>\r\n						<td width=\"100%\">$title</td>\r\n					</tr>\r\n					<tr>\r\n						<td nowrap class=\"info_bar\">�����:</td>\r\n						<td width=\"100%\">$size</td>\r\n					</tr>\r\n					<tr>\r\n						<td nowrap class=\"info_bar\">���� �������:</td>\r\n						<td width=\"100%\">$clicks</td>\r\n					</tr>\r\n					<tr>\r\n						<td nowrap class=\"info_bar\">�������:</td>\r\n						<td width=\"100%\">$ratings</td>\r\n					</tr>\r\n					<tr>\r\n						<td nowrap class=\"info_bar\">�������:</td>\r\n						<td width=\"100%\"><font class=\"fontablt\">\r\n						$rating_avg</font></td>\r\n					</tr>\r\n					<tr>\r\n						<td nowrap class=\"info_bar\">����� �������:</td>\r\n						<td width=\"100%\">$date</td>\r\n					</tr>\r\n					<tr>\r\n						<td nowrap class=\"info_bar\">������ �������</td>\r\n						<td width=\"100%\">$formmember</td>\r\n					</tr>\r\n					<tr>\r\n						<td nowrap class=\"info_bar\">�����:</td>\r\n						<td width=\"100%\">$post_head <hr> $post </td>\r\n					</tr>\r\n				</table>\r\n				</td>\r\n			</tr>\r\n			<tr>\r\n				<td width=\"100%\">\r\n               $action\r\n\r\n				<font class=\"fontablt\">\r\n				<img border=\"0\" src=\"themes/$themepath/download.gif\" width=\"73\" height=\"24\">\r\n                </font></a>\r\n                <a href=\"javascript:rafiawin(\'popup.php?action=alert&id=$id\',200,400)\">\r\n                <img border=\"0\" src=\"themes/$themepath/hidlink.gif\" width=\"88\" height=\"24\"></a>\r\n                <a href=\"javascript:rafiawin(\'popup.php?action=rated&id=$id\',200,400)\">\r\n                <img border=\"0\" src=\"themes/$themepath/rank.gif\" width=\"66\" height=\"24\"></a>\r\n                <a href=\"download.php?action=edit&id=$id\">\r\n                <img border=\"0\" src=\"themes/$themepath/edit.gif\" width=\"54\" height=\"24\"></a>\r\n                </td>\r\n			</tr>\r\n			<tr>\r\n				<td align=\"left\"><font size=\"2\" color=\"#FFFFFF\"><br>\r\n				\r\n               </font></td>\r\n			</tr>\r\n		</table>');
INSERT INTO rafia_templates VALUES (10,'arabportal','s_view_topic_comment',1,'<center>\r\n<table border=0 width=90% cellpadding=1 bordercolorlight= cellspacing=0>\r\n<tr>\r\n<td width=50% valign=top bgcolor=F4F4F4 align=\"right\"><b><font class=fontht>������  : $name || ������ : $date </font></b>\r\n</td>\r\n</tr><tr>\r\n<td width=50% valign=top bgcolor=F4F4F4 align=\"right\">\r\n<font class=fontablt><b> $title</b><br>$comment\r\n</font></b></td></tr></table>\r\n<hr noshade color=#000000 size=0 width=90%>\r\n  </center>');
INSERT INTO rafia_templates VALUES (11,'arabportal','forum_main_table',3,'<table border=\"0\" cellpadding=\"0\" cellspacing=\"0\" style=\"border-collapse: collapse\" bordercolor=\"#111111\" width=\"95%\">\r\n    <tr>\r\n      <td width=\"33%\">&nbsp;</td>\r\n      <td width=\"33%\">&nbsp;</td>\r\n      <td width=\"34%\">&nbsp;$last_topics</td>\r\n    </tr>\r\n  </table>\r\n<table border=\"0\" width=\"95%\" id=\"table4\" cellspacing=\"1\" cellpadding=\"0\">\r\n			<tr>\r\n				<td class=\"forum_header\">&nbsp;</td>\r\n				<td width=\"100%\" class=\"forum_header\">�������</td>\r\n				<td width=\"200\" class=\"forum_header\" nowrap>��� ������</td>\r\n				<td class=\"forum_header\">��������</td>\r\n				<td class=\"forum_header\">������</td>\r\n			</tr>\r\n\r\n   \r\n           $forum_cat_table\r\n\r\n   \r\n		</table>\r\n		<BR>&nbsp;');
INSERT INTO rafia_templates VALUES (12,'arabportal','forum_cat',3,'<tr>\r\n				<td class=\"forum_alt2\">\r\n				<img border=\"0\" src=\"themes/apt/$cat_icon\" width=\"21\" height=\"19\"></td>\r\n				<td align=right width=\"100%\" class=\"forum_alt2\"><a href=forum.php?action=list&cat_id=$id>\r\n    <font color=\"#34597D\">$title\r\n    </font></a>\r\n				<div class=\"small\">\r\n					$dsc</div>\r\n                <div class=\"small\">\r\n					 �������  ������ :<b> $moderatename</b> </div>\r\n				</td>\r\n				<td width=\"200\" class=\"forum_alt1\"><span class=\"small\">\r\n   <a href=forum.php?action=view&id=$lastpostid>$lasttitle </a>\r\n    <br>\r\n				$lastpostd <br>\r\n				������ : <a href=\"members.php?action=info&userid=$lastposterid\">$username</a>\r\n    </span></td>\r\n				<td class=\"forum_alt2\" align=\"center\">$numrows</td>\r\n				<td class=\"forum_alt1\" align=\"center\">$numcomment</td>\r\n			</tr>');
INSERT INTO rafia_templates VALUES (13,'arabportal','forum_main',3,'<body topmargin=\"0\" leftmargin=\"0\" rightmargin=\"0\" bottommargin=\"0\">\r\n $pagehd\r\n<center>\r\n<table border=\"0\" width=\"$themewidth\" id=\"table4\" cellspacing=\"0\" cellpadding=\"0\">	\r\n	<tr>\r\n		<td width=\"25\">\r\n		<img border=\"0\" src=\"themes/apt/apt_26.gif\" width=\"25\" height=\"25\"></td>\r\n		<td background=\"themes/apt/apt_25.gif\" width=\"64\"> </td>\r\n		<td width=\"174\">\r\n		<img border=\"0\" src=\"themes/apt/apt_24.gif\" width=\"174\" height=\"25\"></td>\r\n		<td width=\"100%\" background=\"themes/apt/apt_25.gif\"> \r\n<!--INC dir=\"block\" file=\"last_10_forum.php\" -->		\r\n		</td>\r\n		<td width=\"187\">\r\n		<img border=\"0\" src=\"themes/apt/apt_22.gif\" width=\"187\" height=\"25\"></td>\r\n	</tr>\r\n</table>\r\n\r\n\r\n<table border=\"0\" cellpadding=\"0\" cellspacing=\"0\" width=\"$themewidth\" height=\"100%\" bgcolor=\"#FFFFFF\">\r\n\r\n <tr>\r\n\r\n  <td width=\"100%\" valign=\"top\" style=\"padding:5px\" class=\"forum_control_bar\">\r\n<div style=\"float:right\">$users_tools</div>\r\n<div style=\"float: left; width:234px; height:27px\">      \r\n<form name=search_form  action=search.php method=post style=\"margin: 0px; padding: 0px\">\r\n<input type=text name=searchfor size=14><input type=hidden name=searchin value=rafia_forum>\r\n  <input class=button  type=submit name=submit value=���>&nbsp<a href=\"search.php?action=search\">��� �����</a>&nbsp;&nbsp; \r\n</form></div>\r\n  </td>\r\n  </tr>\r\n \r\n \r\n<tr>\r\n<td width=\"100%\" valign=\"top\" align=\"center\" style=\"padding:5px\" height=\"100%\">\r\n\r\n  <center>$ads_head  </center>\r\n           \r\n          $forum_middle\r\n\r\n\r\n		</td></tr>\r\n	</table></center>\r\n \r\n<center>$ads_foot</center>\r\n$pageft\r\n\r\n\r\n</body>\r\n\r\n</html>');
INSERT INTO rafia_templates VALUES (14,'arabportal','Index_main',1,'<center>\r\n<body topmargin=\"0\" leftmargin=\"0\" rightmargin=\"0\" bottommargin=\"0\" >\r\n\r\n\r\n$pagehd\r\n\r\n<table border=\"0\" width=\"$themewidth\" id=\"table4\" cellspacing=\"0\" cellpadding=\"0\">	\r\n	<tr>\r\n		<td width=\"25\">\r\n		<img border=\"0\" src=\"themes/apt/apt_26.gif\" width=\"25\" height=\"25\"></td>\r\n		<td background=\"themes/apt/apt_25.gif\" width=\"64\"> </td>\r\n		<td width=\"174\">\r\n		<img border=\"0\" src=\"themes/apt/apt_24.gif\" width=\"174\" height=\"25\"></td>\r\n		<td width=\"100%\" background=\"themes/apt/apt_25.gif\"> \r\n<!--INC dir=\"block\" file=\"last_10_news.php\" -->		\r\n		</td>\r\n		<td width=\"187\">\r\n		<img border=\"0\" src=\"themes/apt/apt_22.gif\" width=\"187\" height=\"25\"></td>\r\n	</tr>\r\n</table>\r\n\r\n\r\n\r\n\r\n\r\n<table border=0 cellpadding=\"0\" cellspacing=\"0\"  width=\"$themewidth\"  height=\"100%\" bgcolor=#FFFFFF>\r\n<tr>\r\n<!-- RightStart -->\r\n<td width=\'160\' valign=\'top\' align=\'center\' nowrap style=\"border-top:1px solid #FFFFFF; border-left:1px solid #D9D9D9; \" bgcolor=#F1F1F1>\r\n$right_menu<br>\r\n</td>\r\n<!-- RightEnd -->\r\n<td width=\'100%\' valign=\'top\' align=\'center\' style=\"padding:5px\">\r\n$ads_head\r\n\r\n$index_middle\r\n<br>\r\n$middle_menu\r\n<br>\r\n$ads_foot\r\n</td>\r\n<!-- LeftStart -->\r\n<td width=\'160\' valign=\'top\' align=\'center\' nowrap style=\"border-top:1px solid #FFFFFF; border-right:1px solid #D9D9D9; \" bgcolor=#F1F1F1>\r\n$left_menu\r\n</td>\r\n<!-- LeftEnd -->\r\n</tr>\r\n    </table>\r\n\r\n$pageft\r\n</center>');
INSERT INTO rafia_templates VALUES (15,'arabportal','guestbook_table',1,'<!-- guestbook_table START -->\r\n<table border=\"0\" width=\"100%\" id=\"side_menu\" cellspacing=\"0\" cellpadding=\"0\">\r\n	<tr>\r\n  <td bgcolor=\"#F1F1F1\" style=\"padding-right: 5px\" class=fontablt colspan=\"3\" align=right>\r\n<a href=\"$PHP_SELF?action=edit&id=$id\"><img border=\"0\" src=\"themes/$themepath/g_edit.gif\" width=\"16\" height=\"16\"></a>\r\n<a href=$url target=_blank><img border=\"0\" src=\"themes/$themepath/home.gif\" width=\"16\" height=\"16\"></a>\r\n<a href=mailto:$email><img border=\"0\" src=\"themes/$themepath/email.gif\" width=\"16\" height=\"16\"></a>  \r\n</td></tr>\r\n<tr>\r\n<td bgcolor=\"#F9F9F9\" style=\"padding-right: 5px\" class=fontablt colspan=\"3\" align=right>\r\n<font class=fontablt> $guestbook <br><br></font></td></tr> \r\n<tr>\r\n<td bgcolor=\"#F1F1F1\" style=\"padding-right: 5px\"  align=right class=fontht2 colspan=\"3\">\r\n<font class=fontht2>����� : $name</font>\r\n</td></tr> \r\n</table><br>\r\n<!-- guestbook_table END -->');
INSERT INTO rafia_templates VALUES (16,'arabportal','forum_cat_table',3,'<tr>\r\n				<td colspan=\"5\">\r\n				<table border=\"0\" width=\"100%\" id=\"table6\" cellspacing=\"0\" cellpadding=\"0\">\r\n					<tr>\r\n						<td class=\"forum_header2\">\r\n						\r\n<a href=\"forum.php?action=list&cat_id=$id\"> <font color=\"#FFFFFF\">$title </font></a>\r\n      </td>\r\n					</tr>\r\n				</table>\r\n				</td>\r\n			</tr>\r\n             $forum_cat');
INSERT INTO rafia_templates VALUES (17,'arabportal','form_code',1,'<table cellpadding=\"0\" cellspacing=\"0\" border=\"0\">\r\n<tr valign=\"bottom\">\r\n	<td colspan=\"2\">\r\n<!-- start control bar --><div id=\"controlbar\"><!-- / start control bar -->\r\n<!-- first control row -->\r\n<div class=\"controlholder\">\r\n<!-- MagicToolBox 2.5 by Alawi BaAqeel, software@rayaheen.net -->\r\n<script language=\"Javascript\" src=\"html/toolbox/toolbox.js\"></script>\r\n<script language=\"Javascript\">\r\ntoolbox_backcolor = \"#ECE9D8\";\r\nbtn_bordercolor = \"black\";\r\nbtn_backcolor_over = \"cornsilk\";\r\nbtn_backcolor_down = \"white\";\r\nstatusColor = \"black\";\r\ntipColor = \"maroon\";\r\n</script>\r\n<STYLE TYPE=\"text/css\">\r\n.cbtn{\r\n  width:20px;\r\n  height:18px;\r\n  cursor:hand;\r\n}\r\n</STYLE>\r\n<table dir=\"ltr\" border=\"0\" cellpadding=\"0\" cellspacing=\"0\" width=\"100%\">\r\n<tr><td align=\"center\" oncontextmenu=\"return false\" onselectstart=\"return false\" \r\nonmousedown=\"Capture(1)\" onmouseup=\"Capture(0)\" onmousemove=\"Capture(0)\">\r\n\r\n<script language=\'javascript\'h>\r\nshowButtons();\r\nshowKeyboard();\r\n</script>\r\n\r\n</td></tr></table>\r\n<!-- end of MagicToolBox 2.5 for vB3 -->\r\n	</div>\r\n<!-- end control bar --></div><!-- / end control bar -->\r\n</td>\r\n</tr>\r\n<tr valign=\"top\">\r\n	<td class=\"controlbar\">\r\n	</td></tr></table>');
INSERT INTO rafia_templates VALUES (18,'arabportal','link_cat_tools',5,'<table border=\'0\' width=\"90%\" cellspacing=\"1\" >\r\n      <tr>\r\n       <td width=\'100%\'  align=\'right\'>\r\n       <div align=\"center\">\r\n        <table border=\"0\" width=\"100%\" cellspacing=\"0\" cellpadding=\"0\">\r\n          <tr>\r\n            <td width=\"50%\" align=\"right\">\r\n       $Jump</td>\r\n            <center>\r\n            <td width=\"50%\" align=\"right\"><a href=\"$PHP_SELF?action=add&cat_id=$cat_id\"><img border=\"0\" src=\"themes/$themepath/$cat_img\" align=\"left\"></a></td>\r\n            </tr>\r\n          </table>\r\n        </center>\r\n       </div>\r\n       </td>\r\n      </tr>\r\n       </table>');
INSERT INTO rafia_templates VALUES (19,'arabportal','member_cp',6,'<div align=\"center\">\r\n  <center>\r\n  <table border=\"0\" width=\"90%\" cellspacing=\"0\" cellpadding=\"0\">\r\n    <tr>\r\n      <td width=\"100%\">\r\n        <div align=\"center\">\r\n          <table border=\"0\" width=\"100%\">\r\n            <tr>\r\n              <td width=\"50%\" bgcolor=\"$bgcolor2\">\r\n</td>\r\n            </tr>\r\n          </table>\r\n        </div>\r\n      </td>\r\n    </tr>\r\n    <tr>\r\n      <td width=\"100%\">\r\n        <div align=\"center\">\r\n          <table border=\"0\" width=\"100%\" cellspacing=\"4\">\r\n            <tr>\r\n              <td width=\"88%\" align=\"right\" colspan=\"2\" background=\"themes/apt/catbg2.gif\" height=\"27\">\r\n				<p align=\"center\"><b>\r\n				<font face=\"Times New Roman\" color=\"#FFFFFF\"><span lang=\"ar-sa\">\r\n				����� ������</span></font></b></td>\r\n            </tr>\r\n            <tr>\r\n              <td width=\"15%\" align=\"right\" bgcolor=\"#D5D5FF\"><font class=fontablt>���\r\n                ��������</td>\r\n              <td width=\"73%\" align=\"right\" bgcolor=\"#EFEFEF\"><font class=fontablt>\r\n				<a href=\"members.php?action=info&userid=$userid\">$username</a> </font></td>\r\n            </tr>\r\n             <tr>\r\n              <td width=\"15%\" align=\"right\" bgcolor=\"#D5D5FF\"><font class=fontablt>�����\r\n                �������</font></td>\r\n              <td width=\"73%\" align=\"right\" bgcolor=\"#EFEFEF\"><font class=fontablt>$date</font></td>\r\n            </tr>\r\n            <tr>\r\n              <td width=\"15%\" align=\"right\" bgcolor=\"#D5D5FF\"><font class=fontablt>�����</font></td>\r\n              <td width=\"73%\" align=\"right\" bgcolor=\"#EFEFEF\"><font class=fontablt>$usertitle</font></td>\r\n            </tr>\r\n            <tr>\r\n              <td width=\"15%\" align=\"right\" bgcolor=\"#D5D5FF\"><font class=fontablt>������</font></td>\r\n              <td width=\"73%\" align=\"right\" bgcolor=\"#EFEFEF\"><font class=fontablt>\r\n				<a href=\"mailto:$email\">$email</a> </font></td>\r\n            </tr>\r\n            <tr>\r\n              <td width=\"15%\" align=\"right\" bgcolor=\"#D5D5FF\"><font class=fontablt>������</font></td>\r\n              <td width=\"73%\" align=\"right\" bgcolor=\"#EFEFEF\"><font class=fontablt>\r\n				<a href=\"$homepage\">$homepage</a> </font></td>\r\n            </tr>\r\n            <tr>\r\n              <td width=\"15%\" align=\"right\" bgcolor=\"#D5D5FF\"><font class=fontablt>����\r\n                ������</font></td>\r\n              <td width=\"73%\" align=\"right\" bgcolor=\"#EFEFEF\"><font class=fontablt>$showemail </font></td>\r\n            </tr>\r\n            <tr>\r\n              <td width=\"15%\" align=\"right\" bgcolor=\"#D5D5FF\"><font class=fontablt>��� ����\r\n                ���������</font></td>\r\n              <td width=\"73%\" align=\"right\" bgcolor=\"#EFEFEF\"><font class=fontablt>$allposts </font></td>\r\n            </tr>\r\n            <tr>\r\n              <td width=\"15%\" align=\"right\" bgcolor=\"#D5D5FF\"><font class=fontablt>������ �������</font></td>\r\n              <td width=\"73%\" align=\"right\" bgcolor=\"#EFEFEF\"><font class=fontablt>$avatar_pic</font></td>\r\n            </tr>    \r\n          </table>\r\n        </div>\r\n      </td>\r\n    </tr>\r\n  </table>\r\n  </center>\r\n</div>');
INSERT INTO rafia_templates VALUES (20,'arabportal','body_msg',1,'<body bgcolor=\"#FFFFFF\">\r\n        <br>\r\n        <br>\r\n        <br>\r\n        <br>\r\n        <br>\r\n        <br>\r\n        <br>\r\n        <br>\r\n        <div align=\"center\">\r\n        <center>\r\n        <table border=\"0\" width=\"80%\" bgcolor=\"#EBEBEB\">\r\n        <tr>\r\n        <td width=\"100%\" align=\"center\"><br><font class=fontablt><b>$msg</font></b><br>\r\n         <a href=\"$url\">$lang_msg[8]</a>\r\n        <br>\r\n        </td>\r\n        </tr>\r\n       </table>\r\n       </center>\r\n       </div>\r\n       </body>\r\n       </html>');
INSERT INTO rafia_templates VALUES (21,'arabportal','error_msg',1,'<body bgcolor=\"#FFFFFF\">\r\n<br>\r\n<br>\r\n<br>\r\n<br>\r\n<br>\r\n<br><br><br>\r\n<div align=center>\r\n<center>\r\n<table border=\"0\" width=\"80%\" bgcolor=\"#EBEBEB\">\r\n<tr>\r\n<td width=\'100%\' align=\"center\"><br><font class=fontablt>$msg<br>\r\n<br>\r\n<center>[ <a href=\'javascript:history.go(-1);\'>������ �����</a> ]</center>\r\n<br>\r\n</td>\r\n</tr>\r\n</table>\r\n</center>\r\n</div>\r\n</body>\r\n</html>');
INSERT INTO rafia_templates VALUES (22,'arabportal','uploadfile',1,'<table border=1 cellpadding=\"4\" cellspacing=\"0\" style=\"border-collapse: collapse; border-width: 0\" bordercolor=\"111111\" width=\"96%\" id=\"AutoNumber7\">\r\n    <tr>\r\n      <td width=\"100%\" colspan=\"2\"  >\r\n        <p align=\"center\"><font size=\"1\" face=\"Windows UI\"><b>&nbsp;���\r\n        ����&nbsp; $download</b></font></td>\r\n    </tr>\r\n    <tr>\r\n      <td width=\"32%\"  ><b><font size=\"1\" face=\"Windows UI\">��� ���� �������</font></b></td>\r\n      <td width=\"68%\" ><b><font size=\"1\" face=\"Windows UI\">$upclicks</font></b></td>\r\n    </tr>\r\n    <tr>\r\n      <td width=\"32%\"><b><font  size=\"1\" face=\"Windows UI\">��� �����</font></b></td>\r\n      <td width=\"68%\" ><font size=\"1\" face=\"Windows UI\"><b>$upsize</b></font><font class=fontablt> <font size=\"1\" face=\"Windows UI\"><b> ����</b></font></font></td>\r\n    </tr>\r\n    <tr>\r\n      <td width=\"32%\"><b><font size=\"1\" face=\"Windows UI\">��� �����</font></b></td>\r\n      <td width=\"68%\"><b><font size=\"1\" face=\"Windows UI\">$upname</font></b></td>\r\n    </tr>\r\n  </table>');
INSERT INTO rafia_templates VALUES (23,'arabportal','blockmenu',7,'<!-- BLOCK START -->\r\n<TABLE WIDTH=\"100%\" BORDER=0 CELLPADDING=0 CELLSPACING=0>\r\n	<TR>\r\n		<TD width=\"9\" height=\"24\" background=\"themes/apt/cat_bg.jpg\">\r\n			&nbsp;</TD>\r\n		<TD background=\"themes/apt/cat_bg.jpg\" width=\"100%\">\r\n			\r\n<p align=\"center\">\r\n			\r\n<font class=side_menu_head>{block_head}</font>			\r\n			</TD>\r\n		<TD width=\"9\" height=\"24\" background=\"themes/apt/cat_bg.jpg\">\r\n			&nbsp;</TD>\r\n	</TR>\r\n  </tr>\r\n  <tr>\r\n    <td  colspan=\"3\" bgcolor=\"#F1F1F1\" style=\"padding-right: 5px\" class=side_menu_center>{block_center}\r\n<BR> \r\n</td>\r\n  </tr>	\r\n</TABLE>\r\n<!-- BLOCK END -->');
INSERT INTO rafia_templates VALUES (24,'arabportal','forum_list_bottom',3,'<table border=\"0\" id=\"table10\" cellspacing=\"3\" cellpadding=\"3\" class=\"small\" width=\"95%\">\r\n			<tr>\r\n				<td nowrap>\r\n				<img border=\"0\" src=\"themes/$themepath/posticon.gif\" width=\"12\" height=\"16\"></td>\r\n				<td nowrap>������ �����</td>\r\n				<td nowrap>\r\n				<img border=\"0\" src=\"themes/$themepath/postnew.gif\" width=\"12\" height=\"16\"></td>\r\n				<td nowrap>������ �����</td>\r\n				<td width=\"100%\">&nbsp;</td>\r\n			</tr>\r\n			<tr>\r\n				<td nowrap>\r\n				<img border=\"0\" src=\"themes/$themepath/posthot.gif\" width=\"12\" height=\"16\"></td>\r\n				<td nowrap>������ �����</td>\r\n				<td nowrap>\r\n				<img border=\"0\" src=\"themes/$themepath/Sticky.gif\" width=\"12\" height=\"16\"></td>\r\n				<td nowrap>������ ������</td>\r\n				<td width=\"100%\">&nbsp;</td>\r\n			</tr>\r\n			<tr>\r\n				<td nowrap>\r\n				<img border=\"0\" src=\"themes/$themepath/postlock.gif\" width=\"12\" height=\"16\"></td>\r\n				<td nowrap>������ �����</td>\r\n				<td nowrap>&nbsp;</td>\r\n				<td nowrap>&nbsp;</td>\r\n				<td width=\"100%\">&nbsp;</td>\r\n			</tr>\r\n		</table>');
INSERT INTO rafia_templates VALUES (25,'arabportal','pm_msg_list',6,'<!-- pm_msg_list -->\r\n	<tr>\r\n	<td width=\"29\" bgcolor=\"#D8E3F1\">\r\n	<p align=\"center\">\r\n	$msgisread</td>\r\n	<td width=\"41%\" bgcolor=\"#ECF2F9\"><b>\r\n	<a href=\"/pm.php?action=view&msgid=$id\" style=\"text-decoration: none\">\r\n	<font color=\"#34597D\">&nbsp;<a href=\"$PHP_SELF?action=view&msgid=$msgid&box=$box\">$msgtitle</a></font></a></b></td>\r\n	<td id=\"m4\" width=\"12%\" align=\"center\" bgcolor=\"#D8E3F1\">\r\n		<font color=\"#34597D\" face=\"Arial\"><b>\r\n		<span lang=\"en-us\">$fromusername</span></b></font></td>\r\n	<td id=\"m4\" width=\"263\" bgcolor=\"#ECF2F9\">\r\n		<div class=\"\">\r\n			<p align=\"center\"><font color=\"#34597D\" face=\"Tahoma\" size=\"2\"><strong style=\"font-weight: 400\">$msgdate</strong>\r\n		</font>\r\n		</div>\r\n	\r\n	</td>\r\n	<td align=\"center\" style=\"padding:0px\" width=\"2%\" bgcolor=\"#DFE9F4\">\r\n	<input type=\"checkbox\" name=\"msgsid[]\" value=\"$msgid\" /></td>\r\n</tr>\r\n<!-- // pm_msg_list -->');
INSERT INTO rafia_templates VALUES (26,'arabportal','pm_msg_table',6,'<table border=\'0\' width=\'96%\' cellspacing=\'0\'><tr>\r\n               <td width=\'100%\' valign=bottom><p align=\'right\' class=forum_alt2>               \r\n               <IMG height=21 src=themes/apt/navbits_start.gif width=21 align=absMiddle border=0> \r\n<A href=pm.php>������� ������</A>\r\n            <BR>\r\n            <IMG height=15 src=themes/apt/icon_bar.gif width=15 align=absMiddle border=0>\r\n            <IMG height=21 src=themes/apt/navbits_finallink.gif width=21 align=absMiddle border=0><a href=\"pm.php?box=1\">����� ������</a> � $msgtitle</td></tr></table>\r\n               \r\n\r\n<br />\r\n\r\n<table border=\"0\" width=\"95%\" id=\"table4\" cellspacing=\"1\" cellpadding=\"0\">\r\n			<tr>\r\n				<td width=\"100%\" class=\"forum_header\" style=\"text-align: right\">\r\n				 $rep_icon � $msgtitle</td>\r\n			</tr>\r\n			<tr>\r\n				<td width=\"100%\" class=\"forum_alt3\">\r\n<table border=\"0\" width=\"100%\" id=\"table16\" >\r\n					<tr>\r\n\r\n			<tr>\r\n				<td width=\"100%\" class=\"forum_alt3\">\r\n				<table border=\"0\" width=\"100%\" id=\"table16\" >\r\n					<tr>\r\n						<td width=\"20%\" class=\"forum_alt1\" valign=\"top\">\r\n\r\n<span class=small>\r\n������: <a href=\"members.php?action=info&userid=$userid\">$row->username</a>\r\n<br>\r\n$userimgtitle<br>\r\n������� : $row->date<br>\r\n��������� :  $row->allposts<br>\r\n  <a href=\"mail.php?action=sendtousers&userid=$row->userid\">\r\n <img border=\'0\' src=\'themes/apt/email.gif\' alt=\'������\'>\r\n  </a>\r\n<a href=$homepage target=_blank><img border=\'0\' src=\'themes/apt/home.gif\' alt=\'������ ������\' ></a>\r\n<br>\r\n</span>\r\n</td>\r\n\r\n\r\n	<td width=\"80%\" valign=\"top\" class=\"forum_alt2\" colspan=\"2\"><span class=small></A>\r\n						 ��� ��  $msgdate</font>\r\n\r\n    </span>\r\n						<hr color=\"#7394B6\" size=\"1\">\r\n                  <b>$msgtitle</b>\r\n                 $message\r\n\r\n                 <br>\r\n$upload_file<br>\r\n      <hr color=\"#7394B6\" size=\"1\">\r\n       <center>$signature</center>\r\n        </td>\r\n					</tr>\r\n					<tr>\r\n						<td width=\"20%\" class=\"small\" valign=\"top\" align=\"center\">\r\n</td><td width=\"40%\" valign=\"top\" class=small>\r\n </td><td width=\"60%\" valign=\"top\" align=\"left\">\r\n<a href=\"pm.php?action=reply&id=$msgid&box=$box\"><img border=\"0\" src=\"themes/$themepath/sendpm.gif\"></a>\r\n<a href=\"pm.php?action=manag&case=del&id=$msgid&box=$box\"><img border=\"0\" src=\"themes/$themepath/del.gif\"></a> \r\n<a href=\"pm.php?action=manag&case=save&id=$msgid&box=$box\"><img border=\"0\" src=\"themes/$themepath/save.gif\"></a>\r\n     </td>\r\n					</tr>\r\n				</table>\r\n               </td>\r\n				</tr>\r\n			</table>\r\n			    </td>\r\n				</tr>\r\n			</table>');
INSERT INTO rafia_templates VALUES (27,'arabportal','pm_list_table',6,'<br />\r\n<form method=\"POST\" action=\"$PHP_SELF?action=manag\" name=\"admin\">\r\n\r\n<div align=\"center\">\r\n\r\n<table cellpadding=\"6\" cellspacing=\"1\" border=\"1\" width=\"100%\" style=\"border-collapse: collapse\">\r\n<thead>\r\n	<tr>\r\n		<td colspan=\"5\" style=\"padding: 6px 0 6px 6px\" bgcolor=\"#F2F0EE\">\r\n			<p align=\"center\">\r\n			<b><font color=\"#34597D\">$nummsg ����� �� ��� $total ����� ��� ����</font></b></p>\r\n			<div align=\"center\">\r\n				<table border=\"1\" width=\"400\" id=\"table5\" style=\"border-collapse: collapse\" >\r\n            <tr>\r\n              <td width=\"100%\" align=\"center\">\r\n              <center>\r\n                 <table border=\"1\" width=\"100%\" id=\"table6\" style=\"border-collapse: collapse\">\r\n             <tr>\r\n              <td width=\"100%\" background=\"themes/apt/pm_cell.gif\"> \r\n				<font class=fontablt color=\"#FFFFFF\"> \r\n				<p align=\"center\"><b> $box_title ����� �����  $width % </b> </td>\r\n            </tr>\r\n             </table>\r\n             <table border=\"0\" width=\"400\"  cellspacing=\"0\" cellpadding=\"0\" id=\"table7\">\r\n            <tr>\r\n              <td width=\"100%\" height=\"3\">\r\n				</td>\r\n            </tr>\r\n            <tr>\r\n              <td width=\"100%\">\r\n<img border=\"0\" src=\"images/msg.gif\" width=\"$width%\"  height=10></td>\r\n            </tr>\r\n           </table>\r\n              </td>\r\n            </tr><tr>\r\n              <td width=\"100%\" align=\"center\">\r\n              <table border=\"0\" width=\"400\" id=\"table8\">\r\n            <tr>\r\n              <td width=\"50%\" align=\"right\"><font size=\"1\"><b>0 %</b></font></td>\r\n\r\n              <td width=\"50%\"  align=\"left\"><font size=\"1\"><b>100 %</b></font></td>\r\n            </tr>\r\n          </table>\r\n              </td>\r\n            </tr>\r\n          </table>\r\n      		</div>\r\n\r\n			</td>\r\n	</tr>\r\n</thead>\r\n<tbody>\r\n	<tr>\r\n		<td class=\"\" colspan=\"5\" style=\"padding-top:3px; padding-bottom:3px; border-bottom:1px outset;\" width=\"102%\" background=\"themes/apt/catbg2.gif\">\r\n			\r\n				<p align=\"center\"><font color=\"#FFFFFF\"><b>$box_title</b></font>\r\n		</td>\r\n	</tr>\r\n</tbody>\r\n<tbody id=\"collapseobj_pmf0_select\" style=\"\">\r\n	<tr>\r\n	<td width=\"29\" bgcolor=\"#D8E3F1\" align=\"center\">&nbsp;</td>\r\n	<td width=\"41%\" align=\"center\" bgcolor=\"#ECF2F9\">\r\n	<font color=\"#34597D\"><b>����� �������</b></font></td>\r\n	<td id=\"m4\" width=\"12%\" align=\"center\" bgcolor=\"#D8E3F1\">\r\n		<font color=\"#34597D\">\r\n		<b>$tofrom</b></font></td>\r\n	<td id=\"m4\" width=\"263\" align=\"center\" bgcolor=\"#ECF2F9\">\r\n		<font color=\"#34597D\">\r\n		<b>����� �������</b></font></td>\r\n	<td align=\"center\" style=\"padding:0px\" width=\"2%\" bgcolor=\"#D8E3F1\">\r\n</td>\r\n</tr>\r\n	<tr>\r\n	<td bgcolor=\"#E6E3DF\" height=\"3\" colspan=\"5\">\r\n	</td>\r\n</tr>\r\n $pm_msg_list\r\n</tbody>\r\n<tbody>\r\n	<tr>\r\n		<td align=\"right\" colspan=\"5\" background=\"themes/apt/catbg2.gif\">			\r\n			<div class=\"\">\r\n				<font color=\"#FFFFFF\"><b>������ �������:</b></font>\r\n<select name=\"do\">\r\n<option value=\"\">���� �� �������</option>\r\n<option value=\"save\">���</option>\r\n<option value=\"del\">���</option>\r\n<option value=\"export\">�����</option>\r\n<option value=\"read\">������ ������</option>\r\n<option value=\"unread\">������ ��� ������</option>\r\n</select>\r\n<input type=\"submit\" class=\"\" value=\"�����\" />\r\n<input type=\"button\" name=\"CheckAll\" value=\"����� ����\" onclick=\"checkAll(document.admin)\" >\r\n        <input type=\"button\" name=\"UnCheckAll\" value=\"����� �������\" onclick=\"uncheckAll(document.admin)\" >\r\n       <input type=\"hidden\" name=\"box\"  value=\"$box\">\r\n\r\n			</div>		\r\n		</td>\r\n	</tr>\r\n</tbody>\r\n</table>\r\n\r\n</div>\r\n\r\n<br>\r\n</form>\r\n<a href=\"pm.php?action=sendmsg\"><img border=\"0\" src=\"themes/$themepath/newpm.gif\"></a><br />\r\n<!-- forumjump -->\r\n<table cellpadding=\"0\" cellspacing=\"0\" border=\"0\" width=\"100%\" align=\"center\">\r\n<tr valign=\"top\">\r\n	<td width=\"100%\" rowspan=\"2\">\r\n		<table cellpadding=\"2\" border=\"0\" style=\"border-collapse: collapse\" width=\"40%\">\r\n		<tr>\r\n			<td>\r\n			<p align=\"center\">\r\n	<img border=\"0\" src=\"themes/apt/pm_unread.gif\" width=\"18\" height=\"12\"></td>\r\n			<td><font color=\"#34597D\"><b>&nbsp; ����� ��� ������</b></font></td>\r\n		</tr>\r\n		<tr>\r\n			<td>\r\n			<p align=\"center\">\r\n			<img border=\"0\" src=\"themes/apt/pm_read.gif\" width=\"18\" height=\"17\"></td>\r\n			<td><font color=\"#34597D\"><b>&nbsp; ����� ������</b></font></td>\r\n		</tr>\r\n		<tr>\r\n			<td>\r\n			<p align=\"center\">\r\n			<img border=\"0\" src=\"themes/apt/pm_reply.gif\" width=\"18\" height=\"17\"></td>\r\n			<td><font color=\"#34597D\"><b>&nbsp; ����� �� ���� �����\r\n			</b></font></td>\r\n		</tr>\r\n		<tr>\r\n			<td>\r\n			<p align=\"center\">\r\n			<img border=\"0\" src=\"themes/apt/pm_forward.gif\" width=\"18\" height=\"17\"></td>\r\n			<td><font color=\"#34597D\"><b>&nbsp; ����� �����</b></font></td>\r\n		</tr>\r\n		</table>\r\n	</td>\r\n	<td class=\"\" nowrap=\"nowrap\">\r\n		&nbsp;</td>\r\n</tr>\r\n<tr>\r\n	<td valign=\"bottom\"><div class=\"\" style=\"text-align:left; white-space:nowrap\">\r\n	<form action=\"pm.php\" method=\"get\">\r\n\r\n	<strong>�������� ���:</strong><br />\r\n	<select name=\"box\" onchange=\"this.form.submit();\">\r\n			<option value=\"index\" selected=\"selected\">���� �� �������</option>	\r\n			<option value=\"1\" >����� ������</option>\r\n			<option value=\"2\" >����� ������</option>			\r\n			<option value=\"3\" >����� �����</option>			\r\n	</select>&nbsp;<input type=\"submit\" class=\"\" value=\"����\"  />\r\n	</form>\r\n</div></td>\r\n</tr>\r\n</table>');
INSERT INTO rafia_templates VALUES (28,'arabportal','users_Login',3,'<form method=post action=members.php?action=login>\r\n\r\n\r\n    <font face=tahoma size=2>���� ����� � ���� ����  :</font> <input type=textbox name=username size=13>\r\n <input type=password name=userpass size=13>\r\n        <input class=\"button\"  type=submit value=����>\r\n          <a href=javascript:rafiawin(\'popup.php?action=remind\',250,350)>����� ��������</a>\r\n</form>');
INSERT INTO rafia_templates VALUES (29,'arabportal','forum_cat_tools',3,'<table border=\'0\' width=\"96%\" cellspacing=\"1\" >\r\n      <tr>\r\n       <td width=\'100%\'  align=\'right\'>\r\n       <div align=\"center\">\r\n        <table border=\"0\" width=\"100%\" cellspacing=\"0\" cellpadding=\"0\">\r\n          <tr>\r\n            <td width=\"50%\" align=\"right\">\r\n       $Jump</td>\r\n            <center>\r\n            <td width=\"50%\" align=\"right\"><a href=\"$PHP_SELF?action=add&cat_id=$cat_id\"><img border=\"0\" src=\"themes/$themepath/$cat_img\" align=\"left\"></a></td>\r\n            </tr>\r\n          </table>\r\n        </center>\r\n       </div>\r\n       </td>\r\n      </tr>\r\n       </table>');
INSERT INTO rafia_templates VALUES (30,'arabportal','member_info',6,'<div align=\"center\">\r\n  <center>\r\n  <table border=\"0\" width=\"90%\" cellspacing=\"0\" cellpadding=\"0\">\r\n    <tr>\r\n      <td width=\"100%\">\r\n        <div align=\"center\">\r\n          <table border=\"0\" width=\"100%\">\r\n            <tr>\r\n              <td width=\"50%\" align=\"center\" background=\"themes/apt/catbg2.gif\"><font class=fontht>\r\n�������\r\n�����\r\n�������� : <b> $username </font></b>\r\n</td>\r\n            </tr>\r\n          </table>\r\n        </div>\r\n      </td>\r\n    </tr>\r\n    <tr>\r\n      <td width=\"100%\">\r\n        <div align=\"center\">\r\n          <table border=\"0\" width=\"100%\" cellspacing=\"4\">\r\n            <tr>\r\n              <td width=\"27%\" align=\"right\" bgcolor=\"#D5D5FF\"><font class=fontablt>�����\r\n                �������</font></td>\r\n              <td width=\"73%\" align=\"right\" bgcolor=\"#EFEFEF\"><font class=fontablt>$date</font></td>\r\n            </tr>\r\n            <tr>\r\n              <td width=\"27%\" align=\"right\" bgcolor=\"#D5D5FF\"><font class=fontablt>�����</font></td>\r\n              <td width=\"73%\" align=\"right\" bgcolor=\"#EFEFEF\"><font class=fontablt>$usertitle</font></td>\r\n            </tr>\r\n            <tr>\r\n              <td width=\"27%\" align=\"right\" bgcolor=\"#D5D5FF\"><font class=fontablt>������</font></td>\r\n              <td width=\"73%\" align=\"right\" bgcolor=\"#EFEFEF\"><font class=fontablt>$email </font></td>\r\n            </tr>\r\n            <tr>\r\n              <td width=\"27%\" align=\"right\" bgcolor=\"#D5D5FF\"><font class=fontablt>������</font></td>\r\n              <td width=\"73%\" align=\"right\" bgcolor=\"#EFEFEF\"><font class=fontablt>$homepage </font></td>\r\n            </tr>\r\n            <tr>\r\n              <td width=\"27%\" align=\"right\" bgcolor=\"#D5D5FF\"><font class=fontablt>����\r\n                ������</font></td>\r\n              <td width=\"73%\" align=\"right\" bgcolor=\"#EFEFEF\"><font class=fontablt>$showemail </font></td>\r\n            </tr>\r\n            <tr>\r\n              <td width=\"27%\" align=\"right\" bgcolor=\"#D5D5FF\"><font class=fontablt>��� ����\r\n                ���������</font></td>\r\n              <td width=\"73%\" align=\"right\" bgcolor=\"#EFEFEF\"><font class=fontablt>$allposts   ( $newsPosts  $forumPosts )</font></td>\r\n            </tr>\r\n            <tr>\r\n              <td width=\"27%\" align=\"right\" bgcolor=\"#D5D5FF\"><font class=fontablt>������\r\n                �������</font></td>\r\n              <td width=\"73%\" align=\"right\" bgcolor=\"#EFEFEF\"><font class=fontablt>$avatar_pic</font></td>\r\n            </tr>\r\n          </table>\r\n        </div>\r\n      </td>\r\n    </tr>\r\n  </table>\r\n  </center>\r\n</div>');
INSERT INTO rafia_templates VALUES (31,'arabportal','guestbook_tools',1,'<table border=\'0\' width=\"90%\" cellspacing=\"1\" >\r\n      <tr>\r\n       <td width=\'100%\'  align=\'right\'>\r\n       <div align=\"center\">\r\n        <table border=\"0\" width=\"100%\" cellspacing=\"0\" cellpadding=\"0\">\r\n          <tr>\r\n            <td width=\"50%\" align=\"right\">\r\n       $pagenum</td>\r\n            <center>\r\n            <td width=\"50%\" align=\"right\"><a href=\"$PHP_SELF?action=add\"><img border=\"0\" src=\"themes/$themepath/sign.gif\" align=\"left\"></a></td>\r\n            </tr>\r\n          </table>\r\n        </center>\r\n       </div>\r\n       </td>\r\n      </tr>\r\n       </table><br>');
INSERT INTO rafia_templates VALUES (32,'arabportal','download_comment_table',4,'<table border=\"1\" cellpadding=\"3\" cellspacing=\"0\" style=\"border-collapse: collapse\" width=\"95%\"  bordercolor=\"#C0C0C0\">\r\n      <tr>\r\n        <td valign=\"top\" bgcolor=\"#F1F1F1\" nowrap>\r\n<span class=fontablt>������:\r\n <a href=members.php?action=info&userid=$userid>$username</a> <br>\r\n  $usertitle <A name=comment$id></A>\r\n\r\n<br>\r\n  $userimgtitle <br>\r\n        ������� : $datetime <br>\r\n        �������� : $allposts <br>\r\n        <a href= mail.php?action=sendtousers&userid=$userid><img border=\'0\' src=\'themes/apt/email.gif\' alt=\'������\' width=\'16\' height=\'16\'></a>\r\n\r\n <a href=$homepage target=_blank><img border=\'0\' src=\'themes/apt/home.gif\' alt=\'����\' width=\'16\' height=\'16\'> </a>\r\n        </span><br>\r\n             </td>\r\n        <td width=\"100%\" valign=\"top\">\r\n\r\n\r\n <p dir=\"rtl\"> <span class=normal>$title  </span><font class=\"fontablt\" >\r\n <font color=\"#808080\"> [����� �������� : $date ]<br>\r\n </font>$comment </font>\r\n\r\n        <p><br>\r\n$upload_file <br>\r\n        <font color=\"#C0C0C0\">------------------</font><br>\r\n        <b><font class=fontablt> $signature</font></b>\r\n<br>\r\n          </td>\r\n      </tr>\r\n      <tr>\r\n        <td valign=\"top\" bgcolor=\"#FFFFFF\" nowrap>\r\n             </td>\r\n        <td width=\"100%\" valign=\"top\">\r\n\r\n\r\n   <a href=\"$PHP_SELF?action=addcomment&id=$postid\"ec=$id\">\r\n<img border=\"0\" src=\"themes/$themepath/quote.gif\" align=\"left\" ></a><a href=\"$PHP_SELF?action=editcomment&id=$id\"><img border=\"0\" src=\"themes/$themepath/edit.gif\" align=\"left\" ></a><a href=\"pm.php?action=sendmsg&id=$userid\"><img border=\"0\" src=\"themes/$themepath/pm.gif\"></a></td>\r\n      </tr>\r\n    </table>\r\n\r\n<BR>');
INSERT INTO rafia_templates VALUES (33,'arabportal','del_msg',1,'<body bgcolor=\"#F1F1F1\">\r\n        <br>\r\n        <br>\r\n        <br>\r\n        <br>\r\n        <br>\r\n        <br>\r\n        <br>\r\n        <br>\r\n        <div align=\"center\">\r\n        <center>\r\n        <table border=\"0\" width=\"80%\" bgcolor=\"#FFFFFF\">\r\n        <tr>\r\n        <form method=\"POST\" action=\"?action=del\">\r\n        <input type=\"hidden\" name=\"cat_id\" value=\"$cat_id\">\r\n          <input type=\"hidden\" name=\"idp\" value=\"$idp\">\r\n          <input type=\"hidden\" name=\"idc\" value=\"$idc\">\r\n        <td width=\"100%\" align=\"center\"><br>\r\n<b>\r\n<font class=fontablt>�� ��� ����� �� ����� �� ��� �������� �</font></b><br>\r\n<input class=\"button\" type=\"submit\" value=\"���\" name=\"yes\"> \r\n<input class=\"button\" type=\"button\" value=\"����� �����\" name=\"B2\" dir=\"rtl\" onClick=\"javascript:history.go(-1);\">\r\n\r\n<br>\r\n        </td>\r\n        </form>\r\n        </tr>\r\n      </table>\r\n      </center>\r\n      </div>\r\n      </body>');
INSERT INTO rafia_templates VALUES (34,'arabportal','news_cat_tools',2,'<center>\r\n      <table border=\'0\' cellspacing=\"1\" width=\"95%\" >\r\n      <tr>\r\n       <td width=\'100%\' >\r\n      \r\n        <table border=\"0\" cellspacing=\"0\" cellpadding=\"0\" width=\"100%\" >\r\n          <tr>\r\n            <td>$Jump</td>\r\n           \r\n            <td align=\"left\">$add_new_post</td>\r\n            </tr>\r\n          </table>\r\n       \r\n       </td>\r\n      </tr>\r\n       </table>\r\n</center>');
INSERT INTO rafia_templates VALUES (35,'arabportal','news_comment_table',2,'<table border=\"1\" cellpadding=\"3\" cellspacing=\"0\" style=\"border-collapse: collapse\" width=\"95%\"  bordercolor=\"#C0C0C0\">\r\n      <tr>\r\n        <td valign=\"top\" bgcolor=\"#F1F1F1\" nowrap>\r\n<span class=fontablt>������:\r\n <a href=members.php?action=info&userid=$userid>$username</a> <br>\r\n  $usertitle <A name=comment$id></A>\r\n\r\n<br>$avatar_pic\r\n  $userimgtitle <br>\r\n        ������� : $datetime <br>\r\n        �������� : $allposts <br>\r\n        <a href= mail.php?action=sendtousers&userid=$userid><img border=\'0\' src=\'images/mail.gif\' alt=\'������\' width=\'25\' height=\'15\'></a>\r\n\r\n <a href=$homepage target=_blank><img border=\'0\' src=\'images/home.gif\' alt=\'����\' width=\'23\' height=\'16\'> </a>\r\n        </span><br>\r\n             </td>\r\n        <td width=\"100%\" valign=\"top\">\r\n\r\n\r\n <p dir=\"rtl\"> <span class=normal>$title  </span><font class=\"fontablt\" >\r\n <font color=\"#808080\"> [����� �������� : $date ]<br>\r\n </font>$comment </font>\r\n\r\n        <p><br>\r\n$upload_file <br>\r\n        <font color=\"#C0C0C0\">------------------</font><br>\r\n        <b><font class=fontablt> $signature</font></b>\r\n<br>\r\n          </td>\r\n      </tr>\r\n      <tr>\r\n        <td valign=\"top\" bgcolor=\"#FFFFFF\" nowrap>\r\n             </td>\r\n        <td width=\"100%\" valign=\"top\">\r\n\r\n\r\n   <a href=\"$PHP_SELF?action=addcomment&id=$postid&qc=$id\">\r\n<img border=\"0\" src=\"themes/$themepath/quote.gif\" align=\"left\" ></a><a href=\"$PHP_SELF?action=editcomment&id=$id\"><img border=\"0\" src=\"themes/$themepath/edit.gif\" align=\"left\" ></a><a href=\"pm.php?action=sendmsg&id=$userid\"><img border=\"0\" src=\"themes/$themepath/pm.gif\"></a></td>\r\n      </tr>\r\n    </table>\r\n\r\n<BR>');
INSERT INTO rafia_templates VALUES (36,'arabportal','users_tools',3,'<a href=\"members.php?action=cp\">\r\n��������</font></a> | \r\n<a href=pm.php>������� ������ : ($pmumrows )</font></a>   | <a href=members.php?action=logout>����� ������</font></a> \r\n$isadmin');
INSERT INTO rafia_templates VALUES (37,'arabportal','blocm',7,'<!-- BLOCK START -->\r\n<HR noShade color=#000000  SIZE=1>\r\n<table width=100% bgcolor=789C70     border=\"0\" cellpadding=\"1\" cellspacing=\"0\">\r\n<tr><td width=\'100%\' valign=\'top\' align=center>\r\n\r\n<font class=fontht>\r\n{block_head}\r\n</font></td>\r\n</tr></table>\r\n<HR noShade color=#000000  SIZE=1>\r\n\r\n<table width=100% border=0 cellpadding=\"4\" cellspacing=\"0\" >\r\n<tr><td width=100% align=\"right\">\r\n{block_center}\r\n</td></tr></table>\r\n   <!-- BLOCK END -->');
INSERT INTO rafia_templates VALUES (38,'arabportal','table_cat_module',1,'<table border=\'0\' width=\'96%\' cellspacing=\'0\'><tr>\r\n               <td width=\'100%\' valign=bottom><p align=\'right\' class=forum_alt2>               \r\n               <IMG height=21 src=themes/apt/navbits_start.gif width=21 align=absMiddle border=0> \r\n<A href=index.php>$sitetitle</A>\r\n            <BR>\r\n            <IMG height=15 src=themes/apt/icon_bar.gif width=15 align=absMiddle border=0>\r\n            <IMG height=21 src=themes/apt/navbits_finallink.gif width=21 align=absMiddle border=0>$modulename             \r\n               </td></tr></table>');
INSERT INTO rafia_templates VALUES (39,'arabportal','forum_list_pagenum',3,'<table border=0 cellspacing=\"0\" style=\"border-collapse: collapse; border-width: 0\" bordercolor=\"#111111\" width=\"96%\" id=\"AutoNumber7\">\r\n    <tr>\r\n      <td width=\"100%\" valign=\"bottom\">\r\n      $pagenum\r\n      </td>\r\n    </tr>\r\n  </table>');
INSERT INTO rafia_templates VALUES (40,'arabportal','forum_list_top',3,'<table border=\"0\" width=\"95%\" id=\"table11\" cellpadding=\"2\">\r\n			<tr>\r\n				<td class=small>\r\n				</td>\r\n				<td align=\"left\"><a href=\"$PHP_SELF?action=add&cat_id=$cat_id\">\r\n				<img border=\"0\" src=\"themes/$themepath/$cat_img\" width=\"98\" height=\"24\"></a></td>\r\n			</tr>\r\n		</table>');
INSERT INTO rafia_templates VALUES (41,'arabportal','forum_list_middle',3,'<table border=\"0\" width=\"95%\" id=\"table4\" cellspacing=\"1\" cellpadding=\"0\">\r\n			<tr>\r\n				<td class=\"forum_header\">&nbsp;</td>\r\n				<td class=\"forum_header\">&nbsp;</td>\r\n				<td width=\"100%\" class=\"forum_header\">��������</td>\r\n				<td  class=\"forum_header\" nowrap>������</td>\r\n				<td class=\"forum_header\">������</td>\r\n				<td class=\"forum_header\">������</td>\r\n				<td class=\"forum_header\" width=200>��� ������</td>\r\n			</tr>\r\n               $forum_topic_list\r\n			<tr>\r\n				<td class=\"forum_header\" colspan=\"7\" style=\"text-align: left\">\r\n\r\n\r\n<form method=\"get\">\r\n<span class=small>\r\n<input type=\"hidden\" name=\"action\" value=\"list\">\r\n<input type=\"hidden\" name=\"cat_id\" value=\"$cat_id\">\r\n	����� ��� <select name=\"orderby\" size=\"1\">\r\n	<option value=\"date\" selected>����� �������</option>\r\n	<option value=\"reader\">��� ������</option>\r\n	<option value=\"comment\">��� ���������</option>\r\n	</select><select name=\"dir\" size=\"1\">\r\n	<option value=\"ASC\" selected>������</option>\r\n	<option value=\"DESC\">������</option>\r\n	\r\n	</select> \r\n	<input type=\"submit\" value=\"����\" class=\"button\">\r\n</span>\r\n\r\n\r\n				</td>\r\n			</tr>\r\n			</form>\r\n		</table>');
INSERT INTO rafia_templates VALUES (42,'arabportal','forum_main_bottom',3,'<table border=\"0\" width=\"95%\" id=\"table8\" cellspacing=\"1\" cellpadding=\"0\">\r\n<tr>\r\n<td class=\"forum_header\" style=\"text-align: right\" colspan=\"2\">�������� �������</td>\r\n</tr>\r\n<tr>\r\n<td class=\"forum_alt1\" width=\"30\" bgcolor=\"#EEEEEE\">\r\n				<img border=\"0\" src=\"themes/apt/stats.gif\" width=\"30\" height=\"30\"></td>\r\n<td align=right class=\"forum_alt1\" width=\"100%\"><span class=small>��� �������� ( $numrows ) -\r\n						��� ������ ( $numcomment )</span></td>\r\n</tr>\r\n</table>\r\n<table border=\"0\" width=\"95%\" id=\"table8\" cellspacing=\"1\" cellpadding=\"0\">\r\n<tr>\r\n<td class=\"forum_header\" style=\"text-align: right\" colspan=\"2\">&nbsp;� <a href=\"online.php\"><font color=\"#FFFFFF\">����������\r\n������</font></a>: � $online � <span class=\"small\">&nbsp;- �� ������: � $not_user � - �� �������:\r\n� $user_online � - ��� ������:� $count_file �</span></td>\r\n</tr>\r\n<tr>\r\n<td class=\"forum_alt1\" width=\"30\" bgcolor=\"#EEEEEE\">\r\n				<img border=\"0\" src=\"themes/apt/whos_online.gif\" width=\"30\" height=\"30\"></td>\r\n<td align=right  class=\"forum_alt1\" width=\"100%\"><span class=small>&nbsp;&nbsp;$users_online</span></td>\r\n</tr>\r\n</table>\r\n<table border=\"0\" width=\"95%\" id=\"table8\" cellspacing=\"1\" cellpadding=\"0\">\r\n<tr>\r\n<td class=\"forum_header\" style=\"text-align: right\" colspan=\"2\">&nbsp;� <font color=\"#FFFFFF\">������� ����� ������� �����</font>: � $online_today �</td>\r\n</tr>\r\n<tr>\r\n<td class=\"forum_alt1\" width=\"30\" bgcolor=\"#EEEEEE\">\r\n				<img border=\"0\" src=\"themes/apt/whos_online.gif\" width=\"30\" height=\"30\"></td>\r\n<td align=right class=\"forum_alt1\" width=\"100%\"><span class=small>&nbsp;&nbsp;$users_today</span></td>\r\n</tr>\r\n</table>\r\n<br>\r\n\r\n		<table border=\"0\" id=\"table9\" cellspacing=\"1\" cellpadding=\"0\" class=\"forum_alt2\">\r\n			<tr>\r\n				<td>\r\n				<img border=\"0\" src=\"themes/apt/on.gif\" width=\"21\" height=\"19\"></td>\r\n				<td class=\"small\">������� �����&nbsp;&nbsp;&nbsp;&nbsp;</td>\r\n				<td>\r\n				<img border=\"0\" src=\"themes/apt/off.gif\" width=\"21\" height=\"19\"></td>\r\n				<td class=\"small\">�� ���� ������� �����&nbsp;&nbsp;&nbsp;&nbsp;</td>\r\n				<td>\r\n				<img border=\"0\" src=\"themes/apt/lock.gif\" width=\"21\" height=\"19\"></td>\r\n				<td class=\"small\">��� ����</td>\r\n			</tr>\r\n		</table>\r\n<br>');
INSERT INTO rafia_templates VALUES (43,'arabportal','table_cat_link',1,'<br><table border=\'0\' width=\'96%\' cellspacing=\'0\'><tr>\r\n        <td width=\'100%\' valign=bottom><p align=\'right\' class=forum_alt2>\r\n        <img border=0 src=themes/apt/navbits_start.gif width=21 height=21 align=middle>\r\n        <a href=index.php><font face=\'Windows UI\'>$sitetitle</font></a> � <a href=$self><font face=\'Windows UI\'>$part</font></a> �\r\n        $CatTree\r\n        </td></tr></table><br>');
INSERT INTO rafia_templates VALUES (44,'arabportal','download_cat_tools',4,'<table border=\'0\' width=\"90%\" cellspacing=\"1\" >\r\n      <tr>\r\n       <td width=\'100%\'  align=\'right\'>\r\n       <div align=\"center\">\r\n        <table border=\"0\" width=\"100%\" cellspacing=\"0\" cellpadding=\"0\">\r\n          <tr>\r\n            <td width=\"50%\" align=\"right\">\r\n       $Jump</td>\r\n            <center>\r\n            <td width=\"50%\" align=\"right\"><a href=\"$PHP_SELF?action=add&cat_id=$cat_id\"><img border=\"0\" src=\"themes/$themepath/$cat_img\" align=\"left\"></a></td>\r\n            </tr>\r\n          </table>\r\n        </center>\r\n       </div>\r\n       </td>\r\n      </tr>\r\n       </table>');
INSERT INTO rafia_templates VALUES (45,'arabportal','download_list',4,'<table border=\"0\" cellpadding=\"0\" cellspacing=\"0\" width=\"95%\">\r\n	<tr>\r\n		<td width=\"17\" height=\"31\">\r\n		<img border=\"0\" src=\"themes/apt/news_icon\"></td>\r\n		<td background=\"themes/apt/cat.jpg\" width=\"100%\">\r\n<font class=fontablt2>$title</font>\r\n	\r\n	</td>\r\n		<td width=\"8\" height=\"31\">\r\n		<img border=\"0\" src=\"themes/apt/table_01.jpg\" width=\"8\" height=\"31\"></td>\r\n	</tr>\r\n  <tr>\r\n    <td width=\"100%\" colspan=\"3\">\r\n    <table border=\"0\" cellpadding=\"2\" style=\"border-collapse: collapse\" width=\"100%\" id=\"AutoNumber1\" class=\"info_bar\">\r\n      <tr>\r\n        <td width=\"100%\">\r\n         �������: $ratings&nbsp;\r\n                </td>\r\n        <td nowrap align=\"left\" colspan=\"3\">  $rating_avg</td>\r\n      </tr>\r\n    </table>\r\n    </td>\r\n  </tr>\r\n  \r\n</table>\r\n\r\n\r\n\r\n<table border=\'0\' width=\'95%\' bgcolor=\"#ffffff\" cellspacing=0 cellpadding=0>\r\n<tr><td width=\'32%\' valign=top bgcolor=#f1f1f1>\r\n<font class=fontablt>���� ������� :  $clicks</font>\r\n<br>\r\n<font class=fontablt>����� : $size</font><br>\r\n\r\n<font class=fontablt>������ : $c_comment </font>\r\n <BR>\r\n<font class=fontablt> ������ : $name  </font>\r\n</td>\r\n<td  height=\'100%\' valign=top>\r\n<table border=\"0\" cellpadding=\"0\" cellspacing=\"0\" width=\"100%\">\r\n<tr>\r\n  <td valign=top><font class=fontablt>$post_head</font>\r\n</td>\r\n</tr>\r\n<tr>\r\n<td valign=top>\r\n<br>\r\n<center>$download_images</center>\r\n$exp_show\r\n</td></tr>\r\n</table>\r\n</td>\r\n</tr>\r\n</table>\r\n<table border=\"0\" cellpadding=\"0\" cellspacing=\"0\" width=\"95%\">\r\n<tr>\r\n<td width=100% valign=top bgcolor=#FFFFFF align=center><p align=center>\r\n| <a href=javascript:rafiawin(\'popup.php?action=alert&id=$id\',200,400)><img border=\"0\" src=\"themes/$themepath/hidlink.gif\"></a>\r\n| <a href=javascript:rafiawin(\'popup.php?action=rated&id=$id\',200,400)><img border=\"0\" src=\"themes/$themepath/rank.gif\"></a>\r\n| <a href=\"$PHP_SELF?action=edit&id=$id\"><img border=\"0\" src=\"themes/$themepath/edit.gif\"></a> |\r\n</td>\r\n</tr>\r\n</table>\r\n<hr color=\"#C0C0C0\" width=\"95%\" size=\"1\">');
INSERT INTO rafia_templates VALUES (46,'arabportal','news_cat',2,'<BR><table border=\"0\" cellpadding=\"0\" cellspacing=\"0\" width=\"100%\" >\r\n         <tr>\r\n           <td width=\"100%\" style=\"padding: 3\"><font class=fontht><img border=\"0\" src=\"images/b1.gif\" align=\"middle\" width=\"8\" height=\"8\">  <a href=news.php?action=list&cat_id=$id> $title</a></font>   \r\n<span class=fontablt>           <img border=\"0\" src=\"images/topics.gif\" align=\"middle\" alt=\"��� ��������\">\r\n           <font color=\"#C0C0C0\">[$numrows]  \r\n           <img border=\"0\" src=\"images/replys.gif\" alt=\"��� ������\" align=\"absmiddle\" > \r\n           [$numcomment]</font></span></td>\r\n         </tr>\r\n         <tr>\r\n           <td width=\"100%\" class=fontablt><font color=\"#808080\">    $dsc</font></td>\r\n         </tr>\r\n       </table>');
INSERT INTO rafia_templates VALUES (47,'arabportal','forum_comment_table',3,'<table border=\"0\" width=\"95%\" id=\"table4\" cellspacing=\"1\" cellpadding=\"0\">\r\n			<tr>\r\n				<td width=\"100%\" class=\"forum_alt3\">\r\n				<table border=\"0\" width=\"100%\" id=\"table16\" >\r\n					<tr>\r\n						<td width=\"20%\" class=\"forum_alt1\" valign=\"top\">\r\n\r\n<span class=small>\r\n������: <a href=\"members.php?action=info&userid=$userid\">$username</a><br>\r\n$usertitle<br>$userimgtitle<br>\r\n$avatar_pic\r\n������� : $datetime<br>\r\n��������� :  $allposts <br>\r\n  <a href=\"mail.php?action=sendtousers&userid=$userid\">\r\n <img border=\'0\' src=\'themes/$themepath/email.gif\' alt=\'������\'>\r\n  </a>\r\n<a href=$homepage target=_blank><img border=\'0\' src=\'themes/$themepath/home.gif\' alt=\'������ ������\' ></a>\r\n<br>\r\n</span>\r\n</td>\r\n\r\n\r\n						<td width=\"80%\" valign=\"top\" class=\"normal\" colspan=\"2\"><span class=small> <A name=comment$id></A>\r\n						 ��� ��  $date -   ������ : $reader\r\n    -   ���� : $c_comment </font>\r\n\r\n    </span>\r\n						<hr color=\"#7394B6\" size=\"1\">\r\n                  <b>$title</b>\r\n                 $comment\r\n\r\n                 <br>\r\n$upload_file<br>\r\n      <hr color=\"#7394B6\" size=\"1\">\r\n       <center>$signature</center>\r\n        </td>\r\n					</tr>\r\n					<tr>\r\n						<td width=\"20%\" class=\"small\" valign=\"top\" align=\"center\">\r\n						 $ip_address </td>\r\n						<td width=\"40%\" valign=\"top\" class=small>\r\n      </td>\r\n						<td width=\"40%\" valign=\"top\" align=\"left\">\r\n\r\n               <a href=\"pm.php?action=sendmsg&id=$userid\">\r\n               <img border=\"0\" src=\"themes/$themepath/pm.gif\" width=\"93\" height=\"24\">\r\n               </a>\r\n\r\n\r\n      <a href=\"$PHP_SELF?action=editcomment&id=$id\"><img border=\"0\" src=\"themes/$themepath/edit.gif\"></a>\r\n       <a href=\"$PHP_SELF?action=addcomment&id=$postid&qc=$id\"><img border=\"0\" src=\"themes/$themepath/quote.gif\" width=\"67\" height=\"24\"></a>\r\n\r\n     			<a href=\"#top\">\r\n				<img border=\"0\" src=\"themes/$themepath/top.gif\" width=\"24\" height=\"24\"></a></td>\r\n					</tr>\r\n				</table>\r\n               </td>\r\n				</tr>\r\n			</table>');
INSERT INTO rafia_templates VALUES (48,'arabportal','popup_msg',1,'<body bgcolor=\'#FFFFFF\'>\r\n        <br>\r\n        <div align=\'center\'>\r\n        <center>\r\n        <table border=\'0\' width=\'80%\' bgcolor=\'#F1F1F1\'>\r\n        <tr>\r\n        <td width=\'100%\' align=\'center\'><br><font class=fontablt>$msg<br><br></td>\r\n        </tr>\r\n        </table>\r\n        </center>\r\n        </div>');
INSERT INTO rafia_templates VALUES (49,'arabportal','Login_main',1,'<body topmargin=\"0\" leftmargin=\"0\" rightmargin=\"0\" bottommargin=\"0\" >\r\n\r\n\r\n$pagehd\r\n<center>\r\n<table border=\"0\" width=\"$themewidth\" id=\"table4\" cellspacing=\"0\" cellpadding=\"0\">	\r\n	<tr>\r\n		<td width=\"25\">\r\n		<img border=\"0\" src=\"themes/apt/apt_26.gif\" width=\"25\" height=\"25\"></td>\r\n		<td background=\"themes/apt/apt_25.gif\" width=\"64\"> </td>\r\n		<td width=\"174\">\r\n		<img border=\"0\" src=\"themes/apt/apt_24.gif\" width=\"174\" height=\"25\"></td>\r\n		<td width=\"100%\" background=\"themes/apt/apt_25.gif\"> \r\n<!--INC dir=\"block\" file=\"last_10_news.php\" -->		\r\n		</td>\r\n		<td width=\"187\">\r\n		<img border=\"0\" src=\"themes/apt/apt_22.gif\" width=\"187\" height=\"25\"></td>\r\n	</tr>\r\n</table>\r\n\r\n\r\n\r\n\r\n\r\n<table border=0 cellpadding=\"0\" cellspacing=\"0\"  width=\"$themewidth\"  height=\"100%\" bgcolor=#FFFFFF>\r\n<tr>\r\n<!-- RightStart -->\r\n<td width=\'160\' valign=\'top\' align=\'center\' nowrap style=\"border-top:1px solid #FFFFFF; border-left:1px solid #D9D9D9; \" bgcolor=#F1F1F1>\r\n<br>\r\n</td>\r\n<!-- RightEnd -->\r\n<td width=\'100%\' valign=\'top\' align=\'center\' style=\"padding:5px\">\r\n<font class=fontablt>\r\n&nbsp;<table border=\'1\' width=\'90%\' bordercolor=\'#F1F1F1\' bgcolor=\'#FFFFFF\' cellpadding=\'4\' cellspacing=\'0\' id=\"table5\">\r\n<tr><td width=\'100%\' align=\'center\'>\r\n<font class=fontablt>                   �� ���� �� ����� ��� �������\r\n���� ��� ���� �����  ������\r\n                 �� �� ���� ����� ������ ������ ������� ��� �� ��� �� ������ ����� ����\r\n</td></tr></table><br>\r\n\r\n\r\n <!-- BLOCK START -->\r\n<table width=350  border=\"0\" cellspacing=\"0\" id=\"table6\">\r\n<tr>\r\n<td width=\"100%\" bgcolor=\"#34597D\" style=\"padding-top: 3; padding-bottom: 3\" class=\"forum_header\">\r\n\r\n����� ������\r\n</td>\r\n</tr></table>\r\n\r\n<table width=100% border=0 cellpadding=\"4\" cellspacing=\"0\" id=\"table7\" >\r\n<tr><td width=100%><center>\r\n<table border=\'0\' width=\'350\' id=\"table8\" cellpadding=\"0\" cellspacing=\"0\"><tr><td width=\'100%\'>\r\n <form method=post action=members.php?action=login>\r\n    <tr><td bgcolor=\"#F2F2F2\" align=\"center\"> <font face=tahoma size=2>��������</font></td></tr>\r\n    <tr><td bgcolor=\"#F2F2F2\" align=\"center\"><input type=textbox name=username size=13>\r\n    </td></tr><tr><td bgcolor=\"#F2F2F2\" align=\"center\"> <font face=tahoma size=2 >���� ������</font></td></tr>\r\n    <tr><td bgcolor=\"#F2F2F2\" align=\"center\"><input type=password name=userpass size=13>\r\n    </td></tr><tr><td bgcolor=\"#F2F2F2\" align=\"center\"><input type=submit value=����>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<a href=javascript:rafiawin(\'popup.php?action=remind\',250,350)><font face=tahoma size=2 >����� ������ʿ</font></a>\r\n    </td></tr></form>\r\n</td></tr></table></center>\r\n</td></tr></table>\r\n   </td>\r\n<!-- LeftStart -->\r\n<td width=\'160\' valign=\'top\' align=\'center\' nowrap style=\"border-top:1px solid #FFFFFF; border-right:1px solid #D9D9D9; \" bgcolor=#F1F1F1>\r\n&nbsp;</td>\r\n<!-- LeftEnd -->\r\n</tr>\r\n    </table></center>\r\n\r\n$pageft');
INSERT INTO rafia_templates VALUES (50,'arabportal','download_topic',4,'<body bgcolor=\"#DEE9ED\" topmargin=\"0\" leftmargin=\"0\">\r\n\r\n$pagehd\r\n\r\n       <table border=1 cellpadding=\"4\" cellspacing=\"0\" style=\"border-collapse: collapse; border-width: 0\" bordercolor=\"111111\" width=\"100%\" id=\"AutoNumber7\" bgcolor=$bgcolor2>\r\n        <tr>\r\n        <td width=\'20%\' valign=\'top\' align=\'center\'bgcolor=$bgcolor1>\r\n$right_menu\r\n         <br></td><td width=\'60%\' valign=\'top\' align=\'center\'><br>\r\n\r\n\r\n       $next_old\r\n       $next_new\r\n<br>\r\n$table_cat_link\r\n$download_table\r\n<br>\r\n$post_tools\r\n$admin_Jump\r\n$comment_table\r\n<br>\r\n$post_tools2\r\n$list_Jump\r\n<br>\r\n </td>\r\n<td width=\'20%\' valign=\'top\' align=\'center\'bgcolor=$bgcolor1>\r\n$left_menu\r\n\r\n</tr>\r\n    </table></center></div>\r\n$pageft\r\n</body>');
INSERT INTO rafia_templates VALUES (51,'arabportal','news_list_pagenum',2,'<Br>\r\n  <table border=0 cellpadding=\"4\" cellspacing=\"0\" width=\"95%\" >\r\n    <tr>\r\n      <td width=\"50%\" valign=\"bottom\">\r\n      $pagenum\r\n      </td>\r\n\r\n\r\n            <td width=\"50%\" align=\"right\">\r\n$add_new_post\r\nwwwwwwwwww\r\n</td>\r\n\r\n   </tr>\r\n  </table>');
INSERT INTO rafia_templates VALUES (52,'arabportal','search_form',1,'<p><br>\r\n\r\n</p>\r\n\r\n<form name=search_form  action=search.php method=post>     <center>\r\n                  <table cellpadding=\"0\" cellspacing=\"0\" width=\"90%\" id=\"table1\">\r\n\r\n\r\n                    <tr>\r\n<td width=\"2%\" height=\"31\">\r\n<img border=\"0\" src=\"themes/$themepath/table_03.jpg\" width=\"17\" height=\"31\"></td>\r\n<td width=\"100%\" height=\"31\" background=\"themes/$themepath/table_02.jpg\">\r\n<p align=\"center\"><font class=fontablt2> <b>���� �����</b> </font> </td>\r\n                          <td width=\"1%\" height=\"31\">\r\n        <img border=\"0\" src=\"themes/$themepath/table_01.jpg\" width=\"8\" height=\"31\"></td>\r\n                    </tr>\r\n\r\n                </table>\r\n\r\n\r\n                  <table cellpadding=\"0\" cellspacing=\"0\" width=\"90%\">\r\n\r\n\r\n                    <tr>\r\n                        <td class=\"row1\" valign=\"top\" bgcolor=\"#F1F1F1\">\r\n                        	<div align=\"center\">\r\n                        	<table cellspacing=\"4\" cellpadding=\"0\" width=\"100%\" border=\"1\" style=\"border-collapse: collapse\" bordercolor=\"#C0C0C0\">\r\n                        	<tr>\r\n                        	 <td valign=\"top\" width=\"15\">\r\n                            </td>\r\n                            <td valign=\"top\" height=\"0\">\r\n\r\n  <b> <span lang=\"ar-sa\">���� ����� </span></b>\r\n\r\n  <select name=\"searchin\" style=\"font-weight: 700\">\r\n<option selected value=\"\">����� �� �</option>\r\n<option value=\"rafia_news\">�������</option>\r\n<option value=\"rafia_forum\">�������</option>\r\n<option value=\"rafia_download\">�������</option>\r\n<option value=\"rafia_links\">�������</option>\r\n</select><b>\r\n<br>  <span lang=\"ar-sa\"> ���� �����</span></b><input name=searchfor size=25 style=\"font-weight: 700\"></td>\r\n                            <td valign=\"top\" height=\"0\" >\r\n\r\n  <span lang=\"ar-sa\">&nbsp;<input type=\"radio\" name=\"spell\" value=\"1\"> �����\r\n	������� ����� ����� ��������</span>\r\n	\r\n	<br>\r\n	  <span lang=\"ar-sa\">&nbsp;<input type=\"radio\" name=\"spell\" value=\"0\" checked> ������ ������</span>\r\n	</td>\r\n                            </tr>\r\n                            </table>\r\n                        	</div>\r\n                        </td>\r\n                    </tr>\r\n                </table>\r\n\r\n\r\n               &nbsp;<p>&nbsp;</p>\r\n               \r\n                <table cellpadding=\"0\" style=\"border-collapse: collapse; \" width=\"89%\">\r\n\r\n                    <tr>\r\n<td width=\"2%\" background=\"themes/$themepath/table_02.jpg\" height=\"31\">\r\n<img border=\"0\" src=\"themes/$themepath/table_03.jpg\" width=\"17\" height=\"31\"></td>\r\n<td width=\"96%\" background=\"themes/$themepath/table_02.jpg\" height=\"31\">\r\n<p align=\"center\">\r\n<font class=fontablt2> <b>����� �����</b> </font>\r\n</td>\r\n                          <td width=\"1%\" background=\"themes/$themepath/table_02.jpg\" height=\"31\">\r\n        <img border=\"0\" src=\"themes/$themepath/table_01.jpg\" width=\"8\" height=\"31\"></td>\r\n                    </tr>\r\n\r\n                    <tr>\r\n                        <td class=\"row1\" valign=\"top\" colspan=\"3\" bgcolor=\"#F1F1F1\">\r\n                         <div align=\"center\">\r\n                         <table cellspacing=\"4\" cellpadding=\"0\" width=\"100%\" border=\"1\" style=\"border-collapse: collapse\" bordercolor=\"#C0C0C0\">\r\n                         <tr>\r\n                        	 <td valign=\"top\">\r\n                        		<b>����� ��..</b>\r\n                       			<br>\r\n								<select name=\"from_date\" class=\"forminput\">\r\n								<option value=\"1\">��� �����\r\n								<option value=\"7\">��� �����\r\n								<option value=\"30\" selected>��� ���\r\n                               <option value=\"182\">��� ��� ����\r\n                               <option value=\"365\">��� ���\r\n								<option value=\"0\">��� �������\r\n								</select>\r\n                             	<br>\r\n<input type=\"radio\" name=\"from_type\" value=\"ASC\"> ������  <br>\r\n\r\n<input type=\"radio\" name=\"from_type\" value=\"DESC\" checked> ���<span lang=\"ar-sa\">���</span></td>\r\n                            <td valign=\"top\">\r\n								<b>��� ��������� �� ���� �������</b><br>\r\n								<select name=\"search_max\">\r\n<option value=\"30\">30</option>\r\n<option value=\"10\">10</option>\r\n<option value=\"20\">20</option>\r\n<option value=\"40\">40</option>\r\n<option value=\"50\">50</option>		<option value=\"5\">5</option>					</select>\r\n								<br><input type=\"radio\" name=\"search_order\" value=\"DESC\" checked>����� \r\n								������\r\n								<br><input type=\"radio\" name=\"search_order\" value=\"ASC\">����� \r\n								������\r\n                            </td>\r\n                            </tr>\r\n                            </table>\r\n                        	</div>\r\n                        </td>\r\n                    </tr>\r\n                </table>\r\n\r\n                <p align=\"center\">\r\n&nbsp;<p align=\"center\">\r\n<input type=submit name=submit value=��� style=\"border-style: solid; border-width: 1; padding-left: 4; padding-right: 4; padding-top: 1; padding-bottom: 1\"></form>');
INSERT INTO rafia_templates VALUES (53,'arabportal','news_table',2,'<table border=\"0\" cellpadding=\"3\" cellspacing=\"3\" width=\"100%\">\r\n  <tr>\r\n    <td valign=\"top\" colspan=\"2\"><div class=news_title>\r\n<img border=\"0\" src=\"themes/$themepath/news_icon.gif\" width=\"12\" height=\"12\"> $title</div></td>\r\n  </tr>\r\n  <tr>\r\n    <td align=right valign=\"top\">\r\n<div class=article_info>\r\n			<img border=\"0\" src=\"themes/$themepath/info.gif\" width=\"13\" height=\"18\"> ������:  <a href=members.php?action=info&userid=$userid>$username</a><br> ������ : $date </div></td>\r\n    <td valign=\"top\">\r\n		<a href=javascript:rafiawin(\'popup.php?action=printnews&id=$id\',500,600)><img border=\"0\" src=\"themes/$themepath/print_page.gif\" title=\"���� �������\" align=\"middle\"></a>\r\n		<a href=mail.php?action=sendpage target=_blank><img border=\"0\" src=\"themes/$themepath/send_f.gif\" title=\"���� ��� ����\" align=\"middle\"></a>\r\n<a href=pdf/show.php?id=$id><img border=\"0\" src=\"themes/$themepath/pdf.gif\" title=\"PDF ����� ���\" align=\"middle\"></a>\r\n<br>\r\n<a href=translate.php target=_blank><img border=\"0\" src=\"themes/$themepath/t.gif\" title=\"����� �������\" align=\"middle\"></a>\r\n		<a href=\"archive/news/save/$id.html\"><img border=\"0\" src=\"themes/$themepath/save.gif\" align=\"middle\"></a>\r\n		<a href=\"$PHP_SELF?action=addcomment&id=$postid\"ec=\"$id\"><img border=\"0\" src=\"themes/$themepath/add_comment.gif\" align=\"middle\"></a>&nbsp;&nbsp;</td>\r\n	\r\n</td>\r\n  </tr>\r\n </table>\r\n\r\n\r\n<table border=\"0\" cellpadding=\"3\" cellspacing=\"3\"  width=\"100%\">\r\n  <tr>\r\n    <td align=right width=\"100%\" class=\"normal\">\r\n<div class=article_pic>$newsimage</div>\r\n$news_head<br>    \r\n$post </td>\r\n  </tr>\r\n  <tr>\r\n    <td width=\"100%\"> \r\n\r\n\r\n<div class=article_info><img border=\"0\" src=\"themes/$themepath/info.gif\" width=\"13\" height=\"18\"> ���� �������: $reader -  ���������: $c_comment</div></td>\r\n  </tr>\r\n</table>\r\n<hr color=\"#C0C0C0\" width=\"95%\" size=\"1\" style=\"border-style: dotted; border-width: 1px\"><br>\r\n<B>$topic_nav</b>');
INSERT INTO rafia_templates VALUES (54,'arabportal','post_tools',1,'<table border=\"0\" width=\"95%\" id=\"table11\" cellpadding=\"2\">\r\n			<tr>\r\n				<td class=small>$pagenum</td>\r\n				<td align=\"left\">\r\n\r\n$add_new_post\r\n\r\n$add_new_reply\r\n\r\n    </td>\r\n			</tr>\r\n		</table>');
INSERT INTO rafia_templates VALUES (55,'arabportal','announcement',1,'');
INSERT INTO rafia_templates VALUES (56,'arabportal','members_link',6,'<center><table border=\"0\" width=\"304\"><tr>\r\n      <td width=\"76\" bgcolor=\"$bgcolor5\">\r\n       <p align=\"center\"><a href=\"members.php?action=cp\">\r\n		<img border=\"0\" src=\"themes/apt/personal.jpg\" width=\"76\" height=\"56\"></a></td>\r\n       <td width=\"76\" bgcolor=\"$bgcolor5\">\r\n       <p align=\"center\">   <a href=\"pm.php\">\r\n		<img border=\"0\" src=\"themes/apt/pr_msg.jpg\" width=\"76\" height=\"56\"></a></td>\r\n     <td width=\"76\" bgcolor=\"$bgcolor5\">\r\n      <p align=\"center\"><a href=\"members.php?action=edit\">\r\n		<img border=\"0\" src=\"themes/apt/setting.jpg\" width=\"76\" height=\"56\"></a></td>\r\n      <td width=\"76\" bgcolor=\"$bgcolor5\">\r\n      <p align=\"center\"><a href=\"members.php?action=changepass\">\r\n		<img border=\"0\" src=\"themes/apt/change_pass.jpg\" width=\"76\" height=\"56\"></a></td>\r\n       </tr></table></center>');
INSERT INTO rafia_templates VALUES (57,'arabportal','register_policy',6,'<center><table border=\"0\" width=\"80%\" id=\"table1\" cellspacing=\"0\" cellpadding=\"0\">\r\n	<tr>\r\n		<td width=\"9\" height=\"31\">\r\n		<img border=\"0\" src=\"themes/apt/menu_03.jpg\" width=\"9\" height=\"31\"></td>\r\n		<td background=\"themes/apt/menu_02.jpg\" width=\"100%\"><center><font class=fontablt2>����� �������</font></center></td>\r\n		<td width=\"9\" height=\"31\">\r\n		<img border=\"0\" src=\"themes/apt/menu_01.jpg\" width=\"9\" height=\"31\"></td>\r\n	</tr>\r\n</table>\r\n<table border=\'1\' width=\'80%\' bgcolor=\'$bgcolor1\' cellspacing=\"0\" cellpadding=\"0\" bordercolor=\"#C0C0C0\">\r\n        <tr>\r\n        <td width=\'100%\'>\r\n        <font class=fontablt>\r\n        <li>��� �������� ���� �� ����  ���� �� �����.</li>\r\n        <li>��� �������� ��� �� ���� ���� �� ����� ����.</li>\r\n        <li>���� ������ ��� �� ���� ���� �� ����� ����.</li>\r\n        <li>����� �������� ������ ������ ���� ��� ������ �� ��� ������.</li>\r\n        <br><br><font color=\"#FF0000\">������:</font> ������ ����� ����� ������� \r\n		����� � �� ������ ������ �������� ������� ����� �� (<font color=\"#FF0000\">*</font>)<br><br></td>\r\n        </tr> </table></center>');
INSERT INTO rafia_templates VALUES (58,'arabportal','index_table',1,'<table border=\"0\" cellpadding=\"0\" cellspacing=\"0\" width=\"95%\">\r\n	<tr>\r\n		<td height=\"28\">\r\n<div class=news_title>\r\n	<img border=\"0\" src=\"themes/apt/news_icon.gif\" width=\"12\" height=\"12\"> <a href=\"$news_link\">$title</a></div>\r\n	\r\n		</td>\r\n	</tr>\r\n  <tr>\r\n    <td width=\"100%\">\r\n    <table border=\"0\" cellpadding=\"2\" style=\"border-collapse: collapse\" width=\"100%\" id=\"AutoNumber1\" class=\"article_info\">\r\n      <tr>\r\n        <td width=\"100%\">\r\n	<div class=\"article_info\">	<img border=\"0\" src=\"themes/apt/info.gif\" width=\"13\" height=\"18\"> ������: <a href=\"members.php?action=info&userid=$userid\">$name</a> ������: $date </div></td>\r\n        <td nowrap align=\"left\" colspan=\"3\">  </td>\r\n      </tr>\r\n    </table>\r\n    </td>\r\n  </tr>\r\n  <tr>\r\n    <td width=\"100%\" style=\"padding-top: 5; padding-bottom: 5; text-align:justify\">\r\n$newsimage <font class=\"home_text\">$news_head </font>\r\n		</td>\r\n  </tr>\r\n  <tr>\r\n    <td width=\"100%\" class=\"info_bar2\" style=\"padding-top: 5; padding-bottom: 5\">\r\n    <p align=\"right\"><a href=\"$news_link\">\r\n	<img border=\"0\" src=\"themes/apt/more.gif\" width=\"56\" height=\"13\" align=\"left\"></a>\r\n<div class=\"article_info\">	&nbsp; \r\n	������: $reader &nbsp;&nbsp;&nbsp;���������: $numrows </div></td>\r\n  </tr>\r\n  <tr>\r\n    <td width=\"100%\">$pagenum </td>\r\n  </tr>\r\n</table>\r\n<hr color=\"#C0C0C0\" width=\"95%\" size=\"1\" style=\"border-style: dotted; border-width: 1px\">');
INSERT INTO rafia_templates VALUES (59,'arabportal','download_list_pagenum',4,'<Br>\r\n  <table border=0 cellpadding=\"4\" cellspacing=\"0\" width=\"95%\" >\r\n    <tr>\r\n      <td width=\"50%\" valign=\"bottom\">\r\n      $pagenum\r\n      </td>\r\n\r\n\r\n            <td width=\"50%\" align=\"right\"><a href=\"$PHP_SELF?action=add&cat_id=$cat_id\"><img border=\"0\" src=\"themes/$themepath/$cat_img\" align=\"left\"></a></td>\r\n\r\n   </tr>\r\n  </table>');
INSERT INTO rafia_templates VALUES (60,'arabportal','index_block',1,'<!--INC dir=\"block\" file=\"index_download.php\" -->\r\n<!--INC dir=\"block\" file=\"links.php\" -->');
INSERT INTO rafia_templates VALUES (61,'arabportal','show_members_list',6,'<table border=\'1\' width=\'80%\' bgcolor=\'$bgcolor1\' cellspacing=\"0\" cellpadding=\"0\" bordercolor=\"#C0C0C0\" style=\"border-collapse: collapse\">\r\n \r\n    <tr>\r\n      <td width=\"7%\" bgcolor=\"$color\" align=\"center\">$userid </td>\r\n      <td width=\"30%\" bgcolor=\"$color\"><font class=fontablt>  \r\n		<a href=\"members.php?action=info&userid=$userid\">$username</a></font></td>\r\n      <td width=\"33%\" bgcolor=\"$color\"><font class=fontablt>������� : $allposts </font></td>\r\n      <td width=\"40%\" bgcolor=\"$color\" align=\"center\"><font class=fontablt>\r\n     <a href=\'mail.php?action=sendtousers&userid=$userid\' ><img border=\'0\' src=\'themes/apt/email.gif\' alt=\'������\' width=\'16\' height=\'16\'></a>  \r\n     <a href=\'$homepage\' target=_blank><img border=\'0\' src=\'themes/apt/home.gif\' alt=\'����\' width=\'16\' height=\'16\'> </a>\r\n   </font></td>\r\n    </tr>\r\n</table></center>');
INSERT INTO rafia_templates VALUES (62,'arabportal','index_table_cat_title',1,'<table border=\'0\' cellpadding=\'0\' cellspacing=\'0\' width=\'95%\'>\r\n	<tr>\r\n		<td width=\'8\' height=\'28\'>\r\n		<img border=\'0\' src=\'themes/apt/cat_right.gif\' width=\'8\' height=\'28\'></td>\r\n		<td background=\'themes/apt/cat_bg.gif\' width=\'100%\'>\r\n<div class=\"news_cat_title\"><a title=\"$ctitle\" href=\"news.php?action=list&cat_id=$cid\">$ctitle</a></div>\r\n\r\n	</td>\r\n		<td width=\'7\' height=\'28\'>\r\n		<img border=\'0\' src=\'themes/apt/cat_left.gif\' width=\'7\' height=\'28\'></td>\r\n	</tr></table>');
INSERT INTO rafia_templates VALUES (63,'arabportal','upblock',7,'<!-- BLOCK START -->\r\n<TABLE WIDTH=\"100%\" BORDER=0 CELLPADDING=0 CELLSPACING=0>\r\n	<TR>\r\n		<TD width=\"9\" height=\"24\" background=\"themes/apt/cat_bg.jpg\">\r\n			&nbsp;</TD>\r\n		<TD background=\"themes/apt/cat_bg.jpg\" width=\"100%\">\r\n			\r\n<p align=\"center\">\r\n			\r\n<font class=side_menu_head>{block_head}</font>			\r\n			</TD>\r\n		<TD width=\"9\" height=\"24\" background=\"themes/apt/cat_bg.jpg\">\r\n			&nbsp;</TD>\r\n	</TR>\r\n  </tr>\r\n  <tr>\r\n    <td colspan=\"3\" bgcolor=\"#F1F1F1\" style=\"padding-right: 5px\" class=side_menu_center>\r\n<!-- Start -->\r\n      <CENTER>\r\n      <MARQUEE \r\n      style=\"FONT-SIZE: 12pt; COLOR: #000000; FONT-FAMILY: Times New Roman; TAHOMA: 150%\" \r\n      scrollAmount=5 scrollDelay=200 direction=up width=\"100%\" \r\n      height=161>{block_center}</MARQUEE></CENTER>\r\n<!-- End -->    \r\n<BR> \r\n</td>\r\n  </tr>	\r\n</TABLE><br>\r\n<!-- BLOCK END -->');
INSERT INTO rafia_templates VALUES (64,'arabportal','turn_off_site',1,'<body bgcolor=\"#FFFFFF\">\r\n        <br>\r\n        <br>\r\n        <br>\r\n        <br>\r\n        <br>\r\n        <br>\r\n        <br>\r\n        <br>\r\n        <div align=\"center\">\r\n        <center>\r\n        <table border=\"0\" width=\"80%\" bgcolor=\"#EBEBEB\">\r\n        <tr>\r\n        <td width=\"100%\" align=\"center\"><font class=fontablt><b>$turn_off_msg</font></b><br><br>\r\n\r\n    <table width=\"100%\" border=\"0\" cellpadding=\"4\" cellspacing=\"0\" id=\"table7\">\r\n      <tr>\r\n        <td width=\"100%\"><center>\r\n        <table border=\"0\" width=\"350\" id=\"table8\" cellpadding=\"0\" cellspacing=\"0\">\r\n          <tr>\r\n            <td width=\"100%\">\r\n            <form method=\"post\" action=\"members.php?action=login\">\r\n            </td>\r\n            </tr>\r\n            <tr>\r\n              <td bgcolor=\"#F2F2F2\" align=\"center\"><span lang=\"ar-om\"><b>���� \r\n              ������ ����� ���</b></span></td>\r\n            </tr>\r\n            <tr>\r\n              <td bgcolor=\"#F2F2F2\" align=\"center\">\r\n              <font face=\"tahoma\" size=\"2\">\r\n              �������� : </font>\r\n              <input type=\"textbox\" name=\"username\" size=\"13\"> </td>\r\n            </tr>\r\n            <tr>\r\n              <td bgcolor=\"#F2F2F2\" align=\"center\">\r\n              <font face=\"tahoma\" size=\"2\">\r\n              ���� ������ : </font>\r\n              <input type=\"password\" name=\"userpass\" size=\"13\"> </td>\r\n            </tr>\r\n            <tr>\r\n              <td bgcolor=\"#F2F2F2\" align=\"center\">\r\n              <input type=\"submit\" value=\"���� ������ �����\"></td>\r\n            </tr>\r\n          </form>\r\n        </table>\r\n\r\n\r\n        <br>\r\n        </td>\r\n        </tr>\r\n       </table>\r\n       </center>\r\n       </div>\r\n       </body>\r\n       </html>');
INSERT INTO rafia_templates VALUES (65,'arabportal','guestbook_add',1,'<script language=javascript>\r\nfunction checkForm(){\r\n	if (!document.rafia.name.value) {\r\n		alert(\'���� ... ��� �� ��� ������ �����\'); \r\n		return false;\r\n	} \r\n	if (!document.rafia.email.value) {\r\n		alert(\'���� ... ��� �� ��� ������ �������\'); \r\n		return false;\r\n	} \r\n	if (!document.rafia.post.value) {\r\n		alert(\'���� ... ��� �� ��� ������ �� �������\'); \r\n		return false;\r\n	} \r\ndocument.rafia.spam.value =\'guestnotspam_$cap\';\r\n\r\n}\r\n</script>\r\n<form onsubmit=\'return checkForm(this)\'  action=\"guestbook.php?action=insert\" method=\"post\" name=\"rafia\" enctype=\"multipart/form-data\">\r\n       <table border=\"0\" width=\"90%\"cellspacing=\"0\" cellpadding=\"0\">\r\n					<tr>\r\n						<td align=right class=\"forum_header\">\r\n					����� ����� </td>\r\n					</tr>\r\n                      <tr>\r\n						<td>\r\n						<table border=\"0\" width=\"100%\" id=\"table13\" cellpadding=\"2\" class=\"fontablt\">\r\n                         <tr><td align=right nowrap class=\"info_bar\">����� : <font color=\"#FF0000\">*</font> </td>\r\n				<td align=right width=\"100%\">\r\n				<input type=\"text\" name=\"name\" value=\"\" size=\"35\" class=\"text_box\">\r\n				</td>\r\n				</tr><tr><td align=right nowrap class=\"info_bar\">������ ���������� : <font color=\"#FF0000\">*</font> </td>\r\n				<td align=right width=\"100%\">\r\n				<input type=\"text\" name=\"email\" value=\"\" size=\"30\" class=\"text_box\">\r\n				</td>\r\n				</tr><tr><td align=right nowrap class=\"info_bar\">������ :  </td>\r\n				<td align=right width=\"100%\">\r\n				<input type=\"text\" name=\"url\" value=\"http://\" size=\"50\" class=\"text_box\">\r\n				</td>\r\n				</tr>$txtcount_java<tr><td align=right nowrap class=\"info_bar\" valign=\"top\">������� : <font color=\"#FF0000\">*</font><a neme=\'count\'> $use_smiles <br> ��� ���� ��� �� ���� <br> ��� �� : $txtcount_count  ���<br><center> <A HREF=\"#count\" onmouseover=\"return proces()\">������ �����</A><br>���� �� : <input size=5 name=remain type=text value=$txtcount_count> <center> </td>\r\n            <td align=right width=\"100%\"><br><textarea onmouseover=\"return proces()\" onbeforeeditfocus=\"return proces()\" onmouseout=\"return proces()\" name=post rows=8 cols=60 id=\"post\" wrap=virtual></textarea><input type=\'hidden\' name=\'left\' value=\'$txtcount_count\' size=\'7\' class=\"text_box\">\r\n<input type=\'hidden\' name=\'spam\' value=\'1\'>\r\n</td></tr>\r\n					</table>\r\n						</td>\r\n					</tr>\r\n					<tr>\r\n						<td align=right align=\"center\"><input border=\"0\" src=\"themes/apt/sign.gif\" name=\"I1\" width=\"98\" height=\"24\" type=\"image\"></td>\r\n					</tr>\r\n				</table> </form>');
INSERT INTO rafia_templates VALUES (66,'arabportal','news_add',2,'<script language=javascript>\r\nfunction checkForm(){\r\n	if (!document.rafia.title.value) {\r\n		alert(\'���� ... ��� �� ��� ������ ����� �����\'); \r\n		return false;\r\n	} \r\n	if (!document.rafia.post_head.value) {\r\n		alert(\'���� ... ��� �� ��� ������ ��� �����\'); \r\n		return false;\r\n	} \r\n	if (document.rafia.post_head.value.length >= $counthead) {\r\n		alert(\"���� ... ��� ���� ��� ����� ���� �� $counthead\"); \r\n		return false;\r\n	} \r\n	if (!document.rafia.post.value) {\r\n		alert(\'���� ... ��� �� ��� ������ �� �����\'); \r\n		return false;\r\n\r\n	}\r\ndocument.rafia.spam.value =\'newsnotspam_$cap\';\r\n}\r\n</script>\r\n<form onsubmit=\'return checkForm(this)\' action=\"news.php?action=insert\" method=\"post\" name=\"rafia\" enctype=\"multipart/form-data\">\r\n       <table border=\"0\" width=\"90%\"cellspacing=\"0\" cellpadding=\"0\">\r\n					<tr>\r\n						<td align=right class=\"forum_header\">\r\n					����� ��� </td>\r\n					</tr>\r\n                      <tr>\r\n						<td>\r\n						<table border=\"0\" width=\"100%\" id=\"table13\" cellpadding=\"2\" class=\"fontablt\">\r\n                         $usernamef$useridf$selectform<tr><td align=right nowrap class=\"info_bar\">������� : <font color=\"#FF0000\">*</font> </td>\r\n				<td align=right width=\"100%\">\r\n				<input type=\"text\" name=\"title\" value=\"\" size=\"35\" class=\"text_box\">\r\n				</td>\r\n				</tr>$txtcounth<tr><td align=right nowrap class=\"info_bar\" valign=\"top\">��� ����� : <font color=\"#FF0000\">*</font></td><td align=right width=\"100%\"><textarea name=\"post_head\" rows=\"8\" cols=\"60\"onkeypress=\"return countIt();\"></textarea></td></tr>$editor$txtcount<tr><td align=right nowrap class=\"info_bar\" valign=\"top\">����� ����� : <font color=\"#FF0000\">*</font>  <br> ��� ���� ��� �� ���� <br> ��� �� : $countpost  ���<br><center> <A HREF=\"#\" onmouseover=\"return proces()\">������ �����</A><br>���� �� : <input size=5 name=remain type=text value=$countpost> <center> </td>\r\n            <td align=right width=\"100%\">$form_code<br><textarea onmouseover=\"return proces()\" onbeforeeditfocus=\"return proces()\" onmouseout=\"return proces()\" name=post rows=15 cols=60 id=\"post\" wrap=virtual></textarea><input type=\'hidden\' name=\'left\' value=\'$countpost\' size=\'7\' class=\"text_box\"></td></tr>\r\n<td align=right nowrap class=\"info_bar\"> ������� ������� ����������\r\n                  </td> <td align=right width=\"100%\"><input  type=\"radio\" name=H value=\'1\' checked>  ��� <input type=\"radio\" name=H value=\"0\">  �� </td></tr>\r\n<tr><td align=right nowrap class=\"info_bar\"> ��� ������� �� ���� ������ɿ </td><td align=right width=\"100%\"><input  type=\"radio\" name=\'inindex\'  value=\'1\' checked>  ���&nbsp;&nbsp;<input type=\"radio\" name=\'inindex\'  value=\"0\">  ��</td></tr><tr><td align=right nowrap class=\"info_bar\"> ��� ������� �� ����� ��� ������ѿ </td><td align=right width=\"100%\"><input  type=\"radio\" name=\'inmenu\'  value=\'1\' checked>  ���&nbsp;&nbsp;<input type=\"radio\" name=\'inmenu\'  value=\"0\">  ��</td></tr>$main_n<tr><td align=right nowrap class=\"info_bar\"> ������� ������ ���������� ����� </td><td align=right width=\"100%\"><input  type=\"radio\" name=\'catmig\'  value=\'1\'>  ���&nbsp;&nbsp;<input type=\"radio\" name=\'catmig\'  value=\"0\" checked> ��</td></tr>$fileupload$imgupload\r\n<input type=\"hidden\" name=\"spam\" value=\"spam\">\r\n<input type=\"hidden\" name=\"action\" value=\"insert\">\r\n						</table>\r\n						</td>\r\n					</tr>\r\n					<tr>\r\n						<td align=right align=\"center\"><input border=\"0\" src=\"themes/apt/newnews.gif\" name=\"I1\" width=\"98\" height=\"24\" type=\"image\"></td>\r\n					</tr>\r\n				</table> </form>');
INSERT INTO rafia_templates VALUES (67,'arabportal','link_add',5,'<script language=javascript>\r\nfunction checkForm(){\r\n	if (!document.rafia.title.value) {\r\n		alert(\'���� ... ��� �� ��� ������ ��� ������\'); \r\n		return false;\r\n	} \r\n	if (document.rafia.url.value==\'http://\') {\r\n		alert(\'���� ... ��� �� ��� ������ ����� ������\'); \r\n		return false;\r\n	} \r\n	if (!document.rafia.post.value) {\r\n		alert(\'���� ... ��� �� ��� ������ ��� ������\'); \r\n		return false;\r\n	} \r\ndocument.rafia.spam.value =\'linknotspam_$cap\';\r\n}\r\n</script>\r\n\r\n\r\n<form onsubmit=\'return checkForm(this)\'\r\naction=\"link.php?action=insert\" method=\"post\" name=\"rafia\" enctype=\"multipart/form-data\">\r\n       <table border=\"0\" width=\"90%\"cellspacing=\"0\" cellpadding=\"0\">\r\n					<tr>\r\n						<td align=right class=\"forum_header\">\r\n					����� ���� </td>\r\n					</tr>\r\n                      <tr>\r\n						<td>\r\n						<table border=\"0\" width=\"100%\" id=\"table13\" cellpadding=\"2\" class=\"fontablt\">\r\n                         $cat<tr><td align=right nowrap class=\"info_bar\">��� ������ : <font color=\"#FF0000\">*</font> </td>\r\n				<td align=right width=\"100%\">\r\n				<input type=\"text\" name=\"title\" value=\"\" size=\"35\" class=\"text_box\">\r\n				</td>\r\n				</tr><tr><td align=right nowrap class=\"info_bar\">����� ������ : <font color=\"#FF0000\">*</font> </td>\r\n				<td align=right width=\"100%\">\r\n				<input type=\"text\" name=\"url\" value=\"http://\" size=\"50\" class=\"text_box\">\r\n				</td>\r\n				</tr>$yrname $yrmail<script language=JavaScript>\r\n        function proces()\r\n        {\r\n            value = document.rafia.post.value;\r\n            len = $countpost - value.length;\r\n            if (len < 0 )\r\n            {\r\n                document.rafia.post.value = document.rafia.post.value.substring(0,$countpost);\r\n                document.rafia.left.value = 0;\r\n            }\r\n            else\r\n            {\r\n                document.rafia.left.value = len\r\n            }\r\n            document.rafia.remain.value = len;\r\n            //alert(\'���� �� : \' + len  );\r\n        }\r\n        </script>\r\n<tr><td align=right nowrap class=\"info_bar\" valign=\"top\">��� ���� : <font color=\"#FF0000\">*</font>  <br> ��� ���� ��� �� ���� <br> ��� �� : $countpost  ���<br><center> <A HREF=\"#\" onmouseover=\"return proces()\">������ �����</A><br>���� �� : <input size=5 name=remain type=text value=$countpost> <center> </td>\r\n            <td align=right width=\"100%\"><br><textarea onmouseover=\"return proces()\" onbeforeeditfocus=\"return proces()\" onmouseout=\"return proces()\" name=post rows=8 cols=60 id=\"post\" wrap=virtual></textarea><input type=\'hidden\' name=\'left\' value=\'$countpost\' size=\'7\' class=\"text_box\">\r\n<input type=\"hidden\" name=\"action\" value=\"insert\"></td></tr>\r\n<input type=\"hidden\" name=\"spam\" value=\"spam\">		</table>\r\n						</td>\r\n					</tr>\r\n	<tr>\r\n						<td align=right align=\"center\"><input border=\"0\" src=\"themes/apt/site.gif\" name=\"I1\" type=\"image\"></td>\r\n					</tr>\r\n				</table></form>');
INSERT INTO rafia_templates VALUES (68,'arabportal','middle_menu',7,'<!-- BLOCK START -->\r\n<TABLE WIDTH=\"100%\" BORDER=0 CELLPADDING=0 CELLSPACING=0>\r\n	<TR>\r\n		<TD width=\"9\" height=\"24\" background=\"themes/apt/cat_bg.jpg\">\r\n			&nbsp;</TD>\r\n		<TD background=\"themes/apt/cat_bg.jpg\" width=\"100%\">\r\n			\r\n<p align=\"center\">\r\n			\r\n<font class=side_menu_head>{block_head}</font>			\r\n			</TD>\r\n		<TD width=\"9\" height=\"24\" background=\"themes/apt/cat_bg.jpg\">\r\n			&nbsp;</TD>\r\n	</TR>\r\n  </tr>\r\n  <tr>\r\n    <td  height=\"120\" valign=top colspan=\"3\" bgcolor=\"#F1F1F1\" style=\"padding-right: 5px\" class=side_menu_center>{block_center}\r\n<BR> \r\n</td>\r\n  </tr>	\r\n</TABLE><br>\r\n<!-- BLOCK END -->');
INSERT INTO rafia_templates VALUES (69,'arabportal','index_main_table',1,'<table border=\"0\" cellpadding=\"0\" cellspacing=\"0\" width=\"95%\">\r\n	<tr>\r\n		<td height=\"28\">\r\n<div class=news_title>\r\n	<img border=\"0\" src=\"themes/apt/news_icon.gif\" width=\"12\" height=\"12\"> <a href=\"$news_link\">$title</a></div>\r\n	\r\n		</td>\r\n	</tr>\r\n  <tr>\r\n    <td width=\"100%\">\r\n    <table border=\"0\" cellpadding=\"2\" style=\"border-collapse: collapse\" width=\"100%\" id=\"AutoNumber1\" class=\"article_info\">\r\n      <tr>\r\n        <td width=\"100%\">\r\n	<div class=\"article_info\">	<img border=\"0\" src=\"themes/apt/info.gif\" width=\"13\" height=\"18\"> ������: <a href=\"members.php?action=info&userid=$userid\">$name</a> ������: $date </div></td>\r\n        <td nowrap align=\"left\" colspan=\"3\">  </td>\r\n      </tr>\r\n    </table>\r\n    </td>\r\n  </tr>\r\n  <tr>\r\n    <td width=\"100%\" style=\"padding-top: 5; padding-bottom: 5; text-align:justify\">\r\n$newsimage <font class=\"home_text\">$news_head </font>\r\n		</td>\r\n  </tr>\r\n  <tr>\r\n    <td width=\"100%\" class=\"info_bar2\" style=\"padding-top: 5; padding-bottom: 5\">\r\n    <p align=\"right\"><a href=\"$news_link\">\r\n	<img border=\"0\" src=\"themes/apt/more.gif\" width=\"56\" height=\"13\" align=\"left\"></a>\r\n<div class=\"article_info\">	&nbsp; \r\n	������: $reader &nbsp;&nbsp;&nbsp;���������: $numrows </div></td>\r\n  </tr>\r\n  <tr>\r\n    <td width=\"100%\">$pagenum </td>\r\n  </tr>\r\n</table>\r\n<hr color=\"#C0C0C0\" width=\"95%\" size=\"1\" style=\"border-style: dotted; border-width: 1px\">');

#------------------- TABLE rafia_temptype -------------------
DROP TABLE IF EXISTS rafia_temptype; 

CREATE TABLE `rafia_temptype` (
  `tempid` int(10) unsigned NOT NULL auto_increment,
  `temptypetitle` varchar(100) NOT NULL default '',
  `tempdsc` longtext NOT NULL,
  PRIMARY KEY  (`tempid`)
) ;

INSERT INTO rafia_temptype VALUES (1,'����� ����','');
INSERT INTO rafia_temptype VALUES (2,'����� �������','');
INSERT INTO rafia_temptype VALUES (3,'����� �������','');
INSERT INTO rafia_temptype VALUES (4,'����� ���� �������','');
INSERT INTO rafia_temptype VALUES (5,'����� ���� �������','');
INSERT INTO rafia_temptype VALUES (6,'����� �������','');
INSERT INTO rafia_temptype VALUES (7,'����� �������','');


#------------------- TABLE rafia_upload -------------------
DROP TABLE IF EXISTS rafia_upload; 

CREATE TABLE `rafia_upload` (
  `upid` int(10) NOT NULL auto_increment,
  `upcatid` int(10) NOT NULL default '0',
  `uppostid` int(10) NOT NULL default '0',
  `uptypes` varchar(100) NOT NULL default '',
  `upname` varchar(100) NOT NULL default '',
  `upsize` int(10) NOT NULL default '0',
  `upstat` int(10) NOT NULL default '0',
  `upcat` varchar(10) NOT NULL default '',
  `upend` varchar(10) NOT NULL default '',
  `upuserid` int(10) NOT NULL default '0',
  `upclicks` int(10) default '0',
  `timestamp` int(11) NOT NULL default '0',
  `imagealign` varchar(5) NOT NULL default '0',
  PRIMARY KEY  (`upid`)
) ;

INSERT INTO rafia_upload VALUES (1,'',1,'image/gif','icon_writer_small.gif',3987,1,'catid','gif','','','','');
INSERT INTO rafia_upload VALUES (2,1,1,'image/pjpeg','86b8717e89097d70de64dac6a79b4dfc4ca96c8c.jpg',27632,1,'news','jpg',1,8,'','left');

#------------------- TABLE rafia_users -------------------
DROP TABLE IF EXISTS rafia_users; 

CREATE TABLE `rafia_users` (
  `userid` smallint(5) unsigned NOT NULL auto_increment,
  `username` varchar(100) NOT NULL default '',
  `password` varchar(100) NOT NULL default '',
  `useradmin` tinyint(10) NOT NULL default '0',
  `usergroup` int(10) NOT NULL default '0',
  `grouptitle` varchar(100) NOT NULL default '',
  `email` varchar(100) NOT NULL default '',
  `allposts` int(10) NOT NULL default '0',
  `homepage` varchar(100) NOT NULL default '',
  `showemail` int(1) NOT NULL default '0',
  `signature` text NOT NULL,
  `avatar` tinyint(1) NOT NULL default '0',
  `datetime` int(11) NOT NULL default '0',
  `allowpost` char(3) NOT NULL default '',
  `activate` varchar(255) NOT NULL default '',
  `usertheme` varchar(100) NOT NULL default '0',
  `html_msg` tinyint(1) NOT NULL default '1',
  `lastadd` int(11) NOT NULL default '0',
  `viewemail` int(1) NOT NULL default '0',
  `statpm` int(1) NOT NULL default '0',
  `userip` varchar(20) NOT NULL default '0',
  `lastlogin` int(11) NOT NULL default '0',
  PRIMARY KEY  (`userid`)
) ;

INSERT INTO rafia_users VALUES (1,'admin','fe01ce2a7fbac8fafaed7c982a04e229',1,1,'','admin@site.com',7,'http://www.arabportal.net',1,'�������','','','yes','8810849','arabportal',1,1171307967,'','','62.231.248.120',1171576420);
INSERT INTO rafia_users VALUES (2,'����','','',3,'','',3,'','','','','','yes','5708617','arabportal',1,'','','','',1163753968);


#------------------- TABLE rafia_usertitles -------------------
DROP TABLE IF EXISTS rafia_usertitles; 

CREATE TABLE `rafia_usertitles` (
  `id` tinyint(3) unsigned NOT NULL auto_increment,
  `title` varchar(50) NOT NULL default '',
  `posts` int(10) unsigned NOT NULL default '0',
  `Iconrep` int(11) NOT NULL default '1',
  KEY `id` (`id`),
  KEY `Posts` (`posts`)
) ;

INSERT INTO rafia_usertitles VALUES (1, '��� ����', 1, 1);
INSERT INTO rafia_usertitles VALUES (2, '��� �����', 30, 2);
INSERT INTO rafia_usertitles VALUES (3, '��� ����', 70, 3);
INSERT INTO rafia_usertitles VALUES (4, '��� ����', 150, 4);

