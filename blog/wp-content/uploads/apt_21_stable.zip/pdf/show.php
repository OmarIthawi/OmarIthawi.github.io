<?php

define('FPDF_FONTPATH', 'font/');
include_once('ufpdf.php');
require('ArGlyphs.class.php');
require_once("./../global.php");
$id = $apt->setid('id');

function PreSpeRemove($text){
        $search = array( '~\[B](.+?)\[/B]~is',
                         '~\[I](.+?)\[/I]~is',
                         '~\[U](.+?)\[/U]~is',
                         '~\[quran](.+?)\[/quran]~is',
                         '~\[C](.+?)\[/C]~is',
                         '~\[Q](.+?)\[/Q]~is',
                         '~\[align=(.+?)](.+?)\[/align]~is',
                         '~\[face=(.+?)](.+?)\[/face]~is',
                         '~\[color=(\S+?)](.+?)\[/color]~is',
                         '~\[size=([0-9]+?)](.+?)\[/size]~is'
				  );
       $replace = array( '\\1',
                         '\\1',
                         '\\1',
                         '\\1',
                         '\\1',
                         '\\1',
                         '\\2',
                         '\\2',
                         '\\2',
                         '\\2'
                   );

       $text = preg_replace($search, $replace, $text);


$swords = array("+","�","<",">");
$rwords = array("&#43;","�",">","<");
$text = str_replace($swords, $rwords, $text);
$text = str_replace("&quot;","\"", $text);
$text = str_replace("�","",$text);
$text = str_replace("�","",$text);
$text = str_replace("�","",$text);
$text = str_replace("�","",$text);
$text = str_replace("�","",$text);
$text = str_replace("�","",$text);
$text = str_replace("�","",$text);

return $text;
}

$row = $apt->dbfetch("SELECT rafia_news.*,rafia_users.userid,rafia_users.username,
                  rafia_users.datetime,rafia_users.allposts,rafia_users.signature,
                  rafia_users.homepage,rafia_users.avatar FROM rafia_news,rafia_users
                  WHERE id='$id' AND rafia_news.userid = rafia_users.userid LIMIT 1");
@extract($row);

$news_head = PreSpeRemove($news_head);
$post = PreSpeRemove($post);

$pdf = new UFPDF();
$ArabicPDF = new ArGlyphs();
$pdf->Open();
$title = $ArabicPDF->convert($title);
$username = $ArabicPDF->convert($username);
$Ttitle = ' ' .$username . ' ' . $ArabicPDF->convert("  ������  ") . $title;
$pdf->SetTitle($title);
$pdf->SetAuthor($username);

$pdf->AddFont('ae_AlHor', '', 'ae_AlHor.php');
$pdf->AddPage();


////////////////////

if(file_exists($apt->upload_path."/".$id.".newsthumb")){
$pathfile = $apt->upload_path."/".$id.".newsthumb";
$op = @fopen("./../upload/$id.jpg",w);
}elseif(file_exists($apt->upload_path."/".$id.".news")){
$pathfile = $apt->upload_path."/".$id.".news";
$op = @fopen("./../upload/$id.jpg",w);
}

if($op){
$fr = fread( @fopen($pathfile,r), @filesize($pathfile));
@fwrite($op,$fr);
@fclose($op);
$mime = @getimagesize("./../upload/$id.jpg");
$type = $mime[mime];

if($type = "image/gif"){
$image = @ImageCreateFromGIF("./../upload/$id.jpg");
}elseif($type = "image/jpeg"){
$image = @ImageCreateFromJPEG("./../upload/$id.jpg");
}elseif($type = "image/png"){
$image = @ImageCreateFromPNG("./../upload/$id.jpg");
}else{
$image = @ImageCreateFromJPEG("./../upload/$id.jpg");
}

$width = @imagesx($image) ;
$height = @imagesy($image) ;

if (function_exists('ImagecreateTrueColor')){
$thumb = @ImageCreateTrueColor($width,$height);
@ImageCopyResampled($thumb,$image,0,0,0,0,$width,$height,$width,$height);
}else{
$thumb = @ImageCreate($new_width,$new_height);
@ImageCopyResized($thumb,$image,0,0,0,0,$new_width,$new_height,$width,$height);
}

@ImageJPEG($thumb, "./../upload/$id.jpg");
@imagedestroy($image);

$check = @GetImageSize("./../upload/$id.jpg");

if($check[2]==2){
$pdf->Image("./../upload/$id.jpg",160,5);
@unlink("./../upload/$id.jpg");
}

}

////////////////////

$font_size = 20;
$pdf->SetFont('ae_AlHor', '', $font_size);

$pdf->Write(10,$Ttitle);

$font_size = 16;
$pdf->SetFont('ae_AlHor', '', $font_size);

$news_head = $apt->rep_words($news_head);
$news_head = str_replace("\n\n","\n  \n",$news_head);

//$news_head = wordwrap($news_head, 70, "\n", 1);
$news_head = $ArabicPDF->convert($news_head,80);
//$news_head = str_replace('', '', $news_head);

$arrH = explode("\n",$news_head);

$HC = count($arrH);
foreach($arrH as $H){
$HC--;
$NarrH[] = $arrH[$HC];
}

foreach($NarrH as $NH){
$pdf->Write(12, $NH);
}

//-----

$post = $apt->rep_words ($post);
//$post =  $apt->rafia_code($post);
$post = str_replace("�","",$post);
//$post = str_replace(":ss:",$pdf->Image("./../images/smiles/downloadable.jpg",$pdf->GetY(),$pdf->Getx()),$post);
$post = str_replace("\n\n","\n  \n",$post);
//$post = wordwrap($post, 90, "\n", 1);
$post = $ArabicPDF->convert($post,100);

$arrP = explode("\n",$post);

$PC = count($arrP);
foreach($arrP as $P){
$PC--;
$NarrP[] = $arrP[$PC];
}

foreach($NarrP as $NP){

$pdf->Write(14, $NP);
}

$pdf->Close();
$pdf->Output();

?>