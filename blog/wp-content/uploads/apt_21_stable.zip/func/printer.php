<?php
/*
+===========================================+
|      ArabPortal V2.1.x Copyright � 2006   |
|   -------------------------------------   |
|                                           |
|            By Rafia AL-Otibi              |
|                    And                    |
|              Arab Portal Team             |
|   -------------------------------------   |
|      Web: http://www.ArabPortal.Net       |
|   -------------------------------------   |
|  Last Updated: 22/10/2006 Time: 10:00 PM  |
+===========================================+
*/
class printer
{
   var $print_arr    = array();
   var $url          = '';
  // var $print_string = '';

   function printer($url,$arr)
   {
       $this->url        = $url;
       $this->print_arr   = $arr;
   }

   function set_print()
   {
        foreach($this->print_arr as $key => $value)
        {
           $this->print_string .= $key." : ".$value;
        }
       return  $this->print_string;
   }

   function output_printer()
   {
     global  $apt;
    return "<HTML DIR=RTL LANG=AR-SA>
     <head>
     <title> rafia </title>
     <script language=JavaScript>
     function fermer()
     {
         self.close();
     }
     </script>
     </head>
     <body onload='window.print()'>
     <table width='600' border='0' align=center>
      <tr>
        <td width='100%'>
            <center>
            <table border='0' width='89%' cellspacing='0' cellpadding='0'>
              <tr>
                <td width='100%'>
                <h3 align=\"center\">".$apt->getsettings("sitetitle")."</h3>
                 <font size='2'><b>".$this->url."</b></font>
                 <hr noshade color=\"#000000\" size=\"0\" width=\"100%\">
                <font size='2'><b>".$this->set_print()."
               </b></font>
               <hr noshade color=\"#000000\" size=\"0\" width=\"100%\">
               </td>
              </tr>
            </table>

        </td>
      </tr>
  </table>
</body>
</html>";

   }
}
?>
