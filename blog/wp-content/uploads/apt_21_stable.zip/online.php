<?php
/*
+===========================================+
|      ArabPortal V2.1.x Copyright � 2006   |
|   -------------------------------------   |
|            By Rafia AL-Otibi              |
|                    And                    |
|              Arab Portal Team             |
|   -------------------------------------   |
|      Web: http://www.ArabPortal.Net       |
|   -------------------------------------   |
|  Last Updated: 01/01/2007 Time: 00:00 AM  |
+===========================================+
*/

@header( "Refresh: 30;url=online.php" );

include('global.php');

$menu = new menu;

$menu->menuid       =  $apt->getsettings("index_menuid");

$left_menu          = $menu->_menu(2);
$right_menu         = $menu->_menu(1);
$middle_menu_count  =  $apt->getsettings("count_middle_menu");
$middle_menu = "<table border=0 cellpadding=0 cellspacing=0 width=100%><tr valign=top>";
$middle_menus = $menu->_menu(3);
$ex = @explode('<!-- BLOCK END -->',$middle_menus);
$m=0;
foreach($ex as $amenu){
$middle_menu .= '<td valign=top>'.$amenu.'</td>';
$m++;
if($m==$middle_menu_count)$middle_menu .= "</tr>";
}
$middle_menu .= "</tr></table><br>";

$apt->head("���������� �����");

$result = $apt->query("SELECT DISTINCT onlineip,onlinepage,onlinefile,user_online,useronlineid FROM rafia_online  ORDER BY id DESC");

while($row = $apt->dbarray($result))
{
    $user_online  = $row[user_online];
    $useronlineid  = $row[useronlineid];

    if ( $apt->cookie['cadmin'] >'0' ){
        $onlineip     = $row[onlineip];
    }else{
        $onlineip     = "---";
    }

    $onlinefile    = $row[onlinefile];
    $onlinefile    = explode("/",$onlinefile);
    $onlinefile    = $onlinefile[count($onlinefile)-1];
    $onlinepage    = $row[onlinepage];
    $onlinepage    = explode("/",$onlinepage);
    $onlinepage    = $onlinepage[count($onlinepage)-1];

    if($useronlineid == $apt->Guestid){$user_online = "����";}
    $apt->color($color);
    $index_middle .= " <center><table border=\"0\" width=\"90%\"><tr>
    <td width=\"7%\" bgcolor=\"$color\" align=\"center\">$userid </td>
    <td width=\"30%\" bgcolor=\"$color\"><font class=fontablt>  </font><font class=fontablt>$user_online</font></td>
    <td width=\"33%\" bgcolor=\"$color\"><font class=fontablt><a href=\"$onlinepage\">������ �� $onlinefile</a></font></td>
    <td width=\"40%\" bgcolor=\"$color\" align=\"center\"><font class=fontablt>$onlineip
    </font></td></tr></table></center>";
}

$apt->html_Output($left_menu);

?>
