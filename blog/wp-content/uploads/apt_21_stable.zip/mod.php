<?php
/*
+===========================================+
|      ArabPortal V2.1.x Copyright � 2006   |
|   -------------------------------------   |
|            By Rafia AL-Otibi              |
|                    And                    |
|              Arab Portal Team             |
|   -------------------------------------   |
|      Web: http://www.ArabPortal.Net       |
|   -------------------------------------   |
|  Last Updated: 01/01/2007 Time: 00:00 AM  |
+===========================================+
*/

define('RUN_MODULE', true);

require_once('global.php');

if (isset($apt->get[mod])){
    if (eregi("http\:\/\/", $apt->get[mod]))
    {
        $apt->errmsg (_MOD_NOT_AUTH);
    }
}
//=======================================================

$mod = new module();
$mod->mod_set_arr = $mod->mods_settings($mod->modInfo[mod_name]);

ob_start();

if($mod->modInfo[adsH] == '1'){
$ads_head = $apt->ads_view_in('h');
}
if($mod->modInfo[adsF] == '1'){
$ads_foot = $apt->ads_view_in('f');
}

$index_middle =  $mod->module_OutPut();
if($apt->title == ''){
$apt->head($mod->modInfo[mod_title]);
}else{
$apt->head($mod->modInfo[mod_title]."->".$apt->title);
}
ob_end_flush();

if($mod->modInfo[mnueid] == ''){
	$menu = new menu;
	$apt->html_Output('',0);
}else{
	$menu = new menu;
	$menu->menuid  =  $mod->modInfo[mnueid];
	if($mod->modInfo[right_menu] == 1 )
	{
	    $right_menu = $menu->_menu(1);
	}

	if($mod->modInfo[left_menu] == 1 )
	{
	    $left_menu  = $menu->_menu(2);
	}

	if($mod->modInfo[middle_menu] == 1 )
	{
		$middle_menu_count  =  $apt->getsettings("count_middle_menu");
			$middle_menu = "<table border=0 cellpadding=0 cellspacing=0 width=100%><tr valign=top>";
		$middle_menus = $menu->_menu(3);
		$ex = @explode('<!-- BLOCK END -->',$middle_menus);
		$m=0;
		foreach($ex as $amenu){
		$middle_menu .= '<td valign=top>'.$amenu.'</td>';
		$m++;
		if($m==$middle_menu_count)$middle_menu .= "</tr>";
		}
		$middle_menu .= "</tr></table><br>";
	}

	$apt->html_Output($left_menu,$mod->modInfo[right_menu]);
}

//=======================================================

$apt->foot($pageft);

?>