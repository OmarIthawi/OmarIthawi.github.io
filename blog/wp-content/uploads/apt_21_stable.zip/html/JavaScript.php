<?php
/*
+===========================================+
|      ArabPortal V2.1.x Copyright � 2006   |
|   -------------------------------------   |
|            By Rafia AL-Otibi              |
|                    And                    |
|              Arab Portal Team             |
|   -------------------------------------   |
|      Web: http://www.ArabPortal.Net       |
|   -------------------------------------   |
|  Last Updated: 28/10/2006 Time: 04:30 AM  |
+===========================================+
*/
//JavaScript
class java_script {


//============================================
//       start function post_java
//============================================
  function post_java()
  {

return <<<EOF
<script language="Javascript1.2"><!--
function checkAll(field)
{
  for(i = 0; i < field.elements.length; i++)
     field[i].checked = true ;
}

function uncheckAll(field)
{
 for(i = 0; i < field.elements.length; i++)
    field[i].checked = false ;
}

function emoticons(smiley)
{
  document.rafia.post.value = document.rafia.post.value + " " + smiley + " ";
document.rafia.post.focus(); // Added By MaaSTaaR
}
var form = document.forms["rafia"];
// --></script>
EOF;
}



//============================================
//       start function html_area
//============================================
function html_area() {

return <<<EOF
<script language="Javascript1.2"><!-- // load htmlarea
_editor_url = "html/htmlarea/";                     // URL to htmlarea files
var win_ie_ver = parseFloat(navigator.appVersion.split("MSIE")[1]);
if (navigator.userAgent.indexOf('Mac')        >= 0) { win_ie_ver = 0; }
if (navigator.userAgent.indexOf('Windows CE') >= 0) { win_ie_ver = 0; }
if (navigator.userAgent.indexOf('Opera')      >= 0) { win_ie_ver = 0; }
if (win_ie_ver >= 5.5) {
document.write('<scr' + 'ipt src="' +_editor_url+ 'editor.js"');
document.write(' language="Javascript1.2"></scr' + 'ipt>');
} else { document.write('<scr'+'ipt>function editor_generate() { return false; }</scr'+'ipt>'); }
// --></script>
EOF;
}

//============================================
//       start function pm_popup
//============================================

function pm_popup()  {

return <<<EOF
<script>
function openpopup(){
var popurl="popup.php?action=pm"
winpops=window.open(popurl,"PmPopup","width=300,height=200,resizable=yes,scrollbars=yes")
}
openpopup()
</script>
EOF;

}
//============================================
//       start function rafia_popup
//============================================

function rafia_popup()  {
return <<<EOF
<script language=JavaScript>
function rafiawin(external, height, width) {
    options = 'height=' + height + ',width=' + width + ',scrollbars=yes,resizable=yes,top=0,left=0';
window.open(external, 'rafia', options);
}
function fermer()
{
    self.close();
}
</script>
EOF;

}
//============================================
//       start function _images
//============================================

function _images()  {

return <<<EOF
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=windows-1256">
<title>portal</title>
</head>
<body>  <center>
<table cellSpacing="2" cellPadding="20" border="0">
<tbody>
<tr>
<td noWrap bgColor="white" align="center">
<!-- IMAGE BEGINS HERE -->
<font size="-3"><pre>
<font color="white">010101010101010</font><font color="#fefdfc">1</font><font color="#f8f5f3">0</font><font color="#f2edeb">1</font><font color="#ede6e4">0</font><font color="#e9e0de">1</font><font color="#e7ddda">010</font><font color="#e7dcda">1</font><font color="#e7ddd9">010</font><font color="#e7dcda">1</font><font color="#e7ddda">0</font><font color="#e7dcd9">1</font><font color="#e7dedb">0</font><font color="#ebe3e0">1</font><font color="#f0e9e7">0</font><font color="#f5f1ef">1</font><font color="#fbf9f8">0</font><font color="#fffffe">1</font><font color="white">01010101010101</font>
<font color="white">0101010</font><font color="#fefdfd">1</font><font color="#faf8f8">0</font><font color="#f9f7f6">1</font><font color="#f5f1f0">0</font><font color="#e4d8d6">1</font><font color="#d5c4bf">0</font><font color="#d4c1bb">10</font><font color="#d5c4be">1</font><font color="#dbccc7">0</font><font color="#e0d4cf">1</font><font color="#e5dad7">0</font><font color="#e9e0dd">1</font><font color="#ebe4e1">01</font><font color="#ece4e1">010</font><font color="#ebe4e1">1</font><font color="#ece4e1">0</font><font color="#ebe4e1">1</font><font color="#ece4e1">0</font><font color="#ece3e1">1</font><font color="#ebe2df">0</font><font color="#e7deda">1</font><font color="#e2d7d3">0</font><font color="#ddd0cb">1</font><font color="#d8c7c2">0</font><font color="#d3c2bc">1</font><font color="#d4c1bc">0</font><font color="#d3c1bb">1</font><font color="#dbcdc8">0</font><font color="#ede6e3">1</font><font color="#f9f7f5">0</font><font color="#f9f7f7">1</font><font color="#fbfbfa">0</font><font color="#fefffe">1</blackblackfont><font color="white">010101</font>
<font color="white">0101</font><font color="#fffffe">0</font><font color="#f8f5f4">1</font><font color="#e0d3d0">0</font><font color="#dccfca">1</font><font color="#d8c9c3">0</font><font color="#d8c8c2">1</font><font color="#ddceca">0</font><font color="#eee7e5">1</font><font color="#fcfcfb">0</font><font color="#fefefe">10</font><font color="white">101010101010101010101</font><font color="#fefefe">01</font><font color="#f7f3f2">0</font><font color="#e5dbd7">1</font><font color="#d9c9c4">0</font><font color="#d8c8c2">1</font><font color="#daccc8">0</font><font color="#ded0cc">1</font><font color="#eae2df">0</font><font color="#fefefe">1</font><font color="white">0101</font>
<font color="white">010</font><font color="#fcfbfb">1</font><font color="#dacbc6">0</font><font color="#d0bdb7">1</font><font color="#ece5e3">0</font><font color="#f2edec">1</font><font color="#fcfbfb">0</font><font color="white">10101010101010101010101010101010</font><font color="#fffffe">1</font><font color="#f7f5f3">0</font><font color="#f0ebe8">1</font><font color="#e1d5d1">0</font><font color="#ccb6b1">1</font><font color="#f1ebe9">0</font><font color="white">101</font>
<font color="white">010</font><font color="#ded0cd">1</font><font color="#cdb8b1">0</font><font color="#fefeff">1</font><font color="white">010101010101010101010101010101010101010</font><font color="#f6f4f3">1</font><font color="#b5958b">0</font><font color="#fdfefd">1</font><font color="white">01</font>
<font color="white">01</font><font color="#feffff">0</font><font color="#c8b1aa">1</font><font color="#dccec9">0</font><font color="#feffff">1</font><font color="white">0101010</font><font color="#fdfefd">1</font><font color="#e2ede0">0</font><font color="#c3d5c1">1</font><font color="#abc2a8">0</font><font color="#afc8aa">1</font><font color="#c9dac5">0</font><font color="#e1ece0">1</font><font color="#f9fbf9">0</font><font color="white">1010</font><font color="#eff4ee">1</font><font color="#ecf2eb">0</font><font color="#fdfdfd">1</font><font color="white">01010101010101010</font><font color="#feffff">1</font><font color="#a68175">0</font><font color="#fefffe">1</font><font color="white">01</font>
<font color="white">01</font><font color="#feffff">0</font><font color="#c7b0a9">1</font><font color="#dcceca">0</font><font color="#feffff">1</font><font color="white">01010101</font><font color="#f5f8f4">0</font><font color="#d9e0d9">1</font><font color="#84a37e">0</font><font color="#2b6622">1</font><font color="#36762b">0</font><font color="#4f8745">1</font><font color="#85a880">0</font><font color="#e0e9de">1</font><font color="#fefffe">0</font><font color="white">1</font><font color="#dde8db">0</font><font color="#b2c9ae">1</font><font color="#e6ede4">0</font><font color="white">101010101010101010</font><font color="#feffff">1</font><font color="#a58074">0</font><font color="#fefffe">1</font><font color="white">01</font>
<font color="white">01</font><font color="#feffff">0</font><font color="#c7b0a9">1</font><font color="#dcceca">0</font><font color="#feffff">1</font><font color="white">01010101</font><font color="#fefffe">0</font><font color="#fcfdfb">1</font><font color="#f4f7f4">0</font><font color="#d6ddd4">1</font><font color="#689261">0</font><font color="#337328">1</font><font color="#29711e">0</font><font color="#397c2e">1</font><font color="#aec5aa">0</font><font color="#dfe9de">1</font><font color="#53844c">0</font><font color="#9faf9c">1</font><font color="#f6f8f6">0</font><font color="#fafbf9">1</font><font color="#fafcfa">0</font><font color="#fdfefd">1</font><font color="white">010101010101010</font><font color="#feffff">1</font><font color="#a57f74">0</font><font color="#fefffe">1</font><font color="white">01</font>
<font color="white">01</font><font color="#feffff">0</font><font color="#c7b0a9">1</font><font color="#dccec9">0</font><font color="#feffff">1</font><font color="white">01010</font><font color="#fcfdfc">1</font><font color="#eff4ee">0</font><font color="#cdddcb">1</font><font color="#aac6a5">0</font><font color="#92b88b">1</font><font color="#86b07e">0</font><font color="#7ea678">1</font><font color="#709b69">0</font><font color="#4e8445">1</font><font color="#286f1d">0</font><font color="#266c1a">1</font><font color="#39792f">0</font><font color="#75a070">1</font><font color="#397730">0</font><font color="#78a372">1</font><font color="#92b58c">0</font><font color="#87ae7f">1</font><font color="#88b081">0</font><font color="#93b98e">1</font><font color="#b1caad">0</font><font color="#dae5d8">1</font><font color="#fafbf9">0</font><font color="#feffff">1</font><font color="white">01010101010</font><font color="#feffff">1</font><font color="#a57f74">0</font><font color="#fefffe">1</font><font color="white">01</font>
<font color="white">01</font><font color="#feffff">0</font><font color="#c7b0a9">1</font><font color="#dccec9">0</font><font color="#feffff">1</font><font color="white">010</font><font color="#fefefe">1</font><font color="#dae6d8">0</font><font color="#8aa985">1</font><font color="#4a8041">0</font><font color="#2d7022">1</font><font color="#226318">0</font><font color="#246818">1</font><font color="#1f5d16">0</font><font color="#225c18">1</font><font color="#28701d">0</font><font color="#29721d">1</font><font color="#266c1a">01</font><font color="#286e1b">0</font><font color="#256c1a">1</font><font color="#216516">0</font><font color="#216518">1</font><font color="#266d1b">0</font><font color="#28711c">1</font><font color="#256a1a">0</font><font color="#3c6f33">1</font><font color="#28641f">0</font><font color="#417139">1</font><font color="#6d9366">0</font><font color="#c8d5c6">1</font><font color="#fffffe">0</font><font color="white">1010101010</font><font color="#feffff">1</font><font color="#a57f74">0</font><font color="#fefffe">1</font><font color="white">01</font>
<font color="white">01</font><font color="#feffff">0</font><font color="#c7b0a9">1</font><font color="#dccec9">0</font><font color="#feffff">1</font><font color="white">01</font><font color="#fefefe">0</font><font color="#c0d1be">1</font><font color="#859c81">0</font><font color="#a5b5a3">1</font><font color="#698a65">0</font><font color="#6d8569">1</font><font color="#aab9a7">0</font><font color="#607e5b">1</font><font color="#8b9e89">0</font><font color="#a9bba6">1</font><font color="#3a7930">0</font><font color="#266e1b">1</font><font color="#246718">0</font><font color="#335b2c">1</font><font color="#7f957b">0</font><font color="#668761">1</font><font color="#316b28">0</font><font color="#276c1b">1</font><font color="#256b1a">01</font><font color="#276e1c">0</font><font color="#598652">1</font><font color="#94ae91">0</font><font color="#b4beb2">1</font><font color="#d0d8ce">0</font><font color="#b0bfad">1</font><font color="#f1f3f1">0</font><font color="white">1010101010</font><font color="#feffff">1</font><font color="#a57f74">0</font><font color="#fefefe">1</font><font color="white">01</font>
<font color="white">01</font><font color="#feffff">0</font><font color="#c7b0a9">1</font><font color="#dccec9">0</font><font color="#feffff">1</font><font color="white">01</font><font color="#fcfdfc">0</font><font color="#e4e9e3">1</font><font color="#fefefe">0</font><font color="white">1</font><font color="#fcfdfc">0</font><font color="white">10</font><font color="#fffeff">1</font><font color="#fefefe">0</font><font color="#c1d3be">1</font><font color="#3c7732">0</font><font color="#235d19">1</font><font color="#3f6139">0</font><font color="#d7dad7">1</font><font color="#efe7e4">0</font><font color="#f0e9e8">1</font><font color="#ced7cd">0</font><font color="#6b8c65">1</font><font color="#205618">0</font><font color="#397030">1</font><font color="#266d1a">0</font><font color="#286e1d">1</font><font color="#387e2d">0</font><font color="#78a371">1</font><font color="#dfe8de">0</font><font color="#fefefe">1</font><font color="#fefffe">0</font><font color="white">1010101010</font><font color="#feffff">1</font><font color="#a57f74">0</font><font color="#fefefe">1</font><font color="white">01</font>
<font color="white">01</font><font color="#feffff">0</font><font color="#c7b0a9">1</font><font color="#dccec9">0</font><font color="#feffff">1</font><font color="white">0101010101</font><font color="#f7f9f7">0</font><font color="#6d8d68">1</font><font color="#a5b4a3">0</font><font color="#8f9e8d">1</font><font color="#d9ddd8">0</font><font color="#fefefd">1</font><font color="#cdb1a8">0</font><font color="#a5857c">1</font><font color="#fefefe">0</font><font color="#f3f5f3">1</font><font color="#c2cac1">0</font><font color="#d8e1d7">1</font><font color="#5c8856">0</font><font color="#407338">1</font><font color="#27681e">0</font><font color="#266a1b">1</font><font color="#487f3f">0</font><font color="#dde6dc">1</font><font color="white">01010101010</font><font color="#feffff">1</font><font color="#a58074">0</font><font color="#fefefe">1</font><font color="white">01</font>
<font color="white">01</font><font color="#feffff">0</font><font color="#c7b0a9">1</font><font color="#dccec9">0</font><font color="#feffff">1</font><font color="white">0101010101</font><font color="#f7f9f7">0</font><font color="#e0e5e0">1</font><font color="#fdfdfe">0</font><font color="#fdfdfd">1</font><font color="white">0</font><font color="#faf7f6">1</font><font color="#aa7b6d">0</font><font color="#704f45">1</font><font color="#fefefe">0</font><font color="white">101</font><font color="#eef0ed">0</font><font color="#d9ddd9">1</font><font color="#88a683">0</font><font color="#34652c">1</font><font color="#326b2a">0</font><font color="#62895a">1</font><font color="#fdfdfd">0</font><font color="white">1010101010</font><font color="#feffff">1</font><font color="#a58074">0</font><font color="#fefefe">1</font><font color="white">01</font>
<font color="white">01</font><font color="#feffff">0</font><font color="#c7b0a9">1</font><font color="#dccec9">0</font><font color="#feffff">1</font><font color="white">010101010</font><font color="#fdfcfa">1</font><font color="#ebdeda">0</font><font color="#d2b9b3">1</font><font color="#d5c3be">0</font><font color="#fdfefd">1</font><font color="white">0</font><font color="#e6d8d4">1</font><font color="#986455">0</font><font color="#9b8d89">1</font><font color="white">010101</font><font color="#fbfbfa">0</font><font color="#e3e6e2">1</font><font color="#d3ddd2">0</font><font color="#436b3d">1</font><font color="#eff0ee">0</font><font color="white">1010101010</font><font color="#feffff">1</font><font color="#a58074">0</font><font color="#fefefe">1</font><font color="white">01</font>
<font color="white">01</font><font color="#feffff">0</font><font color="#c7b0a8">1</font><font color="#dccec9">0</font><font color="#feffff">1</font><font color="white">010101010</font><font color="#dfccc7">1</font><font color="#aa7869">0</font><font color="#965c4b">1</font><font color="#875546">0</font><font color="#e0dad8">1</font><font color="#fefefe">0</font><font color="#ceb0a8">1</font><font color="#74483a">0</font><font color="#d6d3d2">1</font><font color="white">010101</font><font color="#feffff">0</font><font color="#e9ddd9">1</font><font color="#fefffe">0</font><font color="#c7d0c5">1</font><font color="#f0f3f0">0</font><font color="white">1010101010</font><font color="#feffff">1</font><font color="#a58074">0</font><font color="#fefefe">1</font><font color="white">01</font>
<font color="white">01</font><font color="#feffff">0</font><font color="#c7b0a8">1</font><font color="#dccec9">0</font><font color="#feffff">1</font><font color="white">01010101</font><font color="#f1e9e6">0</font><font color="#a87566">1</font><font color="#7d4939">0</font><font color="#856d66">1</font><font color="#bdb6b5">0</font><font color="#e3e0df">1</font><font color="#f0e6e3">0</font><font color="#a47465">1</font><font color="#6e4d44">0</font><font color="#fdfdfc">1</font><font color="white">010101</font><font color="#fffffe">0</font><font color="#bf9e93">1</font><font color="#faf9f9">0</font><font color="white">101010101010</font><font color="#feffff">1</font><font color="#a58074">0</font><font color="#fefefe">1</font><font color="white">01</font>
<font color="white">01</font><font color="#feffff">0</font><font color="#c7b0a9">1</font><font color="#dcceca">0</font><font color="#feffff">1</font><font color="white">0101010</font><font color="#fefeff">1</font><font color="#e1d1cc">0</font><font color="#975e4d">1</font><font color="#765b53">0</font><font color="#eeecea">1</font><font color="#fbf9f8">0</font><font color="#e9deda">1</font><font color="#b78d81">0</font><font color="#8e5b4b">1</font><font color="#90807a">0</font><font color="white">1010101</font><font color="#feffff">0</font><font color="#b38f84">1</font><font color="#e4e0de">0</font><font color="white">101010101010</font><font color="#feffff">1</font><font color="#a58074">0</font><font color="#fefffe">1</font><font color="white">01</font>
<font color="white">01</font><font color="#feffff">0</font><font color="#c7b0a9">1</font><font color="#dcceca">0</font><font color="#feffff">1</font><font color="white">01010101</font><font color="#efe7e5">0</font><font color="#955f50">1</font><font color="#a98479">0</font><font color="#d3bbb3">1</font><font color="#bd978b">0</font><font color="#9e6958">1</font><font color="#925745">0</font><font color="#784537">1</font><font color="#c4bebc">0</font><font color="white">1010101</font><font color="#fefdfd">0</font><font color="#a07569">1</font><font color="#d0c8c5">0</font><font color="#fefffe">1</font><font color="white">01010101010</font><font color="#feffff">1</font><font color="#a58074">0</font><font color="#fefffe">1</font><font color="white">01</font>
<font color="white">01</font><font color="#feffff">0</font><font color="#c7b0a9">1</font><font color="#dccec9">0</font><font color="#feffff">1</font><font color="white">01010101</font><font color="#fefefe">0</font><font color="#ccb6ae">1</font><font color="#966353">0</font><font color="#8d5949">1</font><font color="#8d5c4d">0</font><font color="#8a5e52">1</font><font color="#945949">0</font><font color="#6d4236">1</font><font color="#edebeb">0</font><font color="white">1010101</font><font color="#f0e9e7">0</font><font color="#8e6051">1</font><font color="#cec7c4">0</font><font color="#fffffe">1</font><font color="white">01010101010</font><font color="#feffff">1</font><font color="#a57f74">0</font><font color="#fefffe">1</font><font color="white">01</font>
<font color="white">01</font><font color="#feffff">0</font><font color="#c7b0a9">1</font><font color="#dccec9">0</font><font color="#feffff">1</font><font color="white">010101010</font><font color="#fefefe">1</font><font color="#d0c6c3">0</font><font color="#b2a5a1">1</font><font color="#c1bab8">0</font><font color="#e3dedb">1</font><font color="#9e6959">0</font><font color="#72574e">1</font><font color="#fffffe">0</font><font color="white">101010</font><font color="#fefeff">1</font><font color="#d9c2bb">0</font><font color="#7a4b3d">1</font><font color="#dad5d4">0</font><font color="#feffff">1</font><font color="white">01010101010</font><font color="#feffff">1</font><font color="#a58074">0</font><font color="#fefffe">1</font><font color="white">01</font>
<font color="white">01</font><font color="#feffff">0</font><font color="#c7b0a9">1</font><font color="#dccec9">0</font><font color="#feffff">1</font><font color="white">0101010101010</font><font color="#f2eae7">1</font><font color="#9a6656">0</font><font color="#96847f">1</font><font color="#fefefe">0</font><font color="white">101010</font><font color="#f8f4f3">1</font><font color="#b28579">0</font><font color="#6a4338">1</font><font color="#f5f5f5">0</font><font color="white">101010101010</font><font color="#feffff">1</font><font color="#a58074">0</font><font color="#fefefe">1</font><font color="white">01</font>
<font color="white">01</font><font color="#feffff">0</font><font color="#c7b0a9">1</font><font color="#dcceca">0</font><font color="#feffff">1</font><font color="white">0101010101010</font><font color="#ede2df">1</font><font color="#935f50">0</font><font color="#aca29d">1</font><font color="#fefeff">0</font><font color="white">10101</font><font color="#fefefe">0</font><font color="#d9c3bc">1</font><font color="#956151">0</font><font color="#836f69">1</font><font color="white">0101010101010</font><font color="#feffff">1</font><font color="#a58074">0</font><font color="#fefefe">1</font><font color="white">01</font>
<font color="white">010</font><font color="#f8f6f5">1</font><font color="#faf9f8">0</font><font color="white">10101010</font><font color="#fefffe">1</font><font color="#e3ebe1">0</font><font color="#dce7da">1</font><font color="#f3f7f3">0</font><font color="white">10</font><font color="#f1ebe8">1</font><font color="#915b4b">0</font><font color="#b7ada9">1</font><font color="#feffff">0</font><font color="white">1010</font><font color="#fefdfd">1</font><font color="#e0d0ca">0</font><font color="#a26e5f">1</font><font color="#6b4337">0</font><font color="#d7d4d3">1</font><font color="white">01010</font><font color="#fefefe">1</font><font color="#e2ebe1">0</font><font color="#fdfdfc">1</font><font color="white">0101</font><font color="#f8faf7">0</font><font color="#d9e5d7">1</font><font color="#d9dfd3">0</font><font color="#fbfcfa">1</font><font color="white">01</font>
<font color="white">0101010101010</font><font color="#fefefe">1</font><font color="#77a46f">0</font><font color="#99bb92">1</font><font color="#9dbd97">0</font><font color="#fefefe">1</font><font color="white">0</font><font color="#fcfbfb">1</font><font color="#a17061">0</font><font color="#b1a39f">1</font><font color="#fefefe">0</font><font color="white">101</font><font color="#fcfcfb">0</font><font color="#e2d1cc">1</font><font color="#aa7a6c">0</font><font color="#804c3b">1</font><font color="#968884">0</font><font color="#fdfdfd">1</font><font color="white">01010</font><font color="#fefefe">1</font><font color="#63985b">0</font><font color="#f8faf8">1</font><font color="white">0101</font><font color="#dae6d8">0</font><font color="#73a26a">1</font><font color="#689a60">0</font><font color="#f4f8f4">1</font><font color="white">01</font>
<font color="white">01</font><font color="#fefefe">0</font><font color="#dae7d8">1</font><font color="#edf3ec">0</font><font color="white">10101010</font><font color="#fefffe">1</font><font color="#63975a">0</font><font color="#93b78d">1</font><font color="#89b083">0</font><font color="#fefffe">1</font><font color="white">01</font><font color="#ceb4ac">0</font><font color="#a68c84">1</font><font color="#fefefe">0</font><font color="white">1</font><font color="#fdfbfb">0</font><font color="#ece2df">1</font><font color="#c4a298">0</font><font color="#9a6150">1</font><font color="#7c4a3b">0</font><font color="#907e78">1</font><font color="#fbfbfb">0</font><font color="white">10</font><font color="#fffffe">1</font><font color="#dbe7d9">0</font><font color="#ebf2ea">1</font><font color="white">0</font><font color="#fffffe">1</font><font color="#46843c">0</font><font color="#fefffe">1</font><font color="white">0101</font><font color="#d6e4d4">0</font><font color="#63965b">1</font><font color="#46833c">0</font><font color="#fefffe">1</font><font color="white">01</font>
<font color="white">01</font><font color="#fefefe">0</font><font color="#e5ece4">1</font><font color="#99ba92">0</font><font color="#fefefe">1</font><font color="#fdfdfd">01</font><font color="white">0101</font><font color="#fbfcfb">0</font><font color="#fefffe">1</font><font color="#63975a">0</font><font color="#93b78d">1</font><font color="#89b083">0</font><font color="#fefffe">1</font><font color="white">01</font><font color="#f7f3f2">0</font><font color="#b18c81">1</font><font color="#d2bab3">0</font><font color="#d8c1bb">1</font><font color="#c5a398">0</font><font color="#a37365">1</font><font color="#905948">0</font><font color="#784d40">1</font><font color="#9e8f8a">0</font><font color="#f2f1f1">1</font><font color="white">010</font><font color="#fefefe">1</font><font color="#e6eee5">0</font><font color="#94b78e">1</font><font color="white">0</font><font color="#fcfdfc">1</font><font color="#46833b">0</font><font color="#fefffe">1</font><font color="white">0101</font><font color="#d5e3d2">0</font><font color="#63965b">1</font><font color="#46833c">0</font><font color="#fefffe">1</font><font color="white">01</font>
<font color="white">010</font><font color="#ebf1e9">1</font><font color="#438138">0</font><font color="#e0eadf">1</font><font color="#c3d6bf">0</font><font color="#b4ccaf">1</font><font color="white">0</font><font color="#fdfefd">1</font><font color="#fafaf9">0</font><font color="#c5d8c2">1</font><font color="#b3ccae">0</font><font color="#fdfefd">1</font><font color="#63975a">0</font><font color="#93b78d">1</font><font color="#89b083">0</font><font color="#fefffe">1</font><font color="white">01</font><font color="#fefeff">0</font><font color="#ebe5e3">1</font><font color="#a07e73">0</font><font color="#7e4d3f">1</font><font color="#7a493b">0</font><font color="#784f42">1</font><font color="#8a726b">0</font><font color="#c6c1c0">1</font><font color="#fefefe">0</font><font color="#fffeff">1</font><font color="white">0101</font><font color="#ebf2ea">0</font><font color="#3a7c2f">1</font><font color="#e5ede3">0</font><font color="#c3d6c0">1</font><font color="#46833b">0</font><font color="#fefffe">1</font><font color="white">0</font><font color="#f1f5f0">1</font><font color="#d5e2d2">0</font><font color="#cfdfcd">1</font><font color="#b4cdb0">0</font><font color="#63965b">1</font><font color="#46833c">0</font><font color="#fefffe">1</font><font color="white">01</font>
<font color="white">0</font><font color="#fffeff">1</font><font color="#cedecb">0</font><font color="#5a9151">1</font><font color="#397a2d">0</font><font color="#9bbb95">1</font><font color="#7ea977">0</font><font color="#4c8843">1</font><font color="#fdfefc">0</font><font color="#82ab7b">1</font><font color="#b3ccaf">0</font><font color="#498540">1</font><font color="#c2d6be">0</font><font color="#d7e4d5">1</font><font color="#578f4d">0</font><font color="#93b78d">1</font><font color="#77a470">0</font><font color="#f5f9f4">1</font><font color="white">0101</font><font color="#f4f1f0">0</font><font color="#e2dbda">1</font><font color="#d7d0cd">0</font><font color="#e4e0de">1</font><font color="#f3f3f2">0</font><font color="white">101010</font><font color="#d1e0ce">1</font><font color="#5a9051">0</font><font color="#307624">1</font><font color="#a1bf9b">0</font><font color="#8bb185">1</font><font color="#428239">0</font><font color="#e6eee5">1</font><font color="#e2eae0">0</font><font color="#548c4a">1</font><font color="#428138">0</font><font color="#73a26b">1</font><font color="#87ae80">0</font><font color="#62975a">1</font><font color="#46833c">0</font><font color="#e3ece1">1</font><font color="#fdfdfd">0</font><font color="white">1</font>
<font color="white">0</font><font color="#fefffe">1</font><font color="#d9e5d7">0</font><font color="#a5c4a0">1</font><font color="#9fbf99">0</font><font color="#7ca775">1</font><font color="#8fb489">0</font><font color="#639659">1</font><font color="#d4e2d1">0</font><font color="#5a9050">1</font><font color="#a0bf9a">0</font><font color="#9dbd97">1</font><font color="#a9c5a4">0</font><font color="#aac6a5">1</font><font color="#63975b">0</font><font color="#94b78e">1</font><font color="#78a471">0</font><font color="#e9f0e7">1</font><font color="#fefffe">0</font><font color="white">10101010101010</font><font color="#d9e6d7">1</font><font color="#a5c3a0">0</font><font color="#9ebf9a">1</font><font color="#81ab7a">0</font><font color="#8eb388">1</font><font color="#558f4d">0</font><font color="#c9dbc6">1</font><font color="#ccdcca">0</font><font color="#6e9d65">1</font><font color="#3f7f35">0</font><font color="#8cb285">1</font><font color="#9dbe98">0</font><font color="#6f9d67">1</font><font color="#5e9356">0</font><font color="#c4d8c1">1</font><font color="#f9fbf9">0</font><font color="white">1</font>
<font color="white">01010</font><font color="#d4e2d1">1</font><font color="#e6eee5">0</font><font color="#f1f6f0">1</font><font color="#f3f6f2">0</font><font color="#e9f0e8">1</font><font color="#fdfdfd">0</font><font color="white">10</font><font color="#fefefe">1</font><font color="#f5f9f5">0</font><font color="#f1f5f1">1</font><font color="#f8faf7">0</font><font color="#fefffe">1</font><font color="white">010101010101010101</font><font color="#e3ece2">0</font><font color="#f2f7f1">1</font><font color="#f0f5f0">0</font><font color="white">1</font><font color="#fbfbfa">0</font><font color="#eaf1ea">1</font><font color="#f0f4ef">0</font><font color="#fbfcfa">1</font><font color="#fdfefd">0</font><font color="#f1f5f0">1</font><font color="#f1f5ef">0</font><font color="#fefefe">1</font><font color="white">01</font>
<font color="white">01010101010101010101010101010101010101010101010101</font>
</pre></font>
<!-- IMAGE ENDS HERE -->
</td>
</tr>
</tbody>
</table>
</body>
</html>
EOF;

}
}

?>