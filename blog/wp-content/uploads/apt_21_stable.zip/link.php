<?php
/*
+===========================================+
|      ArabPortal V2.1.x Copyright � 2006   |
|   -------------------------------------   |
|            By Rafia AL-Otibi              |
|                    And                    |
|              Arab Portal Team             |
|   -------------------------------------   |
|      Web: http://www.ArabPortal.Net       |
|   -------------------------------------   |
|  Last Updated: 01/01/2007 Time: 00:00 AM  |
+===========================================+
*/

require_once('global.php');
checkgroup('view_site');
checkgroup('view_link');
$action = $apt->get['action'];
$cat_img = "site.gif";

if ($action=="")
{
    $apt->head(LANG_TITLE_LINKS);
    $linkColcount    = intval($apt->getsettings("linkColcount"));
    if($linkColcount < 1 ) $linkColcount = 1;
    $index_middle = $apt->table_cat_module(LANG_TITLE_LINKS);   // Added by Myrosy
    $index_middle .= "<center><table border='0' width='100%' align='center' cellpadding='".$linkColcount."'><tr>";
    $result = $apt->query("SELECT * FROM rafia_cat WHERE catType='4' and subcat='0' ORDER BY ordercat ASC");

    while($row = $apt->dbarray($result))
    {
        extract($row);

        $numrows       = $countopic + $apt->countcat($id,'countopic');
        $title         =  $apt->format_data_out($title);
        $dsc           =  $apt->format_data_out($dsc);

        $tdwidth =  100/$linkColcount;
        $index_middle .= "<td align=\"center\" width=\"".$tdwidth."%\"  valign=\"top\">";

        eval("\$index_middle .= \" " . $apt->gettemplate ( 'link_cat' ) . "\";");
         $index_middle .= "</td>";
         $count++;
         if ($count ==  $linkColcount)
         {
             $index_middle .= "</tr>";
             $count = 0;
         }
    }
    $index_middle .= "</tr></table><br>";
     $menu = new menu;
     $menu->menuid =  $apt->getsettings("link_menuid");
     $right_menu   = $menu->_menu(1);
$middle_menu_count  =  $apt->getsettings("count_middle_menu");
$middle_menu = "<table border=0 cellpadding=0 cellspacing=0 width=100%><tr valign=top>";
$middle_menus = $menu->_menu(3);
$ex = @explode('<!-- BLOCK END -->',$middle_menus);
$m=0;
foreach($ex as $amenu){
$middle_menu .= '<td valign=top>'.$amenu.'</td>';
$m++;
if($m==$middle_menu_count)$middle_menu .= "</tr>";
}
$middle_menu .= "</tr></table><br>";


     if($apt->getsettings("link_left_menu"))
     $left_menu    = $menu->_menu(2);
      $apt->html_Output($left_menu);
}
elseif ($action=="list")
{
    $cat_id = $apt->setid('cat_id');

    $perpage = $apt->getsettings("linkperpagelist");
      
    $result = $apt->query("SELECT * FROM rafia_cat
                             WHERE id='$cat_id'
                             ORDER BY id DESC");
                             
       $row = $apt->dbarray($result);
       extract($row);
       
        $apt->head($title);
        $title         =  $apt->format_data_out($title);
        $dscin         =  $apt->format_data_out($dscin);
        
         eval("\$index_middle = \" " . $apt->gettemplate ( 'cat_table' ) . "\";");

   ///////////subcat/////////
    $result = $apt->query("SELECT * FROM rafia_cat WHERE catType='4' and subcat ='$cat_id' ORDER BY ordercat ASC");
    if($apt->dbnumrows($result)>0)
    {
        while($row = $apt->dbarray($result))
        {
            @extract($row);
            $numrows       = $countopic + $apt->countcat($id,'countopic');
            $title         =  $apt->format_data_out($title);
            $dsc           =  $apt->format_data_out($dsc);
            eval("\$index_middle .= \" " . $apt->gettemplate ( 'link_cat' ) . "\";");

      }
     }
   ////////////////////
   $Jump = $apt->listJumpf("$PHP_SELF?action=list&cat_id=","4");
    
      eval("\$index_middle .= \" " . $apt->gettemplate ( 'link_cat_tools' ) . "\";");

    $result = $apt->query("SELECT * FROM rafia_links
                                      WHERE allow='yes' and
                                      cat_id=$cat_id
                                      ORDER BY id DESC
                                      LIMIT  $start,$perpage");

     
    while($row = $apt->dbarray($result))
 	{
        extract($row);
        $rating     = @ceil($rating_total/$ratings);
        $rating_avg = $apt->rating_avg($rating);
        $title      = $apt->format_data_out($title);
        $name       = $apt->format_data_out($name);
        $email      = $apt->format_data_out($email);
        $post       = $apt->rep_words($post);
        $post       = $apt->format_data_out($post);
        $url        = $apt->format_data_out($apt->addToURL($url));

         eval("\$index_middle .= \"" . $apt->gettemplate ( 'link_list' ) . "\";");

    }
    $apt->numrows = $apt->dbnumquery("rafia_links","allow='yes' and cat_id=$cat_id");
    $index_middle .= $apt->pagenum($perpage,"list&cat_id=$cat_id");
     $menu = new menu;
     $menu->menuid =  $apt->getsettings("link_menuid");
     $right_menu   = $menu->_menu(1);
$middle_menu_count  =  $apt->getsettings("count_middle_menu");
$middle_menu = "<table border=0 cellpadding=0 cellspacing=0 width=100%><tr valign=top>";
$middle_menus = $menu->_menu(3);
$ex = @explode('<!-- BLOCK END -->',$middle_menus);
$m=0;
foreach($ex as $amenu){
$middle_menu .= '<td valign=top>'.$amenu.'</td>';
$m++;
if($m==$middle_menu_count)$middle_menu .= "</tr>";
}
$middle_menu .= "</tr></table><br>";

     if($apt->getsettings("link_left_menu"))
     $left_menu    = $menu->_menu(2);
      $apt->html_Output($left_menu);

}
else  if ($action=="add")
{
    $linkallow = $apt->getsettings("linkallow");
    if ($linkallow =="no"){
        checkcookie();
    }
    $cat_id =  $apt->is_NO('cat_id');
    $apt->head(LANG_TITLE_ADD_SITE);
    $fo = new form;
    $cap = $apt->getcaptcha();
    $fo->use_smiles = 0;
    $countpost = $apt->getsettings('txtcount10');

    if(!$cat_id){
        $cat = $fo->selectform("4");
    }else{
        $cat = $fo->hiddenform  ("cat_id", $cat_id);
    }
    if( $apt->cookie['clogin'] != "rafiaphp")
    {
       $yrname = $fo->inputform($apt->lang_form['28'],"text","name","*","");
       $yrmail = $fo->inputform($apt->lang_form['28'],"text","email","*","");
    }

    eval("\$index_middle = \" " . $apt->gettemplate ( 'link_add' ) . "\";");

    //$index_middle = $fo->link_form('add');

    $menu = new menu;
    $menu->menuid =  $apt->getsettings("link_menuid");
    $right_menu   = $menu->_menu(1);
$middle_menu_count  =  $apt->getsettings("count_middle_menu");
$middle_menu = "<table border=0 cellpadding=0 cellspacing=0 width=100%><tr valign=top>";
$middle_menus = $menu->_menu(3);
$ex = @explode('<!-- BLOCK END -->',$middle_menus);
$m=0;
foreach($ex as $amenu){
$middle_menu .= '<td valign=top>'.$amenu.'</td>';
$m++;
if($m==$middle_menu_count)$middle_menu .= "</tr>";
}
$middle_menu .= "</tr></table><br>";
    if($apt->getsettings("link_left_menu"))
    $left_menu    = $menu->_menu(2);

    $apt->html_Output($left_menu);

}
else if($action=="insert")
{

     checkgroup('add_link');
     extract($_POST);

    $this_url = explode('/',$_SERVER['HTTP_HOST']);
    $reff_url = explode('/',$_SERVER['HTTP_REFERER']);

    if($this_url[0] !== $reff_url[2]){
    $apt->bodymsg('���� ... �� ����� ����� ���� �� ���� ������',"link.php?action=add&cat_id=$cat_id");
    }
    $cap = $apt->getcaptcha();
    if($spam !== "linknotspam_$cap"){
    $apt->bodymsg('���� ... ��� ������� ��� ������',"link.php?action=add&cat_id=$cat_id");
    exit;
    }

     if (!$apt->full($_POST))
     {
         $apt->errmsg(LANG_ERROR_VALIDATE);
     }

    if( $apt->cookie['clogin'] != "rafiaphp")
    {
     if (!$apt->check_email($email))
     {
         $apt->errmsg(LANG_ERROR_VALID_EMIAL);
     }
    }
     if (!$apt->txtcounmxs($post,$apt->getsettings("txtcount10")))
      {
          $apt->errmsg(LANG_ERROR_LETTER_MAX);
      }
      
      
      $userid     = $apt->format_data($apt->cookie['cid']);

      if(isset($apt->post['name']) && $apt->cookie['cid']== $apt->Guestid)
      {
         $name  = $apt->format_data($apt->post['name']);

         if (!$apt->checkifues("username",$name))
         {
             $apt->errmsg (LANG_ERROR_USERNAME_EXISTED);
         }
     }
     else
     {
         $name  = $apt->format_data($apt->cookie['cname']);
     }
    
      
     if($userid == '0')
     {
         $name   = $apt->format_data($name);
     }
     else
     {
         $name   = $apt->format_data($apt->cookie['cname']);
     }
     
    $title  = $apt->format_data($title);
    $email  = $apt->format_data($email);
    $post   = $apt->format_post($post);
    $url    = $apt->format_data($url);
    $cat_id = $apt->format_data($cat_id);

    if(strstr($url,'http://'))
    {
        $url = str_replace("http://","",$url);
    }
    
    $timestamp = time();

    $result = $apt->query("SELECT * FROM rafia_links WHERE url='$url'");
    if ($apt->dbnumrows($result) > 0)
    {
        $apt->errmsg(LANG_ERROR_LINK_EXISTED);
    }

    $Spams  = new Spams();
    if( $Spams->checkSpams() == false )
    {
        $apt->bodymsg(LANG_ERROR_WAIT_SECONDS,'link.php');
    }
    $linkallow = $apt->retcheckgroup('stat_link',1);
    
    $result = $apt->query("insert into rafia_links (cat_id,
                                                      title,
                                                      date_time,
                                                      name,
                                                      email,
                                                      post,
                                                      url,
                                                      allow)
                                                values
                                                     ('$cat_id',
                                                      '$title',
                                                      '$timestamp',
                                                      '$name',
                                                      '$email',
                                                      '$post',
                                                      '$url',
                                                      '$linkallow')");
    if ($result)
    {
         $id = $apt->insertid();

         $apt->query("UPDATE rafia_cat SET countopic = countopic+1 WHERE id = '$cat_id'");
         $mail = new email;
         $mail->send_to_moderate($cat_id);
        $url="$PHP_SELF?action=list&cat_id=$cat_id";
        if ($linkallow!="yes")
        {
            $Counter->increment('linksCount');
            $apt->bodymsg(LANG_MSG_THREAD_HAS_ADDED,$url);
        }
        else
        {

           $apt->bodymsg(LANG_MSG_POST_HAS_BEEN_ADDED,$url);
        }
    }
}
else if($action=="edit")
{
      $id = $apt->setid('id');

      if( $apt->checkcookieadmin(5))
    {
        $result= $apt->query("select * from rafia_links where id='$id'");

        $apt->row = $apt->dbarray($result);
        $apt->head(LANG_TITLE_MODERATE_POSTS);
        $fo = new form;
        $fo->use_smiles =0;

        $index_middle = $fo->link_form('edit');
            $menu = new menu;
            $menu->menuid =  $apt->getsettings("link_menuid");
            $right_menu   = $menu->_menu(1);

            if($apt->getsettings("link_left_menu"))
            $left_menu    = $menu->_menu(2);
        $apt->html_Output( $left_menu );
        
    }
    else
    {
        $apt->head(LANG_TITLE_LOG_IN);

         eval("print \"" . $apt->gettemplate ( 'Login_main' ) . "\";");

    }
}
else if($action=="UK")
{
    checkcookie();
    $id = $apt->setid('id');
    if (( $apt->cookie['cgroup'] == $apt->a_g) || ( $apt->cookie['cgroup'] == $apt->m_g))
    {
         @extract($_POST);

         if ($apt->post['del'] =='1')
         {
             $apt->delmsg($cat_id,$id);
         }
         
         $allow = $apt->adminunset($allow);
         $title = $apt->format_data($title);
         $post  = $apt->format_post($post);
         $name  = $apt->format_data($name);
         $email = $apt->format_data($email);
         $url   = $apt->format_data($url);
         
         $result= $apt->query("update rafia_links set cat_id='$cat_id',
                                 title='$title',name='$name',email='$email',
                                 post='$post', url='$url',allow='$allow'
                                 where id='$id'");
                                 
         $url = "$PHP_SELF?action=list&cat_id=$cat_id";
         
        if ($result)
        {
            $apt->bodymsg(LANG_MSG_POST_HAS_BEEN_EDITED,$url);
        }
        else
        {
            $apt->bodymsg(LANG_ERROR_ADD_DB,$url);
        }
    }
}
else  if ($action=="goto"){
    $id = $apt->setid('id');
    $result= $apt->query("SELECT * FROM rafia_links WHERE id='$id' and allow='yes'");
    $row= $apt->dbarray($result);
        extract($row);
        if($clicks==""){$clicks=0;}
        $clicks=$clicks + 1;
        $result=$apt->query("update rafia_links set clicks='$clicks' where id='$id'");
        if($result){
		$url=$apt->addToURL($url);
            $redirect="Location:$url";
            header($redirect);
        }
}
else if($action=="admin")
{
    $apt->head(LANG_TITLE_MODERATE_POSTS);

    if (( $apt->cookie['cgroup'] ==  $apt->a_g) || ( $apt->cookie['cgroup'] ==  $apt->m_g))
    {
        if ( $apt->cookie['cgroup'] == $apt->a_g)
        {
            $result = $apt->query("SELECT * FROM rafia_cat WHERE catType='4' ORDER BY id DESC");
        }
        else
        {
            $result = $apt->query("SELECT rafia_cat.*
                                     FROM rafia_cat,rafia_moderate
                                     WHERE rafia_cat.catType !='0' AND rafia_cat.id=rafia_moderate.moderatecatid
                                     AND rafia_moderate.moderateid =".$apt->cookie['cid']."
                                     ORDER BY id DESC");
        }
                                 
        $countwit = $apt->dbnumquery("rafia_links","allow='wit'");

        if ($countwit == "")
        {
            $countwit=" �� ����";
        }

        $index_middle .=  $apt->admintablehead("$PHP_SELF?action=wait","����� ������");

         while($row = $apt->dbarray($result))
        {
            @extract($row);
            if(($apt->cookie['cgroup']==$apt->m_g ) ||  ($apt->cookie['cgroup'] == $apt->a_g))
            {
                $numrows = $apt->dbnumquery("rafia_links","cat_id='$id'");
                $index_middle .= $apt->admintablecell("$PHP_SELF?action=showit&cat_id=$id");
            }
        }
        $index_middle .= $apt->admintableclose();
        $apt->html_Output($left_menu);
    }
    else
    {
        $apt->head(LANG_TITLE_LOG_IN);
        eval("print \"" . $apt->gettemplate ( 'Login_main' ) . "\";");
        $apt->foot($pageft);
        exit;
    }
}
else if($action == 'showit')
{
    $perpage = 50;

    $cat_id = $apt->setid('cat_id');

    if( $apt->checkcadmincat($cat_id) )
    {
       $apt->head(LANG_TITLE_MODERATE_POSTS);

       $result = $apt->query ("SELECT * FROM rafia_links WHERE
                                 cat_id=$cat_id ORDER BY id DESC
                                 LIMIT  $start,$perpage");

       $apt->numrows = $apt->dbnumquery("rafia_links","allow='yes' and cat_id=$cat_id");

       $index_middle .= $apt->pagenum($perpage,"link&cat_id=$cat_id");



        $index_middle  .= $apt->admin_form_opan("doit");

         $index_middle .= $apt->admin_table_head("������� ���� �������");

       while($apt->row = $apt->dbarray($result))
       {

           $index_middle .=  $apt->admin_table_cell("cat_id=$cat_id&id","edit","",0);
       }

         $index_middle .= $apt->admin_table_close();

        $index_middle .=  $apt->admin_form_close('4');

       $apt->html_Output($left_menu);

}
else
{
       $apt->head(LANG_TITLE_LOG_IN);

      eval("print \"" . $apt->gettemplate ( 'Login_main' ) . "\";");


}
}
//---------------------------------------------------
//
//---------------------------------------------------

else if( $action== "doit" )
{
    if ( $apt->checkcadmincat($apt->post['cat_id']))
    {
        $cat_id =  $apt->post['cat_id'];
        $catid  =  $apt->post['catid'];

        if (count($apt->post['do']) > 0)
        {
             if($apt->post['move'])
             {
                 foreach($apt->post['do'] as $id)
                 {

                    $result = $apt->query("update rafia_links set cat_id='$catid' where id='$id'");

                }
                if ($result)
                {
                    $numrows = $apt->dbnumquery("rafia_links","cat_id='$catid'");
                    $result  = $apt->query("update rafia_cat set countopic='$numrows' where id='$catid'");
                    $numrows = $apt->dbnumquery("rafia_links","cat_id='$cat_id'");
                    $result  = $apt->query("update rafia_cat set countopic='$numrows' where id='$cat_id'");
                    $apt->bodymsg(LANG_MSG_THREAD_HAS_MOVED,$apt->refe);
                 }

            }
            elseif($apt->post['del'])
            {
                foreach($apt->post['do'] as $id)
                {
                    $result  = $apt->query("delete from  rafia_links where id='$id'");
                }
                if ($result)
                {
                    $numrows = $apt->dbnumquery("rafia_links","cat_id='$cat_id'");
                    $result  = $apt->query("update rafia_cat set countopic='$numrows' where id='$cat_id'");
                    $apt->bodymsg(LANG_MSG_POST_HAS_BEEN_DELETED,$apt->refe);
                }
            }
            elseif($apt->post['allow'])
            {
                 foreach($apt->post['do'] as $id)
                 {
                    $result = $apt->query("update rafia_links set allow='yes' where id=$id");
                 }
                 if ($result)
                 {
                     $apt->bodymsg(LANG_MSG_POST_HAS_APPROVED,$apt->refe);
                }
             }
         }
         else
        {
            $apt->errmsg(LANG_ERROR_CHOICE);
        }
    }
     else
    {
         $apt->errmsg(LANG_ERROR_DEL_BY_ADMIN);
    }
}

else if( $action == "del" )
{
    $cat_id = $apt->post['cat_id'];

    if((!$apt->checkcadmincat($cat_id)) ||(!$apt->checkcmodcat('can_delete')))
    {
       $apt->head(LANG_TITLE_LOG_IN);

      eval("print \"" . $apt->gettemplate ( 'Login_main' ) . "\";");

      exit;
   }
    if(!empty( $apt->post['idp']))
    {
        $id = $apt->post['idp'];

        $result = $apt->query("delete from  rafia_links where id=$id");
    }
    if($result)
    {
        $Rurl = "link.php?action=list&cat_id=$cat_id";
        $apt->bodymsg(LANG_MSG_POST_HAS_BEEN_DELETED,$Rurl);
    }
}

else if($action=="wait")
{
    if (( $apt->cookie['cgroup'] ==  $apt->a_g) || ( $apt->cookie['cgroup'] ==  $apt->m_g))
    {
        $apt->head(LANG_TITLE_MODERATE_POSTS);

        $result = $apt->query("SELECT * FROM rafia_links WHERE allow='wit' ORDER BY id ASC");

        if($apt->dbnumrows($result))
        {
            $index_middle .= $apt->admin_form_opan("doit");

            $index_middle .= $apt->admin_table_head("������ ��� ��������");

             while($apt->row = $apt->dbarray($result))
            {

                $index_middle .=$apt->admin_table_cell("link_id","edit","",0);
            }

            $index_middle .= $apt->admin_table_close();
            $index_middle .= $apt->admin_form_close('4',0);

            }
            else
            {
                $index_middle .= "<p>�� ���� ������ ��� ��������.</p>";
            }
             $apt->html_Output($left_menu);
        }
        else
        {
            $apt->head(LANG_TITLE_LOG_IN);

            eval("print \"" . $apt->gettemplate ( 'Login_main' ) . "\";");

        }
}

$apt->foot($pageft);
?>