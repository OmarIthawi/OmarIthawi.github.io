<?php
/***************************************************************************
			   ������ ���� ����� ����� ������� �������
			   ����� ����� ����� || ���� ��� �������
			www.arabiaone.org (arabgenius@hotmail.com)
***************************************************************************/

if (RUN_MODULE !== true)
{
    die ("<center><h3>���� ��� ������� ��� ������</h3></center>");
}

include("modules/gallery/config.php");
include("modules/gallery/functions.php");
include("modules/gallery/rollover.txt");

if(!$apt->request["word"]){
$apt->errmsg("���� ... ��� �� ���� ���� ����� �������� �� �� ������ ���� ������ ��� �� 4 ����");
}

if($apt->post["word"]){
$word 	= $apt->format_post(trim($apt->post["word"]));
$highlight 	= urlencode($word);
}else{
$word 	= urldecode($apt->format_post(trim($apt->get["word"])));
$highlight 	= urlencode($apt->get["word"]);
}

$page = $apt->get[page];
if(!$page) $page=1;
$end=12; 
$show=3; 
$start=$page*$end-$end; 
if($start < 0) $start=0;

if($Cat_Colcount < 1 ) $Cat_Colcount = 1;

$index_middle = $apt->table_cat_module("<a href=mod.php?mod=$mod_name>&nbsp;$mod_title</a>");

$page_icon ='';

$result = $apt->query("SELECT * FROM rafia_gallery_image where imgtitle LIKE '%$word%' or imgdesc LIKE '%$word%' and allow=1 ORDER BY imgid DESC LIMIT $start,$end");
eval("\$index_middle .= \" " . $apt->getmodtemplate ( 'gallery_header', $modid,$mod_theme ) . "\";");
$index_middle .= "<table border='0' width='100%' align='center' cellpadding='".$Cat_Colcount."'><tr>";
if($apt->dbnumrows($result)== 0){
$index_middle .= "<td align=\"center\" width=\"100%\"  valign=\"top\" height=\"100%\">";
$index_middle .= "<b> ���� .. �� ���� �� ����� ����� [ ".urldecode($highlight)." ] </b>";
$index_middle .= "</td>";
}else{
while($row = $apt->dbarray($result)){
@extract($row);
$tdwidth =  100/$Cat_Colcount;
$index_middle .= "<td align=\"center\" width=\"".$tdwidth."%\"  valign=\"top\">";

if($hide_link == 1){
$photo = "<img src=\"mod.php?mod=gallery&modfile=view&thumb=1&imgid=$imgid\" WIDTH=121 HEIGHT=86 border=0 alt='$a_img[$x]' style=\"filter:alpha(opacity=100)\" onmouseout=\"gradualfade(this,100,30,4)\" onmouseover=\"gradualfade(this,40,50,100)\">";
}else{
$photo = "<img src=\"modules/gallery/thumb/$imglink\" WIDTH=121 HEIGHT=86 border=0 alt='$a_img[$x]' style=\"filter:alpha(opacity=100)\" onmouseout=\"gradualfade(this,100,30,4)\" onmouseover=\"gradualfade(this,40,50,100)\">";
}

$index_middle .= "
<TABLE dir=ltr BORDER=0 CELLPADDING=0 CELLSPACING=0>
	<TR>
		<TD COLSPAN=3>
			<IMG SRC=\"$place/ds_img_up.gif\" ALT=\"\"></TD>
	</TR>
	<TR>
		<TD>
			<IMG SRC=\"$place/ds_img_left.gif\" ALT=\"\"></TD>
		<TD>
		<a href='mod.php?mod=gallery&modfile=picshow&imgid=$imgid&highlight=$highlight'>$photo</a></TD>
		<TD>
			<IMG SRC=\"$place/ds_img_right.gif\" ALT=\"\"></TD>
	</TR>
	<TR>
		<TD COLSPAN=3>
			<IMG SRC=\"$place/ds_img_down.gif\" ALT=\"\"></TD>
	</TR>
</TABLE>
";
$index_middle .= "</td>";
$count++;
if ($count ==  $Cat_Colcount)
{
$index_middle .= "</tr>";
$count = 0;
}
}
}
$index_middle .= "</tr></table><br>";

$Sql2 = "select * from rafia_gallery_image where imgtitle LIKE '%$word%' or imgdesc LIKE '%$word%'"; 
$user2 = mysql_query($Sql2); 
$rows=mysql_num_rows($user2); 
$links=$rows/$end; 
$lastlink=ceil($links); 

if($rows > $end){
if ($lastlink!=1) {
$index_middle .= "<b>������� : </b>";
if (($lastlink<=$page+$show and $page-$show>1) or ($page-$show>1) ) { $index_middle .= "<a title='��� ����' href=mod.php?mod=gallery&modfile=search&word=$highlight&page=1> � </a> ..";} 
if ($page-$show<1) { for ($i=1 ;$i<=$page-1 ;$i++) $index_middle .= "<a href=mod.php?mod=gallery&modfile=search&word=$highlight&page=$i>[$i]</a>"; } 
if ($page-$show>=1) { for ($i=$page-$show ;$i<=$page-1 ;$i++) $index_middle .= "<a href=mod.php?mod=gallery&modfile=search&word=$highlight&page=$i>[$i]</a>"; } 
if ($lastlink>$page+$show) { $index_middle .= "[$page]"; for ($i=$page+1 ;$i<=$page+$show ;$i++) { $index_middle .= "<a href=mod.php?mod=gallery&modfile=search&word=$highlight&page=$i>[$i]</a>";}
$index_middle .= " .. <a title='��� ����' href=mod.php?mod=gallery&modfile=search&word=$highlight&page=$lastlink> � </a>"; } 
if ($lastlink<=$page+$show) { $index_middle .= "[$page]"; for ($i=$page+1 ;$i<=$lastlink ;$i++) $index_middle .= "<a href=mod.php?mod=gallery&modfile=search&word=$highlight&page=$i>[$i]</a>"; } 
}
}

eval("\$index_middle .= \" " . $apt->getmodtemplate ( 'gallery_footer', $modid,$mod_theme ) . "\";");
echo $index_middle;

?>