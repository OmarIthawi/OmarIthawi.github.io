<?php
/***************************************************************************
			   ������ ���� ����� ����� ������� �������
			   ����� ����� ����� || ���� ��� �������
			www.arabiaone.org (arabgenius@hotmail.com)
***************************************************************************/

if (RUN_MODULE !== true)
{
    die ("<center><h3>���� ��� ������� ��� ������</h3></center>");
}

include("modules/gallery/config.php");
include("modules/gallery/functions.php");
include("modules/gallery/rollover.txt");

$index_middle = $apt->table_cat_module("<a href=mod.php?mod=$mod_name>&nbsp;$mod_title</a>");

$user_group = $apt->cookie['cgroup'];
if(in_array($user_group,$allow_edit)){
$wait_no = $apt->dbnumquery("rafia_gallery_image","allow=0");
$page_icon = "<br><a href=mod.php?mod=gallery&modfile=wait><b>������� ��� �������� [$wait_no]</b></a>";
}else{$page_icon ='';}

if($Index_Colcount < 1 ) $Index_Colcount = 1;
$result = $apt->query("SELECT * FROM rafia_gallery_cat ORDER BY gorder ASC");

eval("\$index_middle .= \" " . $apt->getmodtemplate ( 'gallery_header', $modid,$mod_theme ) . "\";");
$index_middle .= "<table border='0' width='100%' align='center' cellpadding='".$Index_Colcount."'><tr>";

if($apt->dbnumrows($result)== 0){
$index_middle .= "<td align=\"center\" width=\"100%\"  valign=\"top\" height=\"100%\">";
$index_middle .= " ";
$index_middle .= "</td>";
}else{
while($row = $apt->dbarray($result))
{
@extract($row);
$title	=  $apt->format_data_out($gtitle);
$gdesc	=  $apt->format_data_out($gdesc);
$tdwidth =  100/$Index_Colcount;
$index_middle .= "<td align=\"center\" width=\"".$tdwidth."%\"  valign=\"top\" height=\"100%\">";
eval("\$index_middle .= \" " . $apt->getmodtemplate ( 'gallery_category', $modid,$mod_theme ) . "\";");
$index_middle .= "</td>";
$count++;
if ($count ==  $Index_Colcount){
$index_middle .= "</tr>";
$count = 0;
}
}
}
$index_middle .= "</tr></table><br>";
eval("\$index_middle .= \" " . $apt->getmodtemplate ( 'gallery_footer', $modid,$mod_theme ) . "\";");

echo $index_middle;
?>