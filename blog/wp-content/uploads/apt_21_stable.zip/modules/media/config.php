<?php
/*
+===========================================+
|      ArabPortal V2.1.x Copyright � 2006   |
|   -------------------------------------   |
|            By Rafia AL-Otibi              |
|                    And                    |
|              Arab Portal Team             |
|   -------------------------------------   |
|      Web: http://www.ArabPortal.Net       |
|   -------------------------------------   |
|  Last Updated: 01/01/2007 Time: 00:00 AM  |
+===========================================+
*/


if (RUN_MODULE !== true)
{
    die ("<center><h3>���� ��� ������� ��� ������</h3></center>");
}

$mod_theme	= $mod->modInfo[themeid];
$mod_name	= $mod->modInfo[mod_name];
$modid	= $mod->modInfo[id];
$mod_title	= $mod->modInfo[mod_title];

$file_size  = $mod->getmodsettings('file_size',$mod_id);
$allow_user = $mod->getmodsettings('allow_user',$mod_id);
$new_active = $mod->getmodsettings('new_active',$mod_id);

$allow_ext = array('.mp3','.rm','.ram','.rmvb','.wav','.wma','.wmv','.swf','.avi');
$allow_types = array('audio/vnd.rn-realmedia','audio/x-ms-wma','video/x-ms-wmv', 'audio/wav', 'audio/mp3', 'audio/mpeg', 'application/vnd.rn-realmedia-vbr', 'video/avi', 'application/vnd.rn-realmedia', 'audio/x-pn-realaudio','application/x-shockwave-flash');

$audio_ext = array('.wma', '.wav', '.mp3', '.rm', '.ram');
$vedio_ext = array('.rmvb', '.wmv', '.avi');
$flash_ext = array('.swf');

$audio_types = array('audio/x-ms-wma', 'audio/wav', 'audio/mp3', 'audio/x-pn-realaudio');
$vedio_types = array('application/vnd.rn-realmedia-vbr', 'application/vnd.rn-realmedia', 'video/x-ms-wmv', 'video/avi');
$flash_types = array('application/x-shockwave-flash');

$result = $apt->query("SELECT * FROM rafia_media_items where item_allow=1 order by item_id DESC limit 10");
$media_newitems='';
while(@extract($apt->dbarray($result))){
$media_newitems .= '<li><a href=mod.php?mod=media&modfile=item&itemid='.$item_id.'>'.$item_title.'</a>';
}

$result = $apt->query("SELECT * FROM rafia_media_items where item_allow=1 order by item_show DESC limit 10");
$media_pop_items ='';
while(@extract($apt->dbarray($result))){
$media_pop_items .= '<li><a href=mod.php?mod=media&modfile=item&itemid='.$item_id.'>'.$item_title.'</a>';
}

$catCount = $apt->dbnumquery("rafia_media_cat");
$itemCount= $apt->dbnumquery("rafia_media_items","item_allow=1");

$open_hide  = "";
$close_hide = "";

$member_un   = $apt->format_data($apt->cookie['cname']);
$member_gp = $apt->format_data($apt->cookie['cgroup']);

?>