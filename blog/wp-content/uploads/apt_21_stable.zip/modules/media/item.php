<?php
/*
+===========================================+
|      ArabPortal V2.1.x Copyright � 2006   |
|   -------------------------------------   |
|            By Rafia AL-Otibi              |
|                    And                    |
|              Arab Portal Team             |
|   -------------------------------------   |
|      Web: http://www.ArabPortal.Net       |
|   -------------------------------------   |
|  Last Updated: 01/01/2007 Time: 00:00 AM  |
+===========================================+
*/


if (RUN_MODULE !== true)
{
    die ("<center><h3>���� ��� ������� ��� ������</h3></center>");
}

$itemid= $apt->setid('itemid');
include("modules/media/config.php");

$uresult = $apt->query("SELECT userid,username FROM rafia_users");
while(@extract($apt->dbarray($uresult))){
$user[$userid] = $username;
}

$result = $apt->query("SELECT * FROM rafia_media_items where item_allow=1 and item_id='$itemid'");
if($apt->dbnumrows($result)== 0){$apt->errmsg("���� ... �������� ���� ���� ���� ��� ������ �� �� �����");}
@extract($apt->dbarray($result));
$item_user = $user[$item_uid];
$item_date = $apt->Hijri($item_date);

$result_c = $apt->query("SELECT cat_title FROM rafia_media_cat where cat_id='$item_cat'");
@extract($apt->dbarray($result_c));
$index_middle = $apt->table_cat_module("<a href=mod.php?mod=$mod_name>&nbsp;$mod_title</a> � <a href=mod.php?mod=media&modfile=category&catid=$item_cat>$cat_title</a>");
$item_desc          = $apt->rep_words ($item_desc);
$item_desc          = $apt->rafia_code($item_desc);
$rate		        = @round(($item_crate/$item_rate),1);

$apt->title = $item_title;

if($item_type == 1){
	$item_link = '<object id="video1" style="LEFT: 0px; TOP: 0px" height="60" width="320" VIEWASTEXT classid="clsid:CFCDAA03-8BE4-11CF-B84B-0020AFBBCCFA">
        <param name="src" value="'.$item_link.'">
        <param name="qtsrc" value="'.$item_link.'">
        <param name="autoplay" value="true">
        <param name="loop" value="true">
        <param name="controller" value="true">
       </object>';
}elseif($item_type == 2){

$realname	= basename($item_link);
$ext		= strrchr($realname,'.');
if(($ext == '.rmvb') or ($ext == '.rm') or ($ext == '.ra')){
$item_link = '<OBJECT id="rvocx" classid="clsid:CFCDAA03-8BE4-11cf-B84B-0020AFBBCCFA"
        width="550" height="350"><param name="src" value="'.$item_link.'">
        <param name="autostart" value="true"><param name="controls" value="imagewindow">
        <param name="console" value="video"><param name="loop" value="false">
        <EMBED src="'.$item_link.'" width="550" height="350" loop="false" type="audio/x-pn-realaudio-plugin" controls="imagewindow" console="video" autostart="true">
        </EMBED></OBJECT><OBJECT id="rvocx" classid="clsid:CFCDAA03-8BE4-11cf-B84B-0020AFBBCCFA" width="550" height="30">
          <param name="src" value="'.$item_link.'"><param name="autostart" value="true">
          <param name="controls" value="ControlPanel"><param name="console" value="video">
          <EMBED src="'.$item_link.'" width="550" height="30" controls="ControlPanel" type="audio/x-pn-realaudio-plugin" console="video" autostart="true">
          </EMBED></OBJECT>';
}else{
$item_link = '<object id="wmp" width=300 height=70 classid="CLSID:22d6f312-b0f6-11d0-94ab-0080c74c7e95" codebase="http://activex.microsoft.com/activex/controls/mplayer/en/nsmp2inf.cab#Version=6,0,0,0" standby="Loading Microsoft Windows Media Player components..." type="application/x-oleobject">
<param name="FileName" value="'.$item_link.'"><param name="ShowControls" value="1"><param name="ShowDisplay" value="0">
<param name="ShowStatusBar" value="1"><param name="AutoSize" value="1"><embed type="application/x-mplayer2" pluginspage="http://www.microsoft.com/windows95/downloads/contents/wurecommended/s_wufeatured/mediaplayer/default.asp" src="'.$item_link.'" name=MediaPlayer2 showcontrols=1 showdisplay=0 showstatusbar=1 autosize=1 visible=1 animationatstart=0 transparentatstart=1 loop=0 height=70 width=300></embed></object>';
}
}elseif($item_type == 3){
$item_link = "<EMBED src=\"$item_link\" width=550
height=350 type=application/x-shockwave-flash wmode=\"transparent\" quality=\"best\">";
}

if(!$member_gp == 2){
$add_comment_user='<input type="text" name="user_name" size="26" dir="rtl">';
}else{
$add_comment_user='<input type="text" name="user_name" value="'.$member_un.'" size="26" dir="rtl">';
}

if($member_id == $apt->Guestid){
	if($item_gcomm == 1){
		eval("\$media_add_comment = \" " . $apt->getmodtemplate ( 'media_add_comment', $modid,$mod_theme ) . "\";");
	}else{$media_add_comment = '';}
}else{
eval("\$media_add_comment = \" " . $apt->getmodtemplate ( 'media_add_comment', $modid,$mod_theme ) . "\";");
}

$media_comment = '';
$result = $apt->query("SELECT * FROM rafia_media_comment where comment_item=$itemid order by comment_id DESC");
while(@extract($apt->dbarray($result))){
$comment_text	= $apt->format_data_out($comment_text);
$comment_text     = $apt->rep_words ($comment_text);
eval("\$media_comment .= \" " . $apt->getmodtemplate ( 'media_comment', $modid,$mod_theme ) . "\";");
}

$apt->query("update rafia_media_items set item_show=item_show+1 where item_id=$itemid");

if($member_gp != 1){
$open_hide = "<!--";
$close_hide = " -->";
}

eval("\$media_middle .= \" " . $apt->getmodtemplate ( 'media_item', $modid,$mod_theme ) . "\";");
eval("\$index_middle .= \" " . $apt->getmodtemplate ( 'media_main', $modid,$mod_theme ) . "\";");

echo $index_middle;

?>