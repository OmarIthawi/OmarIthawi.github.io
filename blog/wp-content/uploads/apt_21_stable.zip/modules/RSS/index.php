<?php
/*
+===========================================+
|      ArabPortal V2.1.x Copyright � 2006   |
|   -------------------------------------   |
|            By Rafia AL-Otibi              |
|                    And                    |
|              Arab Portal Team             |
|   -------------------------------------   |
|      Web: http://www.ArabPortal.Net       |
|   -------------------------------------   |
|  Last Updated: 22/10/2006 Time: 10:00 PM  |
+===========================================+
*/
/***************************************************************************
			������ ��� ������� �� ���� ������� RSS + XML
			   ����� ����� ����� (���� ��� �������)
			www.arabiaone.org (arabgenius@hotmail.com)
	=========================== v2.0 ===========================
***************************************************************************/

if (RUN_MODULE !== true)
{
    die ("<center><h3>���� ��� ������� ��� ������</h3></center>");
}

$mod_theme = $mod->modInfo[themeid];
$mod_name = $mod->modInfo[mod_name];
$modid = $mod->modInfo[id];
$mod_title = $mod->modInfo[mod_title];

echo $apt->table_cat_module("<a href=mod.php?mod=$mod_name>&nbsp;$mod_title</a>");

$text = '';
$result = mysql_query ("SELECT * FROM rafia_rss order by feedorder ASC");
while ($row = mysql_fetch_array($result)) {
$id = $row['r_id']; 
$feedurl = $row['url']; 
$feedtime = $row['feedtime']; 
$sitename = $row['sitename']; 
$ltime = $row['ltime']; 
$feed = $row['feed']; 

$now = time();
$diff = $now - $ltime;

if($diff >= $feedtime){
include_once("modules/RSS/ConvertCharset.class.php");
$FromCharset = 'utf-8'; 
$ToCharset = 'windows-1256'; 
$convert  = new ConvertCharset();

$feed = $apt->get_contents($feedurl);
$feed = @explode("\n",$feed);
$apt->query("Update rafia_rss set feed='' where r_id='$id'");
	if(!$feed){
	$text = "	<img src=modules/RSS/images/zoom-headline.gif>&nbsp;&nbsp; �� ��� ������� ������� �� �� ���� ����� ����� <br>\n";
	$apt->query("Update rafia_rss set feed='$text' where r_id='$id'");
	}else{

					foreach($feed as $line)
					{
						if (strpos($line, '<title>') !== false)
						{
							$tmp_title = str_replace(array('<title>','</title>'), '', trim($line));
							$title = addslashes($tmp_title);
						}
						if (strpos($line, '<description>') !== false)
						{
							$tmp_description = str_replace(array('<description>','</description>'), '', trim($line));
							$description = addslashes($tmp_description);
						}
						if (strpos($line, '<url>') !== false || strpos($line, '<link>') !== false)
						{
							$url = str_replace(array('<url>', '</url>', '<link>', '</link>'), '', trim($line));
					$text .= "	<img src=modules/RSS/images/zoom-headline.gif>&nbsp;&nbsp;<a href=$url target=_blank>$title</a><br>\n";
						}
					}
	}
	$do = mysql_query("Update rafia_rss set ltime='$now' where r_id='$id';");
	$text = $convert->Convert($text, $FromCharset, $ToCharset); 
	$apt->query("Update rafia_rss set feed='$text' where r_id='$id'");
	}

eval("echo \" " . $apt->getmodtemplate ( 'header_view_feed', $modid,$mod_theme ) . "\";");
if($text != ''){echo $text;}else{echo $feed;}
unset($feed,$text);
eval("echo \" " . $apt->getmodtemplate ( 'footer_view_feed', $modid,$mod_theme ) . "\";");


}

?>