<?php
//////////////////////////////
//	����� ����� �������		//
//	DeaD SouL - DSQ8.com	//
//	17-01-2007 || 12.49 PM	//
//		XML WebLinks		//
//////////////////////////////

include('admin/conf.php');
$url = $CONF['site_url'];
$site = $CONF['site_title'];

$XML_limit = "10";	// ��� ������
	
function xmlentities($string){
 	return str_replace ( array ( '&', '"', "'", '<', '>', '\x92' ), array ( '&amp;' , '&quot;', '&apos;' , '&lt;' , '&gt;', '&apos;' ), $string );
}

header('Content-Type: text/xml');
echo '<?xml version="1.0" encoding="windows-1256"?>'. "\r\n";
echo '<rss version="0.91">'."\r\n";
echo "<channel>\r\n";
echo "\t<item>\r\n";
echo "\t\t<title>".xmlentities($site)."</title>\r\n";
echo "\t\t<link>$url</link>\r\n";
echo "\t\t<description>".xmlentities("������� ���� ������� �������")."</description>\r\n";
echo "\t</item>\r\n";

$result = mysql_query ("SELECT * FROM rafia_download
   	                             WHERE allow='yes'
       	                         ORDER BY id DESC limit $XML_limit");

while ($row = mysql_fetch_array($result))
{
	$id 		= $row['id']; 
	$title 	= xmlentities($row['title']); 
	$description 	= xmlentities($row['post_head']); 
	$thelink 	= xmlentities($url."download.php?action=view&id=$id");
	
	echo "\t<item>\r\n";
	echo "\t\t<title>$title</title>\r\n";
	echo "\t\t<link>$thelink</link>\r\n";
	echo "\t\t<description>$description</description>\r\n";
	echo "\t</item>\r\n";
}
echo "</channel>\r\n";
echo "</rss>";
exit();
?>