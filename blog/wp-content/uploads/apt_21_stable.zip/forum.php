<?php
/*
+===========================================+
|      ArabPortal V2.1.x Copyright � 2006   |
|   -------------------------------------   |
|            By Rafia AL-Otibi              |
|                    And                    |
|              Arab Portal Team             |
|   -------------------------------------   |
|      Web: http://www.ArabPortal.Net       |
|   -------------------------------------   |
|  Last Updated: 23/10/2006 Time: 10:00 PM  |
+===========================================+

    for($i=0;$i<sizeof($SetMain);$i++)
    {

        $id = $SetMain[$i][id];
        $SetMain[$i][dsc] = "SetMain";
        $FainalMain[$id] =$SetMain[$i];

        for($j=0;$j<sizeof($SetSub);$j++)
        {
            if($id==$SetSub[$j]['subcat'])
            {
               $sid = $SetSub[$j][id];
               $FainalMain[$sid] = $SetSub[$j];
            }
		}
	}
 */
require_once('global.php');

checkgroup('view_site');
checkgroup('view_forum');
$cat_img = "topic.gif";
//---------------------------------------------------
//
//---------------------------------------------------



function __countCat()
{
     global $apt;
    $result = $apt->query("SELECT subcat,id,countopic,countcomm FROM rafia_cat
                            WHERE  catType=2 ");

    if($apt->dbnumrows($result)>0)
    {
        $row = $apt->dbarray($result);
         while($row=$apt->dbarray($result))
         {
             $count[$row[subcat]][countopic] = $row[countopic];
             $count[$row[subcat]][countcomm] = $row[countcomm];
         }
    }
    return $count;
}
//---------------------------------------------------
//
//---------------------------------------------------


function SubRows($mineID)
{
   //global $apt,$themepath,$modName;
   @extract($GLOBALS);
   if(empty($mineID))
   return ;
   
    $result = $apt->query("SELECT rafia_cat.*,rafia_users.userid,rafia_users.username,
                           rafia_forum.title as ftitle,rafia_forum.timestamp
                           FROM rafia_cat LEFT JOIN rafia_forum
                           ON rafia_forum.id=rafia_cat.lastpostid
                           LEFT JOIN rafia_users
                           ON rafia_users.userid = rafia_forum.lastuserid
                           WHERE rafia_cat.catType='2' and rafia_cat.subcat in ($mineID)
                           ORDER BY ordercat ASC");


    if($apt->dbnumrows($result)>0)
    {
        while($Sub_Row = $apt->dbarray($result))
        {
            $SubRows[] = $Sub_Row;
        }
     }
return $SubRows;
}
//---------------------------------------------------
//
//---------------------------------------------------


function sub_cat($SetSub,$ids)
{
     @extract($GLOBALS);

        for($j=0;$j<sizeof($SetSub);$j++)
        {
            if($ids==$SetSub[$j]['subcat'])
            {
               @extract($SetSub[$j]);


            $numrows       = $countopic + $apt->countCat_new($id,'countopic',$subcat);
            $numcomment    = $countcomm + $apt->countCat_new($id,'countcomm',$subcat);

            $lastposter    = $username;
            $lastposterid  = $userid;
            $lasttitle     = $ftitle;
            $lastpostd     = $timestamp;
            $title         = $apt->format_data_out($title);
            $dsc           = $apt->format_data_out($dsc);
            $moderatename  = $apt->implode_multi(" , ",$modName[$id]);

             $SubRows_countcomm  = $numcomment+$SubRows_countcomm;
             $SubRows_countopic =  $numrows+$SubRows_countopic;
             
            if($catClose == 0)
            {
                if(($lastpostd > $apt->cookie['lastvisit'])||($lastpostd > $apt->cookie['lastlogin']))
                {
                    $cat_icon =  "on.gif";
                }
                else
                {
                    $cat_icon = "off.gif";
                }
            }
            else
            $cat_icon = "lock.gif";

            $lastpostd     =   $apt->Hijri($lastpostd)." ".$apt->gettime($lastpostd);

            eval("\$forum_cat .= \" " . $apt->gettemplate ( 'forum_cat' ) . "\";");
          }
      }
     return array($forum_cat,$SubRows_countopic,$SubRows_countcomm);
}

//---------------------------------------------------
//
//---------------------------------------------------


if (( $apt->cookie['cgroup'] == $apt->a_g) && ($apt->cookie['cadmin'] == "1"))
{
    if (( $apt->cookie['cgroup'] == $apt->a_g) || ( $apt->cookie['cgroup'] == $apt->m_g))
    {
        $isadmin = " | <a href=forum.php?action=admin>���� �����</b></font></a>";
    }else{ $isadmin = "";}
    eval("\$users_tools =\" " . $apt->gettemplate ( 'users_tools' ) . "\";");
}
else
{
  eval("\$users_tools =\" " . $apt->gettemplate ( 'users_Login' ) . "\";");
}

//---------------------------------------------------
$last_topics = '';
//---------------------------------------------------

    
if ($apt->get['action']=="")
{

if($apt->getsettings('use_adsin_forum') == 'yes')
{
    $ads_head = $apt->ads_view_in('h');
    $ads_foot = $apt->ads_view_in('f');
}

	
    $apt->head(LANG_TITLE_FORUMS);
    $countCat_array = __countCat();
    
    $forum_middle = $apt->table_cat_module(LANG_TITLE_FORUMS);
    $modName   = $apt->moderatename();
    $result    = $apt->query("SELECT * FROM rafia_cat WHERE catType='2' and subcat='0' and ismine ='1' ORDER BY ordercat ASC");

    while($row = $apt->dbarray($result))
    {
        $SetMain[] =$row;
        $mineID  .= $row[0].",";
    }
    
    $mineID  = substr ($mineID,0,strlen($mineID)-1);
    $SubRows = SubRows($mineID);

    for($i=0;$i<sizeof($SetMain);$i++)
    {
         @extract($SetMain[$i]);
         
         $title         = $apt->format_data_out($title);
         $dsc           = $apt->format_data_out($dsc);
         $_cat          =  sub_cat($SubRows,$id);
         $forum_cat     =  $_cat[0];
         $numrows       =  $_cat[1];
         $numcomment    =  $_cat[2];
          echo $SubRows_countopic;
          
         eval("\$forum_cat_table .= \" " . $apt->gettemplate ( 'forum_cat_table' ) . "\";");
         unset($forum_cat);
    }
    ob_start();
//================== ��� �������� ��� ��� ����� ===================
//===================== ������ ����� ����� =======================
   if((!$apt->cookie['clogin'] == "rafiaphp") or ($apt->cookie['cid'] == $apt->Guestid)){
   $last_topics = '';
   }else{
   $u_lastlogin	=  $apt->cookie['lastlogin'];
   $count_topic	=  $apt->dbnumquery("rafia_forum","allow='yes' and timestamp <= $u_lastlogin");
   $last_topics		=  "<span class=small><a href='forum.php?action=lasttopics'>��� ��������� ��� ��� ����� [$count_topic]</a></span>";
   }
//================================================================

    eval("\$forum_middle .= \" " . $apt->gettemplate ( 'forum_main_table' ) . "\";");
    ob_end_flush();

    ///////////////////// Online ////////////////////
        $result  = $apt->query("SELECT DISTINCT onlineip FROM rafia_online WHERE user_online ='Guest'");
        $resuser = $apt->query("SELECT DISTINCT onlineip FROM rafia_online WHERE user_online !='Guest'");

        $not_user    = $apt->dbnumrows($result);
        $user_online = $apt->dbnumrows($resuser);

        $resMAX = $apt->query("SELECT id FROM rafia_online ORDER BY id DESC LIMIT 1");
        $rowc   = $apt->dbarray($resMAX);

        $count_file = $rowc['id'];

        if (($not_user > 0)||($user_online != 'Guest'))
        {
            $online = $not_user + $user_online;
        }
        
        $getOnline = array();
        $result = $apt->query("SELECT DISTINCT onlineip,onlinepage,user_online,useronlineid FROM rafia_online  WHERE user_online !='Guest' ORDER BY id DESC");

        while($row = $apt->dbarray($result))
        {
            $user__online    = $row[user_online];
            $user__onlineid  = $row[useronlineid];

            if($user__onlineid !="0")
            {
                $getOnline[] = "<a href=members.php?action=info&userid=$user__onlineid>$user__online</a>" ;
            }
        }
    $users_online = $apt->implode_multi(" , ",$getOnline);
//****************************************************
//**********  ������� ����� ������� �����  ************
//**********     ������ ����� �����  *****************
//****************************************************
	$today = strtotime("h:i,NOW"*3600);
	$users_today = '';
	$guestid = $CONF['Guest_id'];
		$todayq = $apt->query("SELECT `userid`,`username`,`lastlogin` FROM `rafia_users` WHERE lastlogin >= '$today' and userid != '$guestid'");
	$online_today    = $apt->dbnumrows($todayq);
	while($row = $apt->dbarray($todayq)){
	@extract($row);
	$utime = date('h:i a, d-m-Y',$lastlogin);
	$utime = str_replace("pm","����",$utime);
	$utime = str_replace("am","�����",$utime);
		$users_today .= "<a title='��� ������ $utime' href='members.php?action=info&userid=$userid'>$username</a> ,";
	unset($utime);
	}
//**********************************************
    eval("\$forum_middle .= \" " . $apt->gettemplate ( 'forum_main_bottom' ) . "\";");
    eval("echo \" " . $apt->gettemplate ( 'forum_main' ) . "\";");
}
else if ($apt->get['action']=="lasttopics")
{
    ob_start();
    checkcookie();

    $perpagelist       = $apt->getsettings("forumperpagelist");
    $perpage_comment   = $apt->getsettings("forumperpagecomment");
    $apt->head('��� ���������');

   $u_lastlogin	=  $apt->cookie['lastlogin'];
   $count_topic	=  $apt->dbnumquery("rafia_forum","timestamp <= $u_lastlogin");

    $result = $apt->query("SELECT * FROM rafia_forum
                                           WHERE allow='yes'
                                           AND timestamp <= '$u_lastlogin'
                                           ORDER BY timestamp DESC
                                           LIMIT $start,$perpagelist");

       while($row = $apt->dbarray($result))
       {
           @extract($row);
           if($close == 1)
           {
               $imgonoff   = "postlock.gif";
           }
           elseif ($c_comment > 10)
           {
               $imgonoff   = "posthot.gif";
           }
           else
           {
               if(($timestamp > $apt->cookie['lastvisit'])||($timestamp > $apt->cookie['lastlogin']))
           {
               $imgonoff   = "postnew.gif";
               $apt->settimecookie();
           }
           else
           {
               $imgonoff = "posticon.gif";
           }
           if(( $apt->cookie['lastvisit'] == $apt->cookie['lastlogin'])&&($timestamp > time()-(3600)))
           {
               $imgonoff   = "postnew.gif";
               $apt->settimecookie();
           }
           if($timestamp > $apt->cookie['lastlogin']-(120))
           {
               $imgonoff   = "postnew.gif";
               $apt->settimecookie();
           }
       }
   $numrows        =  $apt->dbnumquery("rafia_comment","thread_id = $id");
   $apt->numrows   =  $numrows ;
   $pagenum        =  $apt->pagenumlist($perpage_comment,$id);
   $date           =  $apt->Hijri($date_time)." ".$apt->gettime($date_time);
   $title          =  $apt->title_cut($apt->format_data_out($title),$apt->getsettings("max_title_cut"));
   $user           =  $apt->dbfetch("SELECT username FROM rafia_users WHERE userid='".$lastuserid."'");
   $lastposter     =  $user['username'];
   $lastdate       =  $apt->Hijri($timestamp)." ".$apt->gettime($timestamp);

   if( $iconid > 1 )
   {
       $rep_icon =  $apt->rep_icon($iconid);
   }
   else
   {
       unset($rep_icon);
   }

   // $apt->orderc();
  // $apt->color($color);

        eval("\$forum_topic_list .= \" " . $apt->gettemplate ( 'forum_topic_list' ) . "\";");


    }
           eval("\$forum_middle .= \"<br><br> " . $apt->gettemplate ( 'forum_list_middle' ) . "\";");

         eval("\$forum_middle .= \" " . $apt->gettemplate ( 'forum_cat_tools' ) . "\";");

        $apt->numrows =   $apt->dbnumquery("rafia_forum","allow='yes' and userid='$userid'");
        $pagenum = $apt->pagenum($perpagelist,"byuser&userid=$userid");

        if($pagenum)
        {
            eval("\$forum_middle .= \" " . $apt->gettemplate ( 'forum_list_pagenum' ) . "\";");
        }
        eval("\$forum_middle .= \" " . $apt->gettemplate ( 'forum_list_bottom' ) . "\";");

    eval("echo \" " . $apt->gettemplate ( 'forum_main' ) . "\";");

ob_end_flush();
}
else if ($apt->get['action']=="byuser")
{
    ob_start();
    
    checkcookie();
    
    $userid = $apt->setid('userid');
    $perpagelist       = $apt->getsettings("forumperpagelist");
    $perpage_comment   = $apt->getsettings("forumperpagecomment");
    $apt->head($title);
    $result = $apt->query("SELECT * FROM rafia_forum
                                           WHERE allow='yes'
                                           AND userid=$userid
                                           ORDER BY timestamp DESC
                                           LIMIT $start,$perpagelist");

       while($row = $apt->dbarray($result))
       {
           @extract($row);
           if($close == 1)
           {
               $imgonoff   = "postlock.gif";
           }
           elseif ($c_comment > 10)
           {
               $imgonoff   = "posthot.gif";
           }
           else
           {
               if(($timestamp > $apt->cookie['lastvisit'])||($timestamp > $apt->cookie['lastlogin']))
           {
               $imgonoff   = "postnew.gif";
               $apt->settimecookie();
           }
           else
           {
               $imgonoff = "posticon.gif";
           }
           if(( $apt->cookie['lastvisit'] == $apt->cookie['lastlogin'])&&($timestamp > time()-(3600)))
           {
               $imgonoff   = "postnew.gif";
               $apt->settimecookie();
           }
           if($timestamp > $apt->cookie['lastlogin']-(120))
           {
               $imgonoff   = "postnew.gif";
               $apt->settimecookie();
           }
       }
   $numrows        =  $apt->dbnumquery("rafia_comment","thread_id = $id");
   $apt->numrows   =  $numrows ;
   $pagenum        =  $apt->pagenumlist($perpage_comment,$id);
   $date           =  $apt->Hijri($date_time)." ".$apt->gettime($date_time);
   $title          =  $apt->title_cut($apt->format_data_out($title),$apt->getsettings("max_title_cut"));
   $user           =  $apt->dbfetch("SELECT username FROM rafia_users WHERE userid='".$lastuserid."'");
   $lastposter     =  $user['username'];
   $lastdate       =  $apt->Hijri($timestamp)." ".$apt->gettime($timestamp);

   if( $iconid > 1 )
   {
       $rep_icon =  $apt->rep_icon($iconid);
   }
   else
   {
       unset($rep_icon);
   }

   // $apt->orderc();
  // $apt->color($color);

        eval("\$forum_topic_list .= \" " . $apt->gettemplate ( 'forum_topic_list' ) . "\";");


    }
           eval("\$forum_middle .= \"<br><br> " . $apt->gettemplate ( 'forum_list_middle' ) . "\";");

         eval("\$forum_middle .= \" " . $apt->gettemplate ( 'forum_cat_tools' ) . "\";");

        $apt->numrows =   $apt->dbnumquery("rafia_forum","allow='yes' and userid='$userid'");
        $pagenum = $apt->pagenum($perpagelist,"byuser&userid=$userid");

        if($pagenum)
        {
            eval("\$forum_middle .= \" " . $apt->gettemplate ( 'forum_list_pagenum' ) . "\";");
        }
        eval("\$forum_middle .= \" " . $apt->gettemplate ( 'forum_list_bottom' ) . "\";");

    eval("echo \" " . $apt->gettemplate ( 'forum_main' ) . "\";");

ob_end_flush();

}
//---------------------------------------------------
//
//---------------------------------------------------
else if ($apt->get['action']=="view")
{
    $id = $apt->setid('id');
    
    if (( $apt->cookie['cgroup'] == $apt->a_g) || ( $apt->cookie['cgroup'] == $apt->m_g))
    {
        $row = $apt->dbfetch("SELECT rafia_forum.*,rafia_users.userid,rafia_users.username,
                                 rafia_users.datetime,rafia_users.allposts,rafia_users.signature,
                                 rafia_users.homepage,rafia_users.usergroup,rafia_users.avatar FROM rafia_forum,rafia_users
                                 WHERE id='$id'AND rafia_forum.userid = rafia_users.userid LIMIT 1");
    }
    else
    {

        $row = $apt->dbfetch("SELECT rafia_forum.*,rafia_users.userid,rafia_users.username,
                                 rafia_users.datetime,rafia_users.allposts,rafia_users.signature,
                                 rafia_users.homepage,rafia_users.usergroup,rafia_users.avatar FROM rafia_forum,rafia_users
                                 WHERE allow='yes' AND id='$id'AND rafia_forum.userid = rafia_users.userid LIMIT 1");
    }

    @extract($row);

    if(!$apt->catgroup('groupview'))
    {
        $apt->head(LANG_TITLE_LOG_IN);
        eval("print \"" . $apt->gettemplate ( 'Login_main' ) . "\";");
        $apt->foot($pageft);
        exit;
   }

   $apt->query("UPDATE rafia_forum SET reader = reader+1 WHERE id = '$id'");

    $apt->usereaderp("thread_id",$id);
    
    $postid = $id;
     
    $apt->head($apt->format_data_out($title));


    $forum_middle .= $apt->table_cat_link(LANG_TITLE_FORUMS,$cat_id,$title);
    $forum_middle .= $apt->next_old_post("SELECT id FROM rafia_forum WHERE allow='yes' and cat_id='$cat_id' and timestamp < '$timestamp'  ORDER BY timestamp DESC LIMIT 1");
    $forum_middle .= $apt->next_new_post("SELECT id FROM rafia_forum WHERE allow='yes' and cat_id='$cat_id' and timestamp > '$timestamp'  ORDER BY timestamp LIMIT 1");


   if($close == '0')
   {
       $isclose     = "close&cat_id=$cat_id&forumid";
       $replay_img  = "replay.gif";
   }
   else
   {
       $isclose     = "open&cat_id=$cat_id&forumid";
       $replay_img  = "close.gif";
   }


   if ( $apt->checkcadmincat($cat_id) )
   {
        if($sticky == '0')
        {
            $issticky = "sticky&cat_id=$cat_id&forumid";
        }
        else
        {
            $issticky = "unsticky&cat_id=$cat_id&forumid";
        }


   $adminJump .= $apt->adminJump("edit&id","comment&cat_id=$cat_id&id",$issticky,$isclose);
   }
   
     $add_cat_id = $cat_id;

    if ($start == 0)
    {
   $able_addnew = $apt->retCheckGroup('add_forum_post');
   $able_addreply = $apt->retCheckGroup('add_forum_c');

   if($able_addnew==1)  $add_new_post = "<a href=\"$PHP_SELF?action=add&cat_id=$cat_id\"><img border='0' src='themes/$themepath/$cat_img' width='98' height='24'></a>";
   if($able_addreply==1) $add_new_reply = "<a href=\"$PHP_SELF?action=addcomment&id=$postid\"><img border='0' src='themes/$themepath/$replay_img'  width='88' height='24'></a>";

         eval("\$forum_middle .= \" " . $apt->gettemplate ( 'post_tools' ) . "\";");
        if($userid == 0 )
        {
             $usertitle    =  $username;
             $username     =  $apt->format_data_out($name);
             $datetime     =  $apt->Hijri($date_time);
             $allposts     =  1;
        }
        else
        {
            $usertitles    =  explode("-", $apt->userRating($allposts));
		if( ($usergroup == $apt->a_g) || ($usergroup == $apt->m_g)){
            $usertitle     =  $apt->usergroup($usergroup);
		}else{
            $usertitle     =  $usertitles[1];
		}
            $userimgtitle  =  $usertitles[0];
            $username      =  $apt->format_data_out($username);
            $homepage      =  $apt->addToURL ($homepage);
            $datetime      =  $apt->Hijri($datetime);
		ob_start();
            if($avatar == 0){
			    $avatar_pic = '';
            }else{
		    $avatarfile = $apt->upload_path."/".$userid.".".'avatar';
		    if(file_exists($avatarfile)){
		       $avatar_pic = "<img src=members.php?action=image&userid=".$userid."><br>";
		    }else{
		       $avatar_pic = '';
		    }
             }
		ob_end_flush();

            if($usesig == 1)
            {
                $signature =  $apt->signature_code ($signature);
            }else{
                unset($signature);
            }
        }

        $title         =  $apt->format_data_out($title);
        //$post          =  $apt->phpcode($post);
        $post          =  $apt->rep_words($post);
        $post          =  $apt->rafia_code($post);
        if(isset($apt->get[highlight]))
        {
            $post          = $apt->highlight_words($post);
        }
        $date          =  $apt->Hijri($date_time)." ".$apt->gettime($date_time);
        $c_comment     =  $apt->dbnumquery("rafia_comment","thread_id = $id");

        if($iconid)
        {
            $rep_icon =  $apt->rep_icon($iconid);
        }
        
        if ($apt->retcheckgroup('download_forum_file'))
        {
            $upload_file    =  $apt->getuploadfile($uploadfile);
        }
        elseif ($uploadfile)
        {
            $upload_file    =  "<p><font color=\"#FF0000\" face=\"Windows UI\">".LANG_MSG_NOT_VIEW_ATTACHMENTS."</font></p>";
        }

        eval("\$forum_middle .= \" " . $apt->gettemplate ( 'forum_table' ) . "\";");
    }
   

   
   $add_cat_id = $cat_id;
   
   if($c_comment > 0)
   {
       $perpage_comment   = $apt->getsettings("forumperpagecomment");

       $result = $apt->query ("SELECT rafia_comment.* ,rafia_users.userid,rafia_users.username,
                                 rafia_users.datetime,rafia_users.allposts,rafia_users.signature,
                                 rafia_users.homepage,rafia_users.usergroup,rafia_users.avatar
                                 FROM rafia_comment,rafia_users
                                 WHERE thread_id='$id' and allow='yes'
                                 AND rafia_comment.userid = rafia_users.userid
                                 ORDER BY id ASC
                                 LIMIT $start,$perpage_comment");
                                   
                                   
       $apt->numrows =   $apt->dbnumquery("rafia_comment","thread_id='$id'");
       $pagenum = $apt->pagenum ($perpage_comment,"view&id=$id");

        while($row = $apt->dbarray($result))
       {
            @extract($row);
            if($userid == 0 )
             {
                 $usertitle    =  $username;
                 $username     =  $apt->format_data_out($name);
                 $datetime     =  $apt->Hijri($date_time);
                 $allposts     =  1;
             }
             else
             {
                 $usertitles    =  explode("-", $apt->userRating($allposts));
		if( ($usergroup == $apt->a_g) || ($usergroup == $apt->m_g)){
            $usertitle     =  $apt->usergroup($usergroup);
		}else{
            $usertitle     =  $usertitles[1];
		}
                 $userimgtitle  =  $usertitles[0];
                 $username      =  $apt->format_data_out($username);
                 $homepage      =  $apt->addToURL ($homepage);
                 $datetime      =  $apt->Hijri($datetime);
                 ob_start();
                 if($avatar == 0){
			    $avatar_pic = '';
                 }else{
			    $avatarfile = $apt->upload_path."/".$userid.".".'avatar';
			    if(file_exists($avatarfile)){
			             $avatar_pic = "<img src=members.php?action=image&userid=".$userid."><br>";
			    }else{
			       $avatar_pic = '';
			    }
                 }
                 ob_end_flush();
                 if($usesig == 1)
                 {
                     $signature =  $apt->signature_code($signature);
                 }else{
                     unset($signature);
                 }
             }
             
             $title         =  $apt->format_data_out($title);
             $comment       =  $apt->rep_words($comment);
             $comment       =  $apt->rafia_code($comment);
             $date          =  $apt->Hijri($timestamp)." ".$apt->gettime($timestamp);

             if ($apt->retcheckgroup('download_forum_file'))
             {
                 $upload_file    =  $apt->getuploadfile($uploadfile);
             }
             else if ($uploadfile > 0)
             {
                 $upload_file    =  "<p><font color=\"#FF0000\" face=\"Windows UI\">".LANG_MSG_NOT_VIEW_ATTACHMENTS."</font></p>";
             }
             $apt->color($color);
           eval("\$forum_middle .= \" " . $apt->gettemplate ( 'forum_comment_table' ) . "\";");
           unset($upload_file);
       }
   $able_addnew = $apt->retCheckGroup('add_forum_post');
   $able_addreply = $apt->retCheckGroup('add_forum_c');

   if($able_addnew==1)  $add_new_post = "<a href=\"$PHP_SELF?action=add&cat_id=$cat_id\"><img border='0' src='themes/$themepath/$cat_img' width='98' height='24'></a>";
   if($able_addreply==1) $add_new_reply = "<a href=\"$PHP_SELF?action=addcomment&id=$postid\"><img border='0' src='themes/$themepath/$replay_img'  width='88' height='24'></a>";

         eval("\$forum_middle .= \" " . $apt->gettemplate ( 'post_tools' ) . "\";");
   }
   else
   {
   $able_addnew = $apt->retCheckGroup('add_forum_post');
   $able_addreply = $apt->retCheckGroup('add_forum_c');

   if($able_addnew==1)  $add_new_post = "<a href=\"$PHP_SELF?action=add&cat_id=$cat_id\"><img border='0' src='themes/$themepath/$cat_img' width='98' height='24'></a>";
   if($able_addreply==1) $add_new_reply = "<a href=\"$PHP_SELF?action=addcomment&id=$postid\"><img border='0' src='themes/$themepath/$replay_img'  width='88' height='24'></a>";

        eval("\$forum_middle .= \" " . $apt->gettemplate ( 'post_tools' ) . "\";");
   }
       $forum_middle .= $apt->listJumpf("$PHP_SELF?action=list&cat_id=","2");


       if(($apt->retcheckgroup('add_forum_c'))&& ($close == '0'))
       {
           $fo = new form;
         $captcha = rand(1000,9999);
         $fo->cap = $captcha;
         $_SESSION['memccode']= $captcha;

           $forum_middle .= $fo->fastreplay($postid);
       }

 eval("echo \" " . $apt->gettemplate ( 'forum_main' ) . "\";");

}
else if ($apt->get['action'] == 'code')
{
    if ($apt->retcheckgroup('download_forum_file'))
    {
        $apt->showsource();
    }else{
             $apt->errmsg (LANG_MSG_NOT_VIEW_ATTACHMENTS);
    }
    
    exit;
}
else if ($apt->get['action'] == 'image')
{
     $id = $apt->setid('id');
    if ($apt->retcheckgroup('download_forum_file'))
    {
        $result = $apt->query("SELECT * FROM rafia_upload WHERE upid='$id'");
        
     if($apt->dbnumrows($result)>0)
     {
          $rowfile = $apt->dbarray($result);

          @extract($rowfile);
          $pathfile = $apt->upload_path."/".$uppostid.".".$upcat;
          header ("Content-type: $uptypes");
            $open = @fopen($pathfile,r);
            $data = @fread($open,@filesize($pathfile));
            @fclose($open);
            print($data);
          $apt->query("UPDATE rafia_upload SET upclicks = upclicks+1 WHERE upid = '$id'");
     }
     }else{
           $apt->errmsg (LANG_MSG_NOT_VIEW_ATTACHMENTS);
    }
     exit;

}
else if ($apt->get['action'] == 'down')
{
     $id = $apt->setid('id');
     
    if ($apt->retcheckgroup('download_forum_file'))
    {
        $result = $apt->query("SELECT * FROM rafia_upload
                                      WHERE upid='$id'");
     if($apt->dbnumrows($result)>0)
     {
          $rowfile = $apt->dbarray($result);

          @extract($rowfile);
          
          $pathfile = $apt->upload_path."/".$uppostid.".".$upcat;
          
          $download = new downloadfile($pathfile,$upname,$upsize);

          if(!$download->download())
          {
              $apt->errmsg(LANG_ERROR_URL);
          }
          else
          {
               $apt->query("UPDATE rafia_upload SET upclicks = upclicks+1 WHERE upid = '$id'");
          }

          
    }
    }else{
          $apt->errmsg (LANG_MSG_NOT_VIEW_ATTACHMENTS);
    }

}
//---------------------------------------------------
//
//---------------------------------------------------
else if ($apt->get['action']=="list")
{
    ob_start();
    $countCat_array = __countCat();
    $cat_id = $apt->setid('cat_id');
    $result = $apt->query("SELECT * FROM rafia_cat WHERE id='$cat_id' ORDER BY id DESC");

    if ($apt->dbnumrows($result) == 0)
    {
        $apt->errmsg(LANG_ERROR_URL);

    }
    //=============
    $row    =  $apt->dbarray($result);
    @extract($row);
    $apt->head($title);

    if(( $groupview!=0 ) && (!in_array ( $apt->cookie['cgroup'], explode(",", $groupview) )))
    {
        eval("print \"" . $apt->gettemplate ( 'Login_main' ) . "\";");
        $apt->foot($pageft);
        exit;
    }

    //==============

    $forum_middle  = $apt->table_cat_link(LANG_TITLE_FORUMS) ;

    if($ismine == '1')
    {
        $result = $apt->query("SELECT * FROM rafia_cat WHERE catType='2' and subcat='0' and ismine ='1' and id='$id'");
        if($apt->dbnumrows($result) > 0)
        {
            $modName   = $apt->moderatename();
            $row = $apt->dbarray($result);
            @extract($row);
            $title         =  $apt->format_data_out($title);
            $dsc           =  $apt->format_data_out($dsc);
            $_cat          =  sub_cat(SubRows($id),$id);
            $forum_cat     =  $_cat[0];
            $numrows       =  $_cat[1];
            $numcomment    =  $_cat[2];

            eval("\$forum_cat_table .= \" " . $apt->gettemplate ( 'forum_cat_table' ) . "\";");

            unset($forum_cat);

            eval("\$forum_middle .= \" " . $apt->gettemplate ( 'forum_main_table' ) . "\";");

            eval("echo \" " . $apt->gettemplate ( 'forum_main' ) . "\";");
         }
         $apt->foot($pageft);
      exit;
   //==================
     }
    
    $title         =  $apt->format_data_out($title);
    $dscin         =  $apt->format_data_out($dscin);
        


    ////////////subcat////////

   $result = $apt->query("SELECT rafia_cat.*,rafia_users.username as lastposter,
                          rafia_users.userid as lastposterid,
                          rafia_forum.title as lasttitle ,rafia_forum.timestamp as lastpostd
                          FROM rafia_cat
                          LEFT JOIN rafia_forum on rafia_forum.id=rafia_cat.lastpostid
                          LEFT JOIN rafia_users on rafia_users.userid = rafia_forum.lastuserid
                          WHERE rafia_cat.catType='2' and rafia_cat.subcat ='$cat_id' ORDER BY rafia_cat.ordercat ASC");

    if($apt->dbnumrows($result)>0)
    {
        $modName   = $apt->moderatename();
        
        while($row = $apt->dbarray($result))
        {
            @extract($row);

             $numrows       = $countopic + $apt->countCat_new($id,'countopic');
             $numcomment    = $countcomm + $apt->countCat_new($id,'countcomm');

             $lastposter    = $apt->format_data_out($lastposter);
             $lasttitle     = $apt->format_data_out($lasttitle);
             $title         = $apt->format_data_out($title);
             $dsc           = $apt->format_data_out($dsc);
             $moderatename  = $apt->implode_multi(" , ",$modName[$id]);

             
             if(($lastpostd > $apt->cookie['lastvisit'])||($lastpostd > $apt->cookie['lastlogin']))
             {
                $cat_icon =  "on.gif";
            }
            else
            {
                $cat_icon = "off.gif";
             }
             $lastpostd     =   $apt->Hijri($lastpostd)." ".$apt->gettime($lastpostd);

            eval("\$forum_cat_table .= \" " . $apt->gettemplate ( 'forum_cat' ) . "\";");

        }

           eval("\$forum_middle .= \" " . $apt->gettemplate ( 'forum_main_table' ) . "\";");
    }

   ////////////////////
   $perpagelist       = $apt->getsettings("forumperpagelist");
   $perpage_comment   = $apt->getsettings("forumperpagecomment");

    $Jump = $apt->listJumpf("$PHP_SELF?action=list&cat_id=","2");
    
     eval("\$forum_middle .= \" " . $apt->gettemplate ( 'forum_list_top' ) . "\";");

    if(isset($apt->get[orderby]))
    {
      $isOrder = "&orderby=".$apt->get[orderby]."&dir=".$apt->get[dir];
    }

    if ($apt->get[orderby] =='date')
    {
        $down_by = "timestamp";
    }
    elseif($apt->get[orderby] =='comment')
    {
        $down_by = "c_comment";
    }
    elseif($apt->get[orderby] =='reader')
    {
        $down_by = "reader";
    }
    else
    {
        $down_by = $apt->getsettings('forum_order_by');
    }
    
    
    if ((empty($apt->get[dir])) || ($apt->get[dir] == 'd'))
    {
        $down_dir = DESC;
    }
    else
    {
         $down_dir = ASC;
    }
    
   // $apt->get[dir]
  // if (empty($apt->get[orderby]))

   if ($start==0)
    {
        $result = $apt->query ("SELECT rafia_forum.*,COUNT(rafia_comment.thread_id) as numrows
                               FROM rafia_forum LEFT JOIN rafia_comment
                               ON rafia_comment.thread_id=rafia_forum.id
                               WHERE rafia_forum.cat_id='$cat_id'
                               AND rafia_forum.allow='yes'
                               AND rafia_forum.sticky='1'
                               GROUP BY rafia_forum.id
                               ORDER BY $down_by $down_dir");
                               

                                           
      if($apt->dbnumrows($result)>0)
      {
          while($row = $apt->dbarray($result))
          {
              @extract($row);
              $imgonoff     = "Sticky.gif";
              //$numrows      =  $apt->dbnumquery("rafia_comment","thread_id = $id");
              $apt->numrows = $numrows;
              $pagenum    =  $apt->pagenumlist($perpage_comment,$id);
              $date       =  $apt->Hijri($date_time)." ".$apt->gettime($date_time);
              $title      =  $apt->title_cut(LANG_MSG_STACKED." : ". $apt->format_data_out($title),100);
              $user       =  $apt->dbfetch("SELECT username FROM rafia_users WHERE userid='".$lastuserid."'");
              $lastposter =  $user['username'];
              $lastdate   =  $apt->Hijri($timestamp)." ".$apt->gettime($timestamp);
             if($iconid)
             {
                 $rep_icon =  $apt->rep_icon($iconid);
             }
             $apt->color($color);
            eval("\$forum_topic_list .= \" " . $apt->gettemplate ( 'forum_topic_list' ) . "\";");
        }
      }
    }
    $result = $apt->query("SELECT rafia_forum.*,COUNT(rafia_comment.thread_id) as numrows
                           FROM rafia_forum LEFT JOIN rafia_comment
                           ON rafia_comment.thread_id=rafia_forum.id
                           WHERE rafia_forum.allow='yes'
                           AND rafia_forum.cat_id=$cat_id
                           AND rafia_forum.sticky!='1'
                           GROUP BY rafia_forum.id
                           ORDER BY $down_by $down_dir
                           LIMIT $start,$perpagelist");

       while($row = $apt->dbarray($result))
       {
           @extract($row);

           if($close == 1)
           {
               $imgonoff   = "postlock.gif";
           }
           elseif ($c_comment > 10)
           {
               $imgonoff   = "posthot.gif";
           }
           else
           {
               if(($timestamp > $apt->cookie['lastvisit'])||($timestamp > $apt->cookie['lastlogin']))
               {
                   $imgonoff   = "postnew.gif";
                   $apt->settimecookie();
               }
               else
               {
                   $imgonoff = "posticon.gif";
               }
               if(( $apt->cookie['lastvisit'] == $apt->cookie['lastlogin'])&&($timestamp > time()-(3600)))
               {
                   $imgonoff   = "postnew.gif";
                   $apt->settimecookie();
               }
               if($timestamp > $apt->cookie['lastlogin']-(120))
               {
                   $imgonoff   = "postnew.gif";
                   $apt->settimecookie();
               }
           }
           $apt->numrows =  $numrows ;
           $pagenum        =  $apt->pagenumlist($perpage_comment,$id);
           $date           =  $apt->Hijri($date_time)." ".$apt->gettime($date_time);
           $title          =  $apt->title_cut($apt->format_data_out($title),$apt->getsettings("max_title_cut"));
           $user           =  $apt->dbfetch("SELECT username FROM rafia_users WHERE userid='".$lastuserid."'");
           $lastposter     =  $user['username'];
           $lastdate       =  $apt->Hijri($timestamp)." ".$apt->gettime($timestamp);

           if( $iconid > 1 )
           {
               $rep_icon =  $apt->rep_icon($iconid);
           }
           else
           {
               unset($rep_icon);
           }
   
             $apt->color($color);

            eval("\$forum_topic_list .= \" " . $apt->gettemplate ( 'forum_topic_list' ) . "\";");
      }

      eval("\$forum_middle .= \" " . $apt->gettemplate ( 'forum_list_middle' ) . "\";");

      eval("\$forum_middle .= \" " . $apt->gettemplate ( 'forum_cat_tools' ) . "\";");

      $apt->numrows =   $apt->dbnumquery("rafia_forum","allow='yes' and cat_id='$cat_id'");

      $pagenum = $apt->pagenum($perpagelist,"list&cat_id=$cat_id".$isOrder);

        if($pagenum)
        {
            eval("\$forum_middle .= \" " . $apt->gettemplate ( 'forum_list_pagenum' ) . "\";");
        }
        eval("\$forum_middle .= \" " . $apt->gettemplate ( 'forum_list_bottom' ) . "\";");

    eval("echo \" " . $apt->gettemplate ( 'forum_main' ) . "\";");

ob_end_flush();
}

//---------------------------------------------------
//
//---------------------------------------------------

else if ($apt->get['action']=="add")
{
    if(isset($apt->get['cat_id']))
    $cat_id = $apt->setid('cat_id');
    
    checkgroup('add_forum_post');
    
    if(!$apt->catgroup('groupost'))
    {
        $apt->head(LANG_TITLE_LOG_IN);
        eval("print \"" . $apt->gettemplate ( 'Login_main' ) . "\";");
        $apt->foot($pageft);
        exit;
   }


    $apt->head(LANG_TITLE_ADD_THREAD,1);

    if(!$apt->catClose($cat_id) == 1)
    {
         $apt->errmsg(LANG_ERROR_CAT_CLOSED);
    }

   $fo = new form;
   $menu = new menu;
   $index_middle .= $fo->forum_form('add');
   $right_menu   =  $menu->_menu(1);
   $apt->html_Output("");
}
//---------------------------------------------------
//
//---------------------------------------------------
else if($apt->get['action']=="insert")
{
    checkgroup('add_forum_post');

    if(!$apt->catgroup('groupost'))
    {
        $apt->head(LANG_TITLE_LOG_IN);
        eval("print \"" . $apt->gettemplate ( 'Login_main' ) . "\";");
        $apt->foot($pageft);
        exit;
    }
    
     @extract($HTTP_POST_VARS);
     $arr_post_vars = array($title,
                            $post,
                            $apt->cookie['cname']);

    if (!$apt->full($arr_post_vars))
    {
       $apt->errmsg(LANG_ERROR_VALIDATE);
    }

    if (!$apt->txtcounmxs($apt->post['post'],$apt->getsettings("txtcount3")))
    {
        $apt->errmsg(LANG_ERROR_LETTER_MAX);
    }
    if(!$apt->catClose($cat_id) == 1)
    {
         $apt->errmsg(LANG_ERROR_CAT_CLOSED);
    }
    
    if ($apt->retcheckgroup('upload_forum_file'))
    {
        if (is_uploaded_file($apt->files["phpfile"]['tmp_name']))
        {
              $up  = new RaFiaUpload;
              $up->cat ="forum";
              $up->uploads = $apt->files["phpfile"];

                if ($up->uploads["size"] > ($apt->getsettings("forumfilemxsize")*1024))
                {
                    $apt->errmsg(LANG_ERROR_SIZE_MUST_LESS.$apt->getsettings("forumfilemxsize")." kb");
                }

              if ($up->checkend($apt->getsettings("forumfileupload")) == false)
              {
                  $apt->errmsg("��� ����� �� ������� �� ����  ����� ������� <br>");
              }
               $is_uploaded_file =1;
        }
    }

    $userid     = $apt->format_data($apt->cookie['cid']);
    
    if($apt->cookie['cid']==0 or $apt->cookie['cid']== $apt->Guestid)
    {
         $name  = $apt->format_data($apt->post['name']);

         if(!isset($apt->post['name']))    $name  = $name."(����)";

         if (!$apt->checkifues("username",$name))
         {
             $apt->errmsg (LANG_ERROR_USERNAME_EXISTED);
         }
        $name  = $name."(����)";
    }
    else
    {
        $name  = $apt->format_data($apt->cookie['cname']);
    }

    $title      = $apt->format_data($apt->post['title']);
    $post       = $apt->format_post($apt->post['post']);
    $forumallow = $apt->retcheckgroup('stat_forum',1);
    $timestamp  = $apt->time;


    $Spams  = new Spams();
    if( $Spams->checkSpams() == false )
    {
        $apt->bodymsg(LANG_ERROR_WAIT_SECONDS,"$PHP_SELF?action=list&cat_id=$cat_id");
    }

    
    $result = $apt->query("insert into rafia_forum (cat_id,
                                                      title,
                                                      date_time,
                                                      userid,
                                                      name,
                                                      post,
                                                      allow,
                                                      usesig,
                                                      iconid,
                                                      lastuserid,
                                                      timestamp)
                                                values
                                                     ('$cat_id',
                                                     '$title',
                                                     '$timestamp',
                                                     '$userid',
                                                     '$name',
                                                     '$post',
                                                     '$forumallow',
                                                     '$usesig',
                                                     '$iconid',
                                                     '$userid',
                                                     '$timestamp')");

    if ($result)
    {
        $id = $apt->insertid();
        if ($is_uploaded_file ==1)
        {
              $up->uploadfile();
              $upid = $apt->insertid();
              $apt->query("UPDATE rafia_forum set uploadfile='$upid' where id = '$id'");        
		}
        
        $apt->query("UPDATE rafia_cat SET countopic = countopic+1, lastpostid ='$id' WHERE id = '$cat_id'");
        if($userid > 0 )
        $apt->query("UPDATE rafia_users SET allposts = allposts+1, lastadd='$timestamp' WHERE userid = '$userid'");
        
		$Counter->increment('forumCount');
		      
		$mail = new email;
        $mail->send_to_moderate($cat_id);

        if(($H == 1) && ($userid > 0 ))
        {
            $apt->query ("insert into rafia_alert
                                        (thread_id,userid) values
                                        ('$id','$userid')");
        }
        if ($forumallow!="yes")
        {
          $url="$PHP_SELF?action=list&cat_id=$cat_id";
          $apt->bodymsg(LANG_MSG_THREAD_HAS_ADDED,$url);
        }
        else
        {
            $url = "$PHP_SELF?action=view&id=$id";
            $apt->bodymsg(LANG_MSG_POST_HAS_BEEN_ADDED,$url);

        }
    }
    else
    {
        $apt->bodymsg(LANG_ERROR_ADD_DB);
    }
}
else if($apt->get['action']=="edit")
{
    $id = $apt->setid('id');
    
    if(!$apt->retcheckgroup('edit_forum_own')&&!$apt->retcheckgroup('edit_forum') )
    {
        $apt->head(LANG_ERROR);
        $apt->errmsg(LANG_ERROR_CAN_NOT_EDIT);
    }
    
    $result     = $apt->query("SELECT * FROM rafia_forum WHERE id = '$id'");
    $apt->row = $apt->dbarray($result);

    if ($apt->cookie['cid'] == $apt->row['userid'] ||  $apt->checkcadmincat($apt->row['cat_id']))
    {
        $time = $apt->time;

        if(!$apt->checkcadmincat($apt->row['cat_id']))
        {
            if($apt->row['date_time'] < ($time-$apt->getsettings("timeallowedit")))
            {
                $apt->errmsg(LANG_ERROR_TIMERINTERVAL);
            }
            else
            {
                $apt->head(LANG_TITLE_EDIT_POST);
                $fo = new form;
                $index_middle = $fo->forum_form('edit');
                $apt->html_Output("");
                //eval("print \"".$apt->gettemplate("form_main")."\";");
            }
        }
        else
        {
            $apt->head(LANG_TITLE_EDIT_POST);
            $fo = new form;
            $index_middle = $fo->forum_form('edit');
            $apt->html_Output("");
            //eval("print \"".$apt->gettemplate("form_main")."\";");
        }
    }
    else
    {
        $apt->head(LANG_ERROR);
        $apt->errmsg(LANG_ERROR_CAN_NOT_EDIT);
   }
}

//---------------------------------------------------
//
//---------------------------------------------------

else if($apt->get['action']=="UF")
{
    $id = $apt->setid('id');


    if(!$apt->retcheckgroup('edit_forum_own') &&  !$apt->retcheckgroup('edit_forum') )
    {
        $apt->head($head_err);
        $apt->errmsg(LANG_ERROR_CAN_NOT_EDIT);
    }
    // Start Added By Myrosy 22/10/2006
    $result     = $apt->query("SELECT * FROM rafia_forum WHERE id = '$id'");
    $apt->row = $apt->dbarray($result);

    if ($apt->cookie['cid'] == $apt->row['userid'] ||  $apt->checkcadmincat($apt->row['cat_id']))
    {
     // End Added By Myrosy 22/10/2006
    if ($apt->post['del'] =='1')
    {
        $cat_id = $apt->post['cat_id'] ; // Added By Myrosy  13/03/2006
        $apt->delmsg($cat_id,$id);
    }
    
    
    @extract($HTTP_POST_VARS);

     // Start Added By Myrosy 22/10/2006
    $arr_post_vars = array($title,
                            $post,
                            $apt->cookie['cname']);
     // End Added By Myrosy 22/10/2006

    if (!$apt->full($HTTP_POST_VARS))
    {
        $apt->errmsg(LANG_ERROR_VALIDATE);
    }
    
    if (!$apt->txtcounmxs($apt->post['post'],$apt->getsettings("txtcount3")))
    {
        $apt->errmsg(LANG_ERROR_LETTER_MAX);
    }
    
    $title     =  $apt->format_data($apt->post['title']);
    $post      =  $apt->format_post($apt->post['post']);
    
    if ($apt->post[editupload] =="delete")
    {
        $row = $apt->dbfetch("SELECT * FROM rafia_upload WHERE upid='$uploadfile'");
        @extract($row);
        $filename = $apt->upload_path."/".$uppostid.".".$upcat;
        if(@unlink($filename))
        {
           $apt->query("DELETE FROM rafia_upload WHERE upid='$uploadfile'");
           $apt->query("update rafia_forum set uploadfile = '0' where id = '$id'");
        }

    }
    elseif($editupload =="new")
    {
        if ($apt->retcheckgroup('upload_forum_file'))
        {
            if (is_uploaded_file($apt->files["phpfile"]['tmp_name']))
            {
                $up  = new RaFiaUpload;
                $up->cat ="forum";
                $up->uploads = $apt->files["phpfile"];
                if ($up->uploads["size"] > ($apt->getsettings("forumfilemxsize")*1024))
                {
                    $apt->errmsg(LANG_ERROR_SIZE_MUST_LESS.$apt->getsettings("forumfilemxsize")." kb");
                }

                if ($up->checkend($apt->getsettings("forumfileupload")) == false)
                {
                    $apt->errmsg("��� ����� �� ������� �� ����  ����� ������� <br>");
                }
                $up->uploadfile(1);
            }
        }
    }
    if ( $apt->checkcadmincat($catid))
    {
           $allow = $apt->adminunset($allow);

           $result= $apt->query("update rafia_forum set
                                          cat_id = '$cat_id',
                                          title = '$title',
                                          post = '$post',
                                          allow = '$allow'
                                          where id = '$id'");
           if($catid != $cat_id)
           {
               $result = $apt->query("update rafia_comment set cat_id='$cat_id' where thread_id='$id'");
           }
    }
    else
    {
        $result = $apt->query("update rafia_forum set
                                        title = '$title',
                                        post = '$post'
                                        where id = '$id'");
    }
    $url = "$PHP_SELF?action=view&id=$id";
    if ($result)
    {
        $apt->bodymsg(LANG_MSG_YOUR_POST_HAS_EDITED,$url);
    }
    else
    {
        $apt->bodymsg(LANG_ERROR_ADD_DB,$url);
    }
   }
   // Start Added By Myrosy 22/10/2006
    else
    {
        $apt->head(LANG_ERROR);
        $apt->errmsg(LANG_ERROR_CAN_NOT_EDIT);
    }
}
   // End Added By Myrosy 22/10/2006
//---------------------------------------------------
//
//---------------------------------------------------

else if ($apt->get['action']=="addcomment")
{
     $id = $apt->setid('id');
     
     checkgroup('add_forum_c') ;
      
     $result = $apt->query("SELECT * FROM rafia_forum WHERE id='$id'");
     
     $apt->row = $apt->dbarray ($result);

        if ($apt->row['close'] == 1)
        {
            $apt->errmsg(LANG_ERROR_POST_CLOSED);
        }


     if(!$apt->catClose($apt->row[cat_id]) == 1)
     {
         $apt->errmsg(LANG_ERROR_CAT_CLOSED);
     }
        if((isset($apt->get[qp]))&&(!isset($apt->get[qc])))
        {

           $apt->row['quote'] = "\n\n\n[QUOTE]������ :".$apt->row['name']."\n".$apt->row['post']."[/QUOTE]";
        }
        if((isset($apt->get[qc])) &&(!isset($apt->get[qp])))
        {
            $qc = $apt->get[qc];
           $result = $apt->query("select name,comment from rafia_comment where id='$qc'");
           $row = $apt->dbarray($result);
           $apt->row['quote'] = "\n\n\n[QUOTE]������ :".$row['name']."\n".$row['comment']."[/QUOTE]";
        }

         $apt->head(LANG_TITLE_ADD_COMMENT,1);

         $fo = new form;
         $captcha = rand(1000,9999);
         $fo->cap = $captcha;
         $_SESSION['memccode']= $captcha;

         $index_middle .= $fo->comment_form('add');
         $apt->html_Output("");
       // eval("print \"".$apt->gettemplate("form_main")."\";");
}

//---------------------------------------------------
//
//---------------------------------------------------

else if($apt->get['action']=="vfc")
{
    $apt->head(LANG_TITLE_ADD_COMMENT);
    $id = $apt->setid('id');
    print"<br>";
    
    $perpage_comment   = $apt->getsettings("forumperpagecomment");
    
    if( $apt->dbnumquery ("rafia_comment","thread_id=$id") > 0 )
    {
        $result = $apt->query("SELECT * FROM rafia_comment
                                               WHERE thread_id='$id'  and allow='yes'
                                               ORDER BY id DESC
                                               LIMIT $start,$perpage_comment");

       $page_result =  $apt->query ("SELECT * FROM rafia_comment WHERE thread_id='$id' and allow='yes'");

       $apt->numrows = $apt->dbnumrows ($page_result);

       $pagenum = $apt->pagenum ($perpage_comment,"vfc&id=$id");
       
       print $pagenum;
       
       while($row =$apt->dbarray($result))
       {
           @extract($row);

           $name = stripslashes($name);

           $comment = $apt->rafia_code($comment);

           $date =  $apt->Hijri("$date");

           eval("echo \"".$apt->gettemplate("s_view_topic_comment")."\";");
       }
       
       $result = $apt->query ("SELECT * FROM rafia_forum WHERE id='$thread_id'");

       $row = $apt->dbarray($result);

       @extract($row);

       $name = stripslashes($name);

       $comment = $apt->rafia_code($post);

       $date =  $apt->Hijri("$date");
       
       if ( $start == 0 )
       {
            eval("echo\"".$apt->gettemplate("s_view_topic_comment")."\";");
       }

       $pagenum = $apt->pagenum($perpage_comment,"vfc&id=$thread_id");
        print $pagenum;
       }
       else
       {
           $result=$apt->query("SELECT * FROM rafia_forum WHERE id='$id'");

           $row = $apt->dbarray($result);

           @extract($row);

           $name = stripslashes($name);

           $comment = $apt->rafia_code($post);

           $date =  $apt->Hijri($date);

           if ($start==0)
           {
               eval("echo \"".$apt->gettemplate("s_view_topic_comment")."\";");
           }

     }
   exit;
}
//---------------------------------------------------
//
//---------------------------------------------------

else if($apt->get['action'] == "insertcomment" )
{
     checkgroup('add_forum_c') ;

     @extract($HTTP_POST_VARS);

    $pre_ses = $_SESSION['memccode'];
    $newcode = intval($newcode);

    $this_url = explode('/',$_SERVER['HTTP_HOST']);
    $reff_url = explode('/',$_SERVER['HTTP_REFERER']);

    if($this_url[0] !== $reff_url[2]){
    $apt->bodymsg('���� ... �� ����� ����� ����� �� ���� ������',"index.php");
    }

    if($spam !== 'commenttnotspam'){
	$id = $apt->post['post_id'];
    $apt->bodymsg('���� ... ��� ������� ��� ������',"forum.php?action=view&id=$id");
    exit;
    }

     if (!$apt->full($apt->post['post']))
     {
         $apt->errmsg(LANG_ERROR_VALIDATE);
     }
     
     if (!$apt->full($apt->post['post_id']))
     {
         $apt->errmsg(LANG_ERROR_VALIDATE);
     }
     
     if (!$apt->txtcounmxs($apt->post['post'],$apt->getsettings("txtcount6")))
     {
          $apt->errmsg(LANG_ERROR_LETTER_MAX);
     }
    
    $timestamp = $apt->time;
    
    if(!$apt->catClose($apt->post[cat_id]) == 1)
    {
         $apt->errmsg(LANG_ERROR_CAT_CLOSED);
    }
    
    if($apt->cookie['cid']==0 or $apt->cookie['cid']== $apt->Guestid)
    {
         $name  = $apt->format_data($apt->post['name']);

         if(!isset($apt->post['name']))    $name  = $name."(����)";

         if (!$apt->checkifues("username",$name))
         {
             $apt->errmsg (LANG_ERROR_USERNAME_EXISTED);
         }
        $name  = $name."(����)";
    }
    else
    {
        $name  = $apt->format_data($apt->cookie['cname']);
    }
    
    $title      = $apt->format_data($apt->post['title']);
    $comment    = $apt->format_post($apt->post['post']);
    $userid     = intval($apt->format_data($apt->cookie['cid']));
    $usesig     = intval($apt->format_post($usesig));
    $cat_id     = intval($apt->format_post($cat_id));
    $post_id    = intval($apt->format_post($post_id));
    $titlepost  = $apt->format_data($titlepost);
    
    
    $Spams  = new Spams();

    if( $Spams->checkSpams() == false )
    {
        $apt->bodymsg(LANG_ERROR_WAIT_SECONDS,"$PHP_SELF?action=list&cat_id=$cat_id");
    }

    if ($apt->retcheckgroup('upload_comment_file'))
    {
        if (is_uploaded_file($apt->files["phpfile"]['tmp_name']))
     {
         $up  = new RaFiaUpload;
         $up->cat ="comment";
         $up->uploads = $apt->files["phpfile"];
         if ($up->uploads["size"] > ($apt->getsettings("commentfilemxsize")*1024))
         {
             $apt->errmsg(LANG_ERROR_SIZE_MUST_LESS.$apt->getsettings("commentfilemxsize")." kb");
         }

         if ($up->checkend($apt->getsettings("commentfileupload")) == false)
         {
             $apt->errmsg("��� ����� �� ������� �� ����  ����� ������� <br>");
         }
      }
 }
    $commallow     = $apt->retcheckgroup('allow_comment',1);
    $result = $apt->query("insert into rafia_comment (thread_id,
                                                        userid,
                                                        name,
                                                        title,
                                                        comment,
                                                        cat_id,
                                                        usesig,
                                                        timestamp,allow)
                                                  values
                                                        ('$post_id',
                                                        '$userid',
                                                        '$name',
                                                        '$title',
                                                        '$comment',
                                                        '$cat_id',
                                                        '$usesig',
                                                        '$timestamp','$commallow')");
     if ($result)
     {
         $commentid = $apt->insertid();
         if (is_uploaded_file($apt->files["phpfile"]['tmp_name']))
         {

              $up->uploadfile();
              $upid = $apt->insertid();
              $apt->query("update rafia_comment set
                             uploadfile  = '$upid'
                             where id = '$commentid'");

        }
         $apt->query("UPDATE rafia_cat SET countcomm=countcomm+1, lastpostid='$post_id' WHERE id = '$cat_id'");
         $apt->query("UPDATE rafia_forum SET c_comment=c_comment+1,timestamp='$timestamp',  lastuserid='$userid' WHERE id = '$post_id'");
         if($userid > 0 )
         $apt->query("UPDATE rafia_users SET allposts = allposts+1, lastadd='$timestamp'  WHERE userid = '$userid'");
         
		 $Counter->increment('commentCount');
         
         $perpage_comment   = $apt->getsettings("forumperpagecomment");
         $url  =  $apt->getcommenturl($commentid,'thread_id');
         $mail = new email;
         $mail->send_to_users('thread_id',
                               $userid,
                               $post_id,
                               $url,
                               $H);
                               
         $apt->bodymsg(LANG_MSG_POST_HAS_BEEN_ADDED,$url);
    }
    else
    {
        $url = "forum.php?action=view&id=$post_id";

        $apt->bodymsg(LANG_ERROR_ADD_DB,$url);
    }
}
//---------------------------------------------------
//
//---------------------------------------------------

else if($apt->get['action'] == "editcomment")
{
      $id = $apt->setid('id');
      
      if(!$apt->retcheckgroup('edit_forum_own') &&  !$apt->retcheckgroup('edit_forum') )
      {
          $apt->head(LANG_ERROR);
          $apt->errmsg(LANG_ERROR_CAN_NOT_EDIT);
      }
      
      $result = $apt->query("select * from rafia_comment where id='$id'");
      
      $apt->row = $apt->dbarray($result);
      
      $apt->row['post_id'] = $apt->row['thread_id'];
      
      if ($apt->cookie['cid'] == $apt->row['userid'] || $apt->checkcadmincat($apt->row['cat_id']))
        {
           $apt->head(LANG_TITLE_EDIT_POST);
            
            $time = $apt->time;
            
        if(!$apt->checkcadmincat($apt->row['cat_id']))
        {
             if($apt->row['timestamp'] < ($time-$apt->getsettings("timeallowedit")))
             {
                 $apt->errmsg(LANG_ERROR_TIMERINTERVAL);
             }
             else
             {
                 $fo = new form;
                 $index_middle = $fo->comment_form('edit');
                 $apt->html_Output("");
             }
        }
        else
        {
            $fo = new form;
            $index_middle = $fo->comment_form('edit');
            $apt->html_Output("");
        }
       }
       else
       {
           $apt->errmsg(LANG_ERROR_CAN_NOT_EDIT);
      }
}

//---------------------------------------------------
//
//---------------------------------------------------

else if($apt->get['action']=="UC")
{
      $id = $apt->setid('id');
    
      if(!$apt->retcheckgroup('edit_comment_own') &&  !$apt->retcheckgroup('edit_comment') )
      {
          $apt->head($head_err);
          $apt->errmsg(LANG_ERROR_CAN_NOT_EDIT);
      }
      extract($HTTP_POST_VARS);
      
      if ($apt->post['del'] =='1')
      {
           $cat_id = $apt->post['cat_id'] ;
           $apt->delmsg($cat_id,'',$id);
      }

      if (!$apt->full($apt->post['post']))
      {
          $apt->errmsg(LANG_ERROR_VALIDATE);
      }

      if (!$apt->txtcounmxs($apt->post['post'],$apt->getsettings("txtcount6")))
      {
          $apt->errmsg(LANG_ERROR_LETTER_MAX);
      }
       //////////////////////////////////////////////
   if ($apt->post['editupload'] == "delete" )
    {
        $row = $apt->dbfetch("SELECT * FROM rafia_upload WHERE upid='$uploadfile'");
        @extract($row);
        $filename = $apt->upload_path."/".$uppostid.".".$upcat;
        if(@unlink($filename))
        {

            $apt->query("DELETE FROM rafia_upload WHERE upid='$uploadfile'");
            $apt->query("update rafia_comment set
                                          uploadfile = '0'
                                          where id = '$id'");
                                          
        }
        
    }
     //////////////////////////////////////////////
    if($apt->post['editupload'] == 'new' )
    {
        if ($apt->retcheckgroup('upload_forum_file'))
        {
            if (is_uploaded_file($apt->files["phpfile"]['tmp_name']))
            {
                $up  = new RaFiaUpload;
                $up->cat = "comment";
                $up->uploads = $apt->files["phpfile"];
                if ($up->uploads["size"] > ($apt->getsettings("commentfilemxsize")*1024))
                {
                  $apt->errmsg(LANG_ERROR_SIZE_MUST_LESS.$apt->getsettings("commentfilemxsize")." kb");
                }

                if ($up->checkend($apt->getsettings("commentfileupload")) == false)
                {
                    $apt->errmsg("��� ����� �� ������� �� ����  ����� ������� <br>");
                }
                $up->uploadfile(1);
            }
        }
    }
    ////////////////
      $title   = $apt->format_data($apt->post['title']);
      $comment = $apt->format_post($apt->post['post']);

    if ( $apt->checkcadmincat($apt->post['cat_id']))
    {
           $result= $apt->query("update rafia_comment set
                                          title = '$title',
                                        allow = '$allow',

                                          comment = '$comment'
                                          where id = '$id'");
    }
    else
    {
        $result = $apt->query("update rafia_comment set
                                        allow = '$allow',
                                        comment = '$comment'
                                        where id = '$id'");
    }
    
    if($apt->post['commentpage'])
    {
         $url = "$commentpage#comment$id";
    }
    else
    {
        $url = "$PHP_SELF?action=view&id=".$apt->post['post_id'];
    }

    if ($result)
    {
        $apt->bodymsg(LANG_MSG_YOUR_POST_HAS_EDITED,$url);
    }
    else
    {

        $apt->bodymsg(LANG_ERROR_ADD_DB,$url);
    }
}
//---------------------------------------------------
//
//---------------------------------------------------
else if($apt->get['action']=="admin")
{
    $apt->head(LANG_TITLE_MODERATE_POSTS);

    if (( $apt->cookie['cgroup'] == $apt->a_g) || ( $apt->cookie['cgroup'] == $apt->m_g))
    {
        if ( $apt->cookie['cgroup'] == $apt->a_g)
        {
            $result = $apt->query("SELECT * FROM rafia_cat WHERE catType='2' AND subcat!='0' ORDER BY id DESC");
        }
        else
        {
            $result = $apt->query("SELECT rafia_cat.*
                             FROM rafia_cat,rafia_moderate
                             WHERE rafia_cat.catType='2' AND rafia_cat.subcat!='0' AND rafia_cat.id=rafia_moderate.moderatecatid
                             AND rafia_moderate.moderateid =".$apt->cookie['cid']."
                             ORDER BY id DESC");
        }
                                                          
        $countwit = $apt->dbnumquery("rafia_forum","allow='wit'");
        
        if ($countwit == "")
        {
            $countwit=" �� ����";
        }
        
        $index_middle .=  $apt->admintablehead("$PHP_SELF?action=wait","����� ���������");
        while($row = $apt->dbarray($result))
        {
            @extract($row);

                $numrows = $apt->dbnumquery("rafia_forum","cat_id='$id'");
                $index_middle .= $apt->admintablecell("$PHP_SELF?action=forum&cat_id=$id");

        }
        $index_middle .= $apt->admintableclose();
        $apt->html_Output($left_menu);

    }
    else
    {
        $apt->head(LANG_TITLE_LOG_IN);
        eval("print \"" . $apt->gettemplate ( 'Login_main' ) . "\";");
        $apt->foot($pageft);
        exit;
    }
}
//---------------------------------------------------
//
//---------------------------------------------------

else if($apt->get['action']=="forum")
{
    $perpage = 50;
    
    $cat_id = $apt->setid('cat_id');
    
    if( $apt->checkcadmincat($cat_id) )
    {
       $apt->head(LANG_TITLE_MODERATE_POSTS);

       $result = $apt->query ("SELECT * FROM rafia_forum WHERE
                                cat_id='$cat_id' ORDER BY id DESC
                                LIMIT  $start,$perpage");

       $apt->numrows = $apt->dbnumquery("rafia_forum","allow='yes' and cat_id=$cat_id");

       $index_middle .= $apt->pagenum($perpage,"forum&cat_id=$cat_id");



        $index_middle  .=$apt->admin_form_opan("doforum");

         $index_middle .=$apt->admin_table_head("������ �������");

       while( $apt->row = $apt->dbarray( $result ) )
       {
           $result2 = $apt->query("SELECT thread_id FROM rafia_comment WHERE thread_id=" . $apt->row["id"] . "");

           $numrows = $apt->dbnumrows($result2);

           $index_middle .=  $apt->admin_table_cell("cat_id=$cat_id&id","edit","");
       }

         $index_middle .= $apt->admin_table_close();

        $index_middle .=  $apt->admin_form_close('2');

      $apt->html_Output($left_menu);

}
else
{
       $apt->head(LANG_TITLE_LOG_IN);

      eval("print \"" . $apt->gettemplate ( 'Login_main' ) . "\";");


}
}
//---------------------------------------------------
//
//---------------------------------------------------

else if( $apt->get['action']== "doforum" )
{

    if ( $apt->checkcadmincat($apt->post['cat_id']))
    {
        $cat_id =  $apt->post['cat_id'];
        $catid =  $apt->post['catid'];
        
        if (count($apt->post['do']) > 0)
        {
             if($apt->post['move'])
             {
                 foreach($apt->post['do'] as $id)
                 {

                    $result = $apt->query("update rafia_forum set cat_id='$catid' where id='$id'");
                    $result = $apt->query("update rafia_comment set cat_id='$catid' where thread_id='$id'");
                }
                if ($result)
                {
                    $numrows = $apt->dbnumquery("rafia_forum","cat_id='$catid'");
                    $result  = $apt->query("update rafia_cat set countopic='$numrows' where id='$catid'");
                    $numrows = $apt->dbnumquery("rafia_comment","cat_id='$catid'");
                    $result  = $apt->query("update rafia_cat set countcomm='$numrows' where id='$catid'");
                    $numrows = $apt->dbnumquery("rafia_forum","cat_id='$cat_id'");
                    $result  = $apt->query("update rafia_cat set countopic='$numrows' where id='$cat_id'");
                    $numrows = $apt->dbnumquery("rafia_comment","cat_id='$cat_id'");
                    $result  = $apt->query("update rafia_cat set countcomm='$numrows' where id='$cat_id'");
                    
                    $apt->bodymsg(LANG_MSG_LOGED_IN,$apt->refe);
                 }
                 
            }
            elseif($apt->post['del'])
            {

                foreach($apt->post['do'] as $id)
                {


                    $result  = $apt->query("delete from  rafia_forum where id='$id'");
                    $Counter->dropFrom('forumCount',1);
                    $filename = $apt->upload_path."/".$id.".forum";
                    @unlink($filename);
                    if($apt->getuploadsdb($id,'thread_id')){
                        $apt->query("delete from  rafia_comment where thread_id='$id'");
                    }
                }
                if ($result)
                {
                    $numrows = $apt->dbnumquery("rafia_forum","cat_id='$cat_id'");
                    $result  = $apt->query("update rafia_cat set countopic='$numrows' where id='$cat_id'");
                    $numrows = $apt->dbnumquery("rafia_comment","cat_id='$cat_id'");
                    $result  = $apt->query("update rafia_cat set countcomm='$numrows' where id='$cat_id'");
                    $numrows = $apt->dbnumquery("rafia_forum");
                    $Counter->SetCount('forumCount',$numrows);
                    $numcomment = $apt->dbnumquery("rafia_comment");
                    $Counter->SetCount('commentCount',$numcomment);
                    $apt->bodymsg(LANG_MSG_POST_HAS_BEEN_DELETED,$apt->refe);
                }

            }
            elseif($apt->post['allow'])
            {
                 foreach($apt->post['do'] as $id)
                 {
                    $result = $apt->query("update rafia_forum set allow='yes' where id=$id");
                 }
                 if ($result)
                 {
                     $apt->bodymsg(LANG_MSG_POST_HAS_APPROVED,$apt->refe);
                }
             }
         }
         else
        {
            $apt->errmsg(LANG_ERROR_CHOICE);
        }
    }
     else
    {
         $apt->errmsg(LANG_ERROR_DEL_BY_ADMIN);

}
}
elseif ($apt->get['action']=="comment")
{
    $cat_id = $apt->setid('cat_id');
    $id = $apt->setid('id');

    if( !$apt->checkcadmincat($cat_id) )
    {
        $apt->head(LANG_TITLE_LOG_IN);

        eval("print \"" . $apt->gettemplate ( 'Login_main' ) . "\";");

        exit;
    }
   
    $apt->head(LANG_TITLE_MODERATE_POSTS);

    $result = $apt->query("SELECT * FROM rafia_comment WHERE
                             thread_id='$id' ORDER BY id ASC");
                             
    if($apt->dbnumrows($result) > 0)
    {
         $index_middle .=  $apt->admin_form_opan("deletecomment&cat_id=".$cat_id);

         $index_middle .=   $apt->admin_table_head("����� ������ ����������");

        while($apt->row =  $apt->dbarray($result))
        {
             $apt->row["title"] = "������ : ".$apt->row['name']."<hr>".$apt->title_cut($apt->row['comment'],150);
            $index_middle .=   $apt->admin_table_cell("","editcomment","","0");
        }
        
         $index_middle .=   $apt->admin_table_close();

         $index_middle .=  $apt->admin_form_close(0,0);

    }
    else
    {
    $index_middle .=  "<p>&nbsp;������ ���� �� ��� ������� .</p>";
    }
      $apt->html_Output($left_menu);

}
else if( $apt->get['action'] == "del" )
{
   $cat_id = $apt->post['cat_id'];

    if((!$apt->checkcadmincat($cat_id)) || (!$apt->checkcmodcat('can_delete')))
    {
       $apt->head(LANG_TITLE_LOG_IN);

      eval("print \"" . $apt->gettemplate ( 'Login_main' ) . "\";");

      exit;
   }

    if(!empty( $apt->post['idp']))
    {
        $id = $apt->post['idp'];
        
        $result = $apt->query("delete from  rafia_forum where id=$id and cat_id=$cat_id");
        if($result)
        {   $Counter->dropFrom('forumCount',1);
            $filename = $apt->upload_path."/".$id.".forum";
            @unlink($filename);
            if($apt->getuploadsdb($id,'thread_id'))
            {
                $numcomment = $apt->dbnumquery("rafia_comment","thread_id='$id'");
                $Counter->dropFrom('commentCount',$numcomment);
               $apt->query("delete from  rafia_comment where thread_id='$id'");

           }
        }
    }
    else if(!empty( $apt->post['idc']))
    {
         $id = $apt->post['idc'];
         $filename = $apt->upload_path."/".$id.".comment";
         @unlink($filename);
         $result = $apt->query("delete from  rafia_comment where id=$id and cat_id=$cat_id");
         $Counter->dropFrom('commentCount',1);
    }
    if($result)
    {
        $Rurl = "forum.php?action=list&cat_id=$cat_id";
        $apt->bodymsg(LANG_MSG_POST_HAS_BEEN_DELETED,$Rurl);
    }
}
else if($apt->get['action']=="wait")
{

     if (( $apt->cookie['cgroup'] == "1") || ( $apt->cookie['cgroup'] == "4"))
    {
        $apt->head(LANG_TITLE_MODERATE_POSTS);

        $result = $apt->query("SELECT * FROM rafia_forum WHERE allow='wit' ORDER BY id ASC");

        if($apt->dbnumrows($result))
        {
            $index_middle .= $apt->admin_form_opan("doforum");

            $index_middle .= $apt->admin_table_head("������ ��� ��������");

             while($apt->row = $apt->dbarray($result))
            {

                $index_middle .=$apt->admin_table_cell("thread_id","edit","",0);
            }

            $index_middle .= $apt->admin_table_close();
            $index_middle .= $apt->admin_form_close('2',0);
            
            }
            else
            {
                $index_middle .= "<p>�� ���� ������ ��� ��������.</p>";
            }
            // eval("print \"" . $apt->gettemplate ( 'admin_temp' ) . "\";");
            $apt->html_Output($left_menu);
        }
        else
        {
            $apt->head(LANG_TITLE_LOG_IN);

  eval("print \"" . $apt->gettemplate ( 'Login_main' ) . "\";");

        }
}
else if($apt->get['action'] == "deletecomment" )
{



    $cat_id  = $apt->setid('cat_id');
    $do  = $apt->post['do'];
    if(( $apt->checkcadmincat($cat_id) ) && ($apt->checkcmodcat('can_delete')))
    {
        if (count($do) >0)
        {
		if($apt->post['del']){
            foreach($do as $id)
            {
                $result = $apt->query("delete from  rafia_comment where id=$id");
                $filename = $apt->upload_path."/".$id.".comment";
                @unlink($filename);
            }
        }elseif($apt->post['allow']){
            foreach($do as $id)
            {
                $result = $apt->query("update rafia_comment set allow='yes' where id=$id");
            }
        }
        }
        $url = $apt->refe;
        if ($result)
        {
		if($apt->post['del']){
            $apt->bodymsg(LANG_MSG_POST_HAS_BEEN_DELETED,$url);
		}else{
            $apt->bodymsg(LANG_MSG_POST_HAS_APPROVED,$url);
		}
        }
        else
        {
            $apt->bodymsg(LANG_ERROR_ADD_DB,$url);
        }
    }
    else
    {
        $apt->head(LANG_TITLE_LOG_IN);
         eval("print \"" . $apt->gettemplate ( 'Login_main' ) . "\";");
    }




}
elseif($apt->get['action'] == "sticky" )
{
    $forumid = $apt->setid('forumid');
    $cat_id  = $apt->setid('cat_id');
    
    if (( $apt->cookie['cgroup'] == $apt->a_g) || ( $apt->cookie['cgroup'] == $apt->m_g))
    {
        if ($apt->checkcmodcat('can_sticky'))
        {
            $result = $apt->query("update rafia_forum set sticky='1' where id=$forumid and cat_id=$cat_id");
            if ($result)
            {
                $url="forum.php?action=view&id=$forumid";
                $apt->bodymsg(LANG_MSG_THREAD_HAS_STUCK,$url);
            }
        }
    }
}
elseif($apt->get['action']=="unsticky")
{
    $forumid = $apt->setid('forumid');
    $cat_id  = $apt->setid('cat_id');

    if (( $apt->cookie['cgroup'] == $apt->a_g) || ( $apt->cookie['cgroup'] == $apt->m_g))
    {
        if ($apt->checkcmodcat('can_sticky'))
        {
            $result = $apt->query("update rafia_forum set sticky='0' where id=$forumid and cat_id=$cat_id");
            if ($result)
            {
                $url = "forum.php?action=view&id=$forumid";
                $apt->bodymsg(LANG_MSG_THREAD_HAS_UNSTUCK,$url);
            }
        }
    }
}
elseif($apt->get['action']=="open")
{
    $forumid = $apt->setid('forumid');
    $cat_id  = $apt->setid('cat_id');
    if (( $apt->cookie['cgroup'] == $apt->a_g) || ( $apt->cookie['cgroup'] == $apt->m_g))
    {
        if ($apt->checkcmodcat('can_close'))
        {
            $result = $apt->query("update rafia_forum set close='0' where id=$forumid and cat_id=$cat_id");
            if ($result)
            {
                $url = "forum.php?action=view&id=$forumid";
                $apt->bodymsg(LANG_MSG_POST_HAS_OPENED,$url);
            }
        }
    }
}
elseif($apt->get['action']=="close")
{
     $forumid = $apt->setid('forumid');
     $cat_id  = $apt->setid('cat_id');
    if (( $apt->cookie['cgroup'] == $apt->a_g) || ( $apt->cookie['cgroup'] == $apt->m_g))
    {
        if ($apt->checkcmodcat('can_close'))
        {
            $result = $apt->query("update rafia_forum set close='1' where id=$forumid and cat_id=$cat_id");
            if ($result)
            {
                $url="forum.php?action=view&id=$forumid";
                $apt->bodymsg(LANG_MSG_THREAD_HAS_CLOSED,$url);
            }
        }
    }
}
if(isset($fo))
{
    print $apt->script->post_java();
}
$apt->foot($pageft);
?>